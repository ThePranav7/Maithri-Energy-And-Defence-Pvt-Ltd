import drdo from './logos/drdo.webp'
import nstl from './logos/nstl.webp'
import drdl from './logos/drdl.webp'
import alphaElsec from './logos/alpha_elsec.webp'
import scandron from './logos/scandron.webp'
import rci from './logos/rci.webp'
import aeroEngineering from './logos/aero_engineering.webp'
import hblNew from './logos/hbl_new.webp'
import tataSolar from './logos/tata_solar.webp'
import adaniSolar from './logos/adani_solar.webp'
import apraava from './logos/apraava.webp'
import torrentPower from './logos/torrent_power.webp'
import jswEnergy from './logos/jsw_energy.webp'
import sterlingWilson from './logos/sterling_wilson.webp'
import sfs from './logos/sfs.webp'
import ingloV2 from './logos/inglo_v2.webp'
import maithriAquatechV2 from './logos/maithri_aquatech_v2.webp'
import gayamMotor from './logos/gayam_motor.webp'
import beyondWater from './logos/beyond_water.webp'
import inglo from './logos/inglo.webp'
import maithriAquatech from './logos/maithri_aquatech.webp'
import kistlerMorse from './logos/kistler_morse.webp'
import sika from './logos/sika.webp'
import aeroRelSystems from './logos/aero_rel_systems.webp'
import maccon from './logos/maccon.webp'
import greenco from './logos/greenco.webp'
import mytrah from './logos/mytrah.webp'
import './TrustedBy.css'

function ShieldIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6l7-3z"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
    </svg>
  )
}

function FactoryIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M3 21V11l5 3.2V11l5 3.2V9l6 4v8H3z"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
      <path d="M8 21v-4M13 21v-4M18 21v-4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
      <path d="M16 9V4h2v3" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

function SignalIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M12 21v-8" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
      <path
        d="M8.5 9.5a5 5 0 0 1 7 0M6 7a9 9 0 0 1 12 0"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
      />
      <circle cx="12" cy="13" r="1.6" fill="currentColor" />
    </svg>
  )
}

const GROUPS = [
  {
    id: 'defense-government',
    label: 'Our Defence Clients',
    Icon: ShieldIcon,
    keyClient: 'DRDO',
    rolling: true,
    logos: [
      { src: drdo, alt: 'DRDO', name: 'DRDO' },
      { src: nstl, alt: 'DRDO NSTL', name: 'NSTL' },
      { src: drdl, alt: 'DRDO DRDL', name: 'DRDL' },
      { src: alphaElsec, alt: 'Alpha Elsec Defence & Aerospace Systems', name: 'Alpha Elsec' },
      { src: scandron, alt: 'Scandron', name: 'Scandron' },
      { src: rci, alt: 'RCI', name: 'RCI' },
      { src: aeroEngineering, alt: 'Aero Engineering', name: 'Aero Engineering' },
      { src: sika, alt: 'SIKA Aerospace & Defence', name: 'SIKA Aerospace & Defence' },
      { src: aeroRelSystems, alt: 'Aero Rel Systems', name: 'Aero Rel Systems' },
      { src: maccon, alt: 'Maccon', name: 'Maccon' },
    ],
  },
  {
    id: 'industrial-energy',
    label: 'Our Industrial Clients',
    Icon: FactoryIcon,
    keyClient: 'Tata Solar',
    rolling: true,
    logos: [
      { src: hblNew, alt: 'HBL - Hyderabad Batteries Limited', name: 'HBL' },
      { src: tataSolar, alt: 'Tata Power Solar', name: 'Tata Solar' },
      { src: adaniSolar, alt: 'Adani Solar', name: 'Adani Solar' },
      { src: apraava, alt: 'Apraava Energy', name: 'Apraava Energy' },
      { src: torrentPower, alt: 'Torrent Power', name: 'Torrent Power' },
      { src: jswEnergy, alt: 'JSW Energy', name: 'JSW Solar' },
      { src: sterlingWilson, alt: 'Sterling & Wilson', name: 'Sterling & Wilson' },
      { src: sfs, alt: 'SFS', name: 'SFS' },
      { src: ingloV2, alt: 'Inglo', name: 'Inglo' },
      { src: maithriAquatechV2, alt: 'Maithri Aquatech', name: 'Maithri Aquatech' },
      { src: greenco, alt: 'Greenco LED & Solar', name: 'Greenco LED & Solar' },
      { src: mytrah, alt: 'Mytrah', name: 'Mytrah' },
    ],
  },
  {
    id: 'mobility-iot-others',
    label: 'Our IoT Clients',
    Icon: SignalIcon,
    keyClient: 'Maithri Aquatech',
    rolling: true,
    logos: [
      { src: gayamMotor, alt: 'Gayam Motor Works', name: 'Gayam Motor Works' },
      { src: maithriAquatech, alt: 'Maithri Aquatech', name: 'Maithri Aquatech' },
      { src: inglo, alt: 'Inglo', name: 'Inglo' },
      { src: beyondWater, alt: 'Beyond Water', name: 'Beyond Water' },
      { src: drdo, alt: 'DRDO', name: 'DRDO' },
      { src: sfs, alt: 'SFS', name: 'SFS' },
      { src: kistlerMorse, alt: 'Kistler-Morse Automation Limited', name: 'Kistler-Morse Automation Limited' },
    ],
  },
]

function TrustedBy() {
  return (
    <section className="trusted-by">
      <div className="trusted-by__header">
        <h2 className="trusted-by__title">Trusted By Leading Organizations</h2>
        <span className="trusted-by__rule" aria-hidden="true" />
      </div>

      <div className="trusted-by__groups">
        {GROUPS.map(({ id, label, Icon, logos, rolling }) => (
          <div className="trusted-by__group" key={id}>
            <div className="trusted-by__tag">
              <span className="trusted-by__tag-icon">
                <Icon />
              </span>
              <span className="trusted-by__tag-text">
                <span className="trusted-by__tag-label">{label}</span>
                {!rolling && <span className="trusted-by__tag-client">Client</span>}
              </span>
            </div>

            {rolling ? (
              <div className="trusted-by__row trusted-by__row--rolling">
                <div
                  className="trusted-by__track"
                  style={{
                    '--logo-count': logos.length,
                    animationDuration: `${logos.length * 1}s`,
                  }}
                >
                  {[...logos, ...logos].map((logo, i) => (
                    <div className="trusted-by__card" key={`${logo.alt}-${i}`}>
                      <img className="trusted-by__logo" src={logo.src} alt={logo.alt} loading="lazy" />
                      <span className="trusted-by__label">{logo.name}</span>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="trusted-by__row">
                {logos.map((logo) => (
                  <div className="trusted-by__card" key={logo.alt}>
                    <img className="trusted-by__logo" src={logo.src} alt={logo.alt} loading="lazy" />
                    <span className="trusted-by__label">{logo.name}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </section>
  )
}

export default TrustedBy
