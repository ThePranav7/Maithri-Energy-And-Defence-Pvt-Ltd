import React from 'react';

export default function FeatureItem({ icon, title, description, showDivider }) {
  return (
    <div className={`wcu-feature-item${showDivider ? ' with-divider' : ''}`}>
      <div className="wcu-icon-wrap">{icon}</div>
      <h3 className="wcu-item-title">{title}</h3>
      <p className="wcu-item-desc">{description}</p>
    </div>
  );
}
