import React from 'react';
import FeatureItem from './FeatureItem.jsx';
import {
  TechIcon,
  ReliableIcon,
  SupportIcon,
  EngineeringIcon,
  QualityIcon,
} from './icons.jsx';
import './WhyChooseUs.css';

const features = [
  {
    icon: <TechIcon />,
    title: 'Advanced Technology',
    description: 'Cutting-edge R&D and engineering excellence.',
  },
  {
    icon: <ReliableIcon />,
    title: 'Reliable Solutions',
    description: 'Built for extreme conditions and mission-critical needs.',
  },
  {
    icon: <SupportIcon />,
    title: 'End-to-End Support',
    description: 'From concept to commissioning and beyond.',
  },
  {
    icon: <EngineeringIcon />,
    title: 'Custom Engineering',
    description: 'Tailored solutions for unique business requirements.',
  },
  {
    icon: <QualityIcon />,
    title: 'Quality & Safety',
    description: 'International standards with uncompromising quality.',
  },
];

export default function WhyChooseUs() {
  return (
    <section className="why-choose-us">
      <h2 className="title">Why Choose Us</h2>
      <div className="grid">
        {features.map((feature, index) => (
          <FeatureItem
            key={feature.title}
            icon={feature.icon}
            title={feature.title}
            description={feature.description}
            showDivider={index !== features.length - 1}
          />
        ))}
      </div>
    </section>
  );
}
