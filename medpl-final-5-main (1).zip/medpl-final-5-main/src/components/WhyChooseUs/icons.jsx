import React from 'react';

const iconProps = {
  viewBox: '0 0 64 64',
  fill: 'none',
  stroke: '#0b1d3a',
  strokeWidth: 2,
};

export function TechIcon() {
  return (
    <svg {...iconProps}>
      <path d="M32 6 L54 14 V30 C54 44 44 54 32 58 C20 54 10 44 10 30 V14 Z" strokeLinejoin="round" />
      <circle cx="32" cy="27" r="6" />
      <path d="M22 42 C22 34 42 34 42 42" strokeLinecap="round" />
    </svg>
  );
}

export function ReliableIcon() {
  return (
    <svg {...iconProps}>
      <circle cx="32" cy="32" r="24" />
      <path d="M21 32 L29 40 L45 22" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function SupportIcon() {
  return (
    <svg {...iconProps}>
      <circle cx="32" cy="32" r="24" />
      <ellipse cx="32" cy="32" rx="10" ry="24" />
      <line x1="8" y1="32" x2="56" y2="32" />
      <path d="M11 20 H53" strokeLinecap="round" />
      <path d="M11 44 H53" strokeLinecap="round" />
    </svg>
  );
}

export function EngineeringIcon() {
  return (
    <svg {...iconProps}>
      <circle cx="32" cy="32" r="9" />
      <path
        d="M32 8 V16 M32 48 V56 M8 32 H16 M48 32 H56
           M15.5 15.5 L21 21 M43 43 L48.5 48.5
           M15.5 48.5 L21 43 M43 21 L48.5 15.5"
        strokeLinecap="round"
      />
    </svg>
  );
}

export function QualityIcon() {
  return (
    <svg {...iconProps}>
      <path d="M32 6 L54 14 V30 C54 44 44 54 32 58 C20 54 10 44 10 30 V14 Z" strokeLinejoin="round" />
      <path d="M23 31 L29 37 L41 24" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
