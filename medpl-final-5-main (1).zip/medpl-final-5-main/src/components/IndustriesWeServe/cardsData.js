import card1 from './assets/card_1.webp';
import card2 from './assets/card_2.webp';
import card3 from './assets/card_3.webp';
import card4 from './assets/card_4.webp';
import card5 from './assets/card_5.webp';
import card6 from './assets/card_6.webp';
import card7 from './assets/card_7.webp';

const cardsData = [
  {
    id: 1,
    image: card1,
    alt: 'Electric vehicle battery pack and BMS',
    title: 'Electric Vehicles',
    description:
      'Advanced Li-ion battery packs and BMS engineered for electric mobility, delivering dependable performance, thermal safety, extended cycle life, and intelligent battery monitoring.',
    link: '/products/industrial/li-ion',
  },
  {
    id: 2,
    image: card2,
    alt: 'Li-ion battery pack and BMS for material handling equipment',
    title: 'Material Handling',
    description:
      'High-performance Li-ion battery systems for forklifts and warehouse equipment, designed for reliable operation, fast charging, long runtime, and reduced maintenance.',
    link: '/products/industrial/li-ion',
  },
  {
    id: 3,
    image: card3,
    alt: 'Battery energy storage system and UPS',
    title: 'Grid & Backup Power',
    description:
      'Scalable energy storage and backup power solutions that support industrial and commercial operations with reliable power availability, energy efficiency, and continuity.',
    link: '/products/industrial/power-system',
  },
  {
    id: 4,
    image: card4,
    alt: 'HEAUV autonomous underwater vehicle',
    title: 'Defense — Underwater',
    tabTitle: 'Underwater',
    description:
      'Compact, high-reliability power systems engineered for underwater platforms such as HEAUV, supporting long-duration autonomous missions and delivered to NSTL, DRDO.',
    link: '/products/defense',
  },
  {
    id: 5,
    image: card5,
    alt: 'Armored ground vehicle with power system',
    title: 'Defense — Ground',
    tabTitle: 'Ground',
    description:
      'Rugged battery and power solutions built for demanding ground applications, including LORROS and MPATGM, with emphasis on reliability, durability, and mission readiness.',
    link: '/products/defense',
  },
  {
    id: 6,
    image: card6,
    alt: 'Fighter jet with aerospace power system',
    title: 'Defense — Aerospace',
    tabTitle: 'Aerospace',
    description:
      "Lightweight, high-reliability power systems developed for aerospace defense applications, including the Decoy System associated with DRDO's Agni Missile Programme.",
    link: '/products/defense',
  },
  {
    id: 7,
    image: card7,
    alt: 'MEGIoT controller and AquaViz monitoring platform',
    title: 'Smart Infrastructure / IoT',
    description:
      'Intelligent MEGIoT controllers and the AquaViz platform enable connected monitoring, automation, and data-driven operation across systems including Atmospheric Water Generators.',
    link: '/products/iot',
  },
];

export default cardsData;
