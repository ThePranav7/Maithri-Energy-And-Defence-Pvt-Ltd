import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import cardsData from './cardsData';
import './IndustriesWeServe.css';

const AUTO_INTERVAL = 4500;

export default function IndustriesWeServe() {
  const navigate = useNavigate();
  const [activeIndex, setActiveIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const active = cardsData[activeIndex];
  const timerRef = useRef(null);

  const goPrev = () =>
    setActiveIndex((i) => (i === 0 ? cardsData.length - 1 : i - 1));

  const goNext = () =>
    setActiveIndex((i) => (i === cardsData.length - 1 ? 0 : i + 1));

  useEffect(() => {
    if (isPaused) return undefined;
    timerRef.current = setInterval(() => {
      setActiveIndex((i) => (i === cardsData.length - 1 ? 0 : i + 1));
    }, AUTO_INTERVAL);
    return () => clearInterval(timerRef.current);
  }, [isPaused]);

  return (
    <div className="iws-section">
      <div className="iws-grid">
        {/* LEFT: headline + subtext only */}
        <div className="iws-left">
          <h2 className="iws-headline">Industries we serve.</h2>
          <p className="iws-subtext">
            From mobility to defense, MEDPL powers the systems that keep
            critical operations running.
          </p>

          <div className="iws-dots">
            {cardsData.map((card, i) => (
              <button
                key={card.id}
                className={`iws-dot ${i === activeIndex ? 'active' : ''}`}
                onClick={() => setActiveIndex(i)}
                aria-label={card.tabTitle || card.title}
              />
            ))}
          </div>
        </div>

        {/* RIGHT: carousel */}
        <div className="iws-right">
          <div
            className="iws-carousel"
            onMouseEnter={() => setIsPaused(true)}
            onMouseLeave={() => setIsPaused(false)}
          >
            <div
              key={active.id}
              className="iws-slide"
              style={{ backgroundImage: `url(${active.image})` }}
            >
              <div className="iws-slide-overlay" />

              <div className="iws-slide-content">
                <h3 className="iws-title">{active.title}</h3>
                <p className="iws-desc">{active.description}</p>

                <button
                  className="iws-cta"
                  onClick={() => {
                    if (active.link) {
                      navigate(active.link);
                      window.scrollTo(0, 0);
                    }
                  }}
                >
                  Know More
                  <svg
                    className="iws-cta-arrow"
                    width="18"
                    height="18"
                    viewBox="0 0 24 24"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M5 12h14M13 6l6 6-6 6"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </button>
              </div>

              <button
                className="iws-nav iws-nav-prev"
                onClick={goPrev}
                aria-label="Previous industry"
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                  <path
                    d="M15 6l-6 6 6 6"
                    stroke="currentColor"
                    strokeWidth="2.2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </button>
              <button
                className="iws-nav iws-nav-next"
                onClick={goNext}
                aria-label="Next industry"
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                  <path
                    d="M9 6l6 6-6 6"
                    stroke="currentColor"
                    strokeWidth="2.2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
