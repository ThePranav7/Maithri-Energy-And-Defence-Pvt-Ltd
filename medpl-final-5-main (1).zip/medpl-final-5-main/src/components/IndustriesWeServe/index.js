export { default } from './IndustriesWeServe';
