import React from 'react';
import { Link } from 'react-router-dom';
import NewsCard from './NewsCard.jsx';
import './NewsInsights.css';

const newsItems = [
  {
    date: 'May 02, 2024',
    title: 'Advancements in Energy Storage System for Industrial Applications',
    imageAlt: 'Energy storage containers at sunset',
  },
  {
    date: 'Apr 18, 2024',
    title: 'High Performance BMS for Next Gen Battery Systems',
    imageAlt: 'Battery management system circuit board',
  },
  {
    date: 'Mar 15, 2024',
    title: 'Empowering Autonomous Defense Platforms with Confidence',
    imageAlt: 'Drone flying over mountains',
  },
];

export default function NewsInsights() {
  return (
    <section className="news-insights">
      <div className="news-header">
        <div>
          <h2 className="news-heading">News &amp; Insights</h2>
          <p className="news-subheading">
            Stay updated with our latest news, innovations and industry insights.
          </p>
        </div>
        <Link className="view-all-btn" to="/news" onClick={() => window.scrollTo(0, 0)}>
          VIEW ALL NEWS
        </Link>
      </div>

      <div className="news-grid">
        {newsItems.map((item) => (
          <NewsCard
            key={item.title}
            date={item.date}
            title={item.title}
            imageAlt={item.imageAlt}
          />
        ))}
      </div>
    </section>
  );
}
