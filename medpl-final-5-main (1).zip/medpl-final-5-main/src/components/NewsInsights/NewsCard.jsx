import React from 'react';
import { Link } from 'react-router-dom';

export default function NewsCard({ date, title, imageAlt }) {
  return (
    <div className="news-card">
      <div className="news-image" role="img" aria-label={imageAlt}></div>
      <div className="news-body">
        <span className="news-date">{date}</span>
        <h3 className="news-title">{title}</h3>
        <Link className="read-more" to="/news" onClick={() => window.scrollTo(0, 0)}>
          READ MORE <span className="arrow">→</span>
        </Link>
      </div>
    </div>
  );
}
