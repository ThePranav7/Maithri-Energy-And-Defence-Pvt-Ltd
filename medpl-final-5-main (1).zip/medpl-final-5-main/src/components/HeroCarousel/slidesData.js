import slide1Image from '../../assets/slides/slide-1-product-collage.webp'
import slide2Image from '../../assets/slides/slide-2-energy-storage.webp'
import slide3Image from '../../assets/slides/slide-3-iot-network.webp'
import slide4Image from '../../assets/slides/slide-4-storage-skyline.webp'
import slide5Image from '../../assets/slides/slide-5-defense-port.webp'
import slide6Image from '../../assets/slides/slide-6-riverside-storage.webp'

/**
 * The hero text/CTA content is fixed and shared across every slide.
 * Only the background image rotates automatically.
 */
export const heroContent = {
  title: ['Powering Industry.', 'Securing Defense.', 'Enabling Intelligence.'],
  description:
    'Maithri Energy & Defense Pvt. Ltd. is an ISO-certified technology company with expertise in energy systems, defense technologies, and IoT solutions. We design and develop Lithium-ion and Sodium-ion battery systems engineered for demanding applications and diverse operating conditions. Our solutions are focused on safety, reliability, and performance across industrial and defense applications — on land, at sea, and in the air.',
  primaryCta: 'Explore Our Solutions',
  secondaryCta: 'Get in Touch',
}

const images = [
  {
    id: 1,
    image: slide1Image,
    imageAlt: 'Rooftop solar panel array at sunrise with wind turbines and mountains in the background',
  },
  {
    id: 2,
    image: slide2Image,
    imageAlt: 'Row of Maithri energy storage containers on a rooftop garden with a city skyline behind',
  },
  {
    id: 3,
    image: slide3Image,
    imageAlt: 'City skyline overlaid with a connected IoT network of sensors, cloud, and communication icons',
  },
  {
    id: 4,
    image: slide4Image,
    imageAlt: 'Industrial facility exterior with outdoor electrical switchgear and storage tanks',
  },
  {
    id: 5,
    image: slide5Image,
    imageAlt: 'Naval defense installation at a port with aircraft overhead, a warship, and military vehicles',
  },
  {
    id: 6,
    image: slide6Image,
    imageAlt: 'Maithri energy storage containers beside a riverside promenade with a city skyline',
  },
]

export default images
