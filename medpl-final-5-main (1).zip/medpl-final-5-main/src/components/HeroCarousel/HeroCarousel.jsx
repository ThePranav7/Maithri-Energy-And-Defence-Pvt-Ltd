import { useEffect, useRef, useState } from 'react'
import images, { heroContent } from './slidesData.js'
import './HeroCarousel.css'

const AUTOPLAY_MS = 5000

export default function HeroCarousel() {
  const [activeIndex, setActiveIndex] = useState(0)
  const timerRef = useRef(null)

  useEffect(() => {
    timerRef.current = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % images.length)
    }, AUTOPLAY_MS)
    return () => clearInterval(timerRef.current)
  }, [])

  const current = images[activeIndex]

  const goToSlide = (index) => {
    setActiveIndex(index)
    // restart the autoplay timer so a manual click doesn't get
    // immediately overridden by a pending tick
    clearInterval(timerRef.current)
    timerRef.current = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % images.length)
    }, AUTOPLAY_MS)
  }

  return (
    <section
      className="hero-carousel"
      aria-roledescription="carousel"
      aria-label="Maithri Energy & Defense highlights"
    >
      <div className="hero-carousel__inner hero-carousel__inner--card">
        <div className="card-slide">
          <img
            key={current.id}
            src={current.image}
            alt={current.imageAlt}
            className="card-slide__image"
          />
          <div className="card-slide__overlay" />

          <div className="card-slide__content">
            <h2 className="card-slide__title">
              {heroContent.title.map((line) => (
                <span key={line} className="card-slide__title-line">
                  {line}
                </span>
              ))}
            </h2>
            <p className="card-slide__description">{heroContent.description}</p>
          </div>

          <nav className="hero-carousel__dots" aria-label="Slide navigation">
            {images.map((slide, index) => (
              <button
                key={slide.id}
                type="button"
                className={
                  'hero-carousel__dot' +
                  (index === activeIndex ? ' hero-carousel__dot--active' : '')
                }
                aria-label={`Go to slide ${index + 1}`}
                aria-current={index === activeIndex}
                onClick={() => goToSlide(index)}
              />
            ))}
          </nav>
        </div>
      </div>
    </section>
  )
}
