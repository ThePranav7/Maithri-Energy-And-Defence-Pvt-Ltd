export const stats = [
  { id: "incorporated", target: 2015, prefix: "", suffix: "", label: "Incorporated" },
  { id: "verticals", target: 3, prefix: "", suffix: "", label: "Core Verticals" },
  { id: "capacity", target: 1, prefix: "", suffix: " MWh", label: "Monthly Capacity" },
  { id: "facility", target: 25, prefix: "", suffix: "K sq. ft.", label: "Facility" },
  { id: "engineers", target: 18, prefix: "", suffix: "", label: "In-House Engineers" },
  { id: "rnd", target: 350, prefix: "", suffix: "+", label: "Man-Years R&D" },
  { id: "domains", target: 7, prefix: "", suffix: "", label: "Capability Domains" },
];
