import { useCountUp } from "./hooks/useCountUp";

export default function StatItem({ target, prefix = "", suffix = "", label, delay = 0 }) {
  const { ref, value, inView } = useCountUp(target);

  return (
    <div
      ref={ref}
      className={`stat${inView ? " stat--in-view" : ""}`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      <div className="stat__value">
        {prefix}
        {value}
        {suffix}
      </div>
      <div className="stat__label">{label}</div>
    </div>
  );
}
