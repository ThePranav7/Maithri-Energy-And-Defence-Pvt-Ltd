import StatItem from "./StatItem";
import { stats } from "./data/stats";
import "./StatsCounter.css";

export default function StatsCounter() {
  return (
    <div className="stats-wrap">
      <div className="stats">
        {stats.map((stat, i) => (
          <StatItem
            key={stat.id}
            target={stat.target}
            prefix={stat.prefix}
            suffix={stat.suffix}
            label={stat.label}
            delay={i * 70}
          />
        ))}
      </div>
    </div>
  );
}
