import { useEffect, useRef, useState } from "react";

/**
 * Animates a number from 0 to `target` once the returned ref
 * scrolls into view. Uses an ease-out curve and only fires once.
 *
 * @param {number} target - final value to count up to
 * @param {object} options
 * @param {number} options.duration - animation length in ms (default 1600)
 * @param {number} options.threshold - IntersectionObserver threshold (default 0.4)
 */
export function useCountUp(
  target,
  { duration = 1600, threshold = 0.4, replay = true } = {}
) {
  const [value, setValue] = useState(0);
  const [inView, setInView] = useState(false);
  const ref = useRef(null);
  const frameRef = useRef(null);

  useEffect(() => {
    const node = ref.current;
    if (!node) return;

    const prefersReducedMotion = window.matchMedia(
      "(prefers-reduced-motion: reduce)"
    ).matches;

    const runCount = () => {
      if (frameRef.current) cancelAnimationFrame(frameRef.current);

      if (prefersReducedMotion) {
        setValue(target);
        return;
      }

      let start = null;
      const easeOutExpo = (t) => (t === 1 ? 1 : 1 - Math.pow(2, -10 * t));

      const step = (timestamp) => {
        if (start === null) start = timestamp;
        const progress = Math.min((timestamp - start) / duration, 1);
        const eased = easeOutExpo(progress);
        setValue(Math.round(eased * target));
        if (progress < 1) {
          frameRef.current = requestAnimationFrame(step);
        } else {
          setValue(target);
        }
      };
      frameRef.current = requestAnimationFrame(step);
    };

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setInView(true);
            runCount();
            if (!replay) observer.unobserve(node);
          } else if (replay) {
            // Reset so the next scroll-in plays the count-up again
            setInView(false);
            if (frameRef.current) cancelAnimationFrame(frameRef.current);
            setValue(0);
          }
        });
      },
      { threshold }
    );

    observer.observe(node);
    return () => {
      observer.disconnect();
      if (frameRef.current) cancelAnimationFrame(frameRef.current);
    };
  }, [target, duration, threshold, replay]);

  return { ref, value, inView };
}
