import industrialEnergy from "../../assets/solutions-preview/industrial-energy.webp";
import industrialEvBms from "../../assets/solutions-preview/industrial-ev-bms.webp";
import industrialLiionBms from "../../assets/solutions-preview/industrial-liion-bms.webp";
import defenseSystems from "../../assets/solutions-preview/defense-systems.webp";
import defenseArmoredVehicle from "../../assets/solutions-preview/defense-armored-vehicle.webp";
import defenseHeauv from "../../assets/solutions-preview/defense-heauv.webp";
import iotSolutions from "../../assets/solutions-preview/iot-solutions.webp";
import iotAquavizDashboard from "../../assets/solutions-preview/iot-aquaviz-dashboard.webp";
import iotMegiotStorage from "../../assets/solutions-preview/iot-megiot-storage.webp";

const solutions = [
  {
    eyebrow: "INDUSTRIAL",
    title: "Energy Solutions",
    description:
      "Advanced energy solutions engineered for safe, reliable and efficient performance in demanding industrial environments.",
    images: [industrialEnergy, industrialEvBms, industrialLiionBms],
    items: [],
    cta: "Explore",
    href: "/products/industrial#industrial-categories",
  },
  {
    eyebrow: "DEFENSE",
    title: "Defense Systems",
    description:
      "Mission-Ready Technology: Purpose-driven technologies developed to support mission readiness, operational capability and performance in critical defense applications.",
    images: [defenseSystems, defenseArmoredVehicle, defenseHeauv],
    items: [],
    cta: "Explore",
    href: "/products/defense#defense-portfolio",
  },
  {
    eyebrow: "IOT",
    title: "IoT Solutions",
    description:
      "Connecting Technology with Intelligence: Seamlessly integrating connected systems, real-time data and intelligent control to enable smarter, more efficient operations.",
    images: [iotSolutions, iotAquavizDashboard, iotMegiotStorage],
    items: [],
    cta: "Explore",
    href: "/products/iot#iot-showcase",
  },
];

export default solutions;
