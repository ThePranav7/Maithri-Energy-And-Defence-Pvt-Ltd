import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import solutions from "./data";
import "./SolutionsPreview.css";

const ROTATE_MS = 5000;

const ICON_COMMON = {
  width: 15,
  height: 15,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.8,
  strokeLinecap: "round",
  strokeLinejoin: "round",
};

const Icon = ({ type }) => {
  switch (type) {
    case "battery":
      return (
        <svg {...ICON_COMMON}>
          <rect x="2" y="7" width="17" height="10" rx="1.5" />
          <line x1="21" y1="10" x2="21" y2="14" />
          <line x1="6" y1="10" x2="6" y2="14" />
        </svg>
      );
    case "plug":
      return (
        <svg {...ICON_COMMON}>
          <path d="M9 2v4M15 2v4" />
          <path d="M6 6h12v4a6 6 0 0 1-12 0V6z" />
          <path d="M12 16v3" />
          <path d="M9 21h6" />
        </svg>
      );
    case "shield":
      return (
        <svg {...ICON_COMMON}>
          <path d="M12 2l8 3v6c0 5-3.5 8.5-8 11-4.5-2.5-8-6-8-11V5l8-3z" />
          <path d="M9 12l2 2 4-4" />
        </svg>
      );
    case "clock":
      return (
        <svg {...ICON_COMMON}>
          <circle cx="12" cy="12" r="9" />
          <path d="M12 7v5l3 3" />
        </svg>
      );
    case "person":
      return (
        <svg {...ICON_COMMON}>
          <circle cx="12" cy="8" r="3.2" />
          <path d="M5 20c0-3.5 3-6 7-6s7 2.5 7 6" />
        </svg>
      );
    case "controller":
      return (
        <svg {...ICON_COMMON}>
          <path d="M4 12h4M6 10v4" />
          <circle cx="16" cy="10.5" r="1" fill="currentColor" stroke="none" />
          <circle cx="18.5" cy="13" r="1" fill="currentColor" stroke="none" />
          <rect x="2" y="8" width="20" height="9" rx="4.5" />
        </svg>
      );
    case "server":
      return (
        <svg {...ICON_COMMON}>
          <rect x="3" y="4" width="18" height="6" rx="1.2" />
          <rect x="3" y="14" width="18" height="6" rx="1.2" />
          <circle cx="7" cy="7" r="0.6" fill="currentColor" stroke="none" />
          <circle cx="7" cy="17" r="0.6" fill="currentColor" stroke="none" />
        </svg>
      );
    default:
      return null;
  }
};

const SolutionsCard = ({ item }) => {
  const [imgIndex, setImgIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setImgIndex((prev) => (prev + 1) % item.images.length);
    }, ROTATE_MS);
    return () => clearInterval(timer);
  }, [item.images.length]);

  return (
    <Link to={item.href || "#"} className="solutions-card" key={item.title}>
      <div
        key={imgIndex}
        className="solutions-card__image"
        style={{ backgroundImage: `url(${item.images[imgIndex]})` }}
      />
      <div className="solutions-card__overlay" />

      <div className="solutions-card__content">
        <span className="solutions-card__category">{item.eyebrow}</span>

        <h3 className="solutions-card__title">{item.title}</h3>

        <p className="solutions-card__description">{item.description}</p>

        {item.items && item.items.length > 0 && (
          <ul className="solutions-card__list">
            {item.items.map((sub) => (
              <li key={sub.label}>
                <span className="solutions-card__list-icon">
                  <Icon type={sub.icon} />
                </span>
                <span>{sub.label}</span>
              </li>
            ))}
          </ul>
        )}

        <span className="solutions-card__cta">
          {item.cta || "Explore"}
          <svg
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M5 12H19M19 12L13 6M19 12L13 18"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </span>
      </div>
    </Link>
  );
};

const SolutionsPreview = () => {
  return (
    <section className="solutions-preview">
      <div className="solutions-preview__header">
        <h2 className="solutions-preview__title">Our Product Categories</h2>
        <p className="solutions-preview__subtitle">
          Where knowledge becomes innovation and innovation creates impact.
        </p>
      </div>

      <div className="solutions-preview__grid">
        {solutions.map((item) => (
          <SolutionsCard item={item} key={item.title} />
        ))}
      </div>
    </section>
  );
};

export default SolutionsPreview;
