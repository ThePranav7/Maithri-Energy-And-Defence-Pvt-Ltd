import React, { useEffect, useRef, useState, useCallback } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import Logo from "./Logo";
import productsData from "./productsData";
import {
  HomeIcon,
  InfoIcon,
  ProductsIcon,
  NewsIcon,
  CareersIcon,
  ContactIcon,
  Caret,
  ArrowRight
} from "./icons";
import "./Navbar.css";

const NAV_ITEMS = [
  { name: "Home", icon: HomeIcon, path: "/" },
  { name: "Products", icon: ProductsIcon, menu: "products", path: "/products" },
  { name: "News & Blog", icon: NewsIcon, path: "/news" },
  { name: "About Us", icon: InfoIcon, menu: "about", path: "/about" },
  { name: "Careers", icon: CareersIcon, path: "/careers" },
  { name: "Contact Us", icon: ContactIcon, path: "/contact", divider: true }
];

const ABOUT_LINKS = [
  { label: "Company Overview", hash: "about-overview" },
  { label: "Leadership Team", hash: "leadership" },
  { label: "Mission, Vision & Core Values", hash: "mission" }
];

export default function Navbar() {
  const navigate = useNavigate();
  const location = useLocation();
  const [activeName, setActiveName] = useState("Home");
  const [openMenu, setOpenMenu] = useState(null); // "about" | "products" | null
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  const dockRef = useRef(null);
  const selectorRef = useRef(null);
  const itemRefs = useRef(new Map());

  // Navbar is always shown with a solid white background (no
  // transparent/see-through state over hero banners).
  const isTransparent = false;

  const setItemRef = (name) => (el) => {
    if (el) itemRefs.current.set(name, el);
    else itemRefs.current.delete(name);
  };

  const syncBg = useCallback(() => {
    const dock = dockRef.current;
    const bg = selectorRef.current;
    const activeEl = itemRefs.current.get(activeName);
    if (!dock || !bg || !activeEl) return;

    const dockRect = dock.getBoundingClientRect();
    const r = activeEl.getBoundingClientRect();

    bg.style.left = `${r.left - dockRect.left}px`;
    bg.style.top = `${r.top - dockRect.top}px`;
    bg.style.width = `${r.width}px`;
    bg.style.height = `${r.height}px`;
    bg.style.opacity = "1";
  }, [activeName]);

  // keep the pill glued to the active item, including while its width
  // eases open/closed or the window resizes
  useEffect(() => {
    syncBg();

    const ro = new ResizeObserver(() => syncBg());
    itemRefs.current.forEach((el) => ro.observe(el));

    window.addEventListener("resize", syncBg);
    return () => {
      ro.disconnect();
      window.removeEventListener("resize", syncBg);
    };
  }, [syncBg]);

  // close any open dropdown on an outside click
  useEffect(() => {
    const handleDocClick = () => setOpenMenu(null);
    document.addEventListener("click", handleDocClick);
    return () => document.removeEventListener("click", handleDocClick);
  }, []);

  // solid background as soon as the first section of the current page has
  // scrolled past the navbar; transparent again whenever that first
  // section is back in view (covers every page, not just Home)
  useEffect(() => {
    const NAVBAR_VISIBLE_HEIGHT = 76;

    const handleScroll = () => {
      const heroEl = document.querySelector(
        ".hero-carousel, .hero, .products-hero, .industrial-hero, .dps-hero, .banner, .news-banner, .careers-hero, .contact-hero"
      );
      if (heroEl) {
        const bottom = heroEl.getBoundingClientRect().bottom;
        setScrolled(bottom <= NAVBAR_VISIBLE_HEIGHT);
      } else {
        setScrolled(window.scrollY > NAVBAR_VISIBLE_HEIGHT);
      }
    };

    handleScroll();
    window.addEventListener("scroll", handleScroll, { passive: true });
    window.addEventListener("resize", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
      window.removeEventListener("resize", handleScroll);
    };
  }, [location.pathname]);

  // reset scroll position whenever the route changes so the bar is
  // correctly transparent for the top of the page just landed on
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location.pathname]);

  // close the mobile menu whenever the route changes
  useEffect(() => {
    setMobileOpen(false);
    setOpenMenu(null);
  }, [location.pathname]);

  // prevent the page behind the mobile menu from scrolling while it's open
  useEffect(() => {
    document.body.style.overflow = mobileOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [mobileOpen]);

  useEffect(() => {
    if (!mobileOpen) return undefined;
    const handleEscape = (event) => {
      if (event.key === "Escape") {
        setMobileOpen(false);
        setOpenMenu(null);
      }
    };
    document.addEventListener("keydown", handleEscape);
    return () => document.removeEventListener("keydown", handleEscape);
  }, [mobileOpen]);

  // keep the active pill correct on back/forward navigation, direct loads,
  // and clicks that land on a sub-route (e.g. /products/industrial,
  // /products/industrial/li-ion, /about) rather than the exact nav path
  useEffect(() => {
    const path = location.pathname;
    // prefer the most specific (longest) matching path so "/products"
    // doesn't win over a more specific future entry, and so "/" only
    // matches the exact home route
    const match = NAV_ITEMS.filter((item) => item.path !== "/")
      .filter((item) => path === item.path || path.startsWith(`${item.path}/`))
      .sort((a, b) => b.path.length - a.path.length)[0];

    if (match) {
      setActiveName(match.name);
    } else if (path === "/") {
      setActiveName("Home");
    }
  }, [location.pathname]);

  const goHome = (e) => {
    e.preventDefault();
    setOpenMenu(null);
    setActiveName("Home");
    if (location.pathname === "/") {
      window.scrollTo({ top: 0, behavior: "smooth" });
    } else {
      navigate("/");
    }
  };

  // hover intent: open immediately, close after a short delay so the
  // cursor can travel from the label down into the panel without it
  // snapping shut
  const closeTimer = useRef(null);

  const clearCloseTimer = () => {
    if (closeTimer.current) {
      clearTimeout(closeTimer.current);
      closeTimer.current = null;
    }
  };

  const handleItemEnter = (item) => {
    if (!item.menu || mobileOpen) return;
    clearCloseTimer();
    setOpenMenu(item.menu);
  };

  const handleItemLeave = (item) => {
    if (!item.menu || mobileOpen) return;
    clearCloseTimer();
    closeTimer.current = setTimeout(() => setOpenMenu(null), 150);
  };

  const handleItemClick = (item, e) => {
    if (item.name === "Home") {
      goHome(e);
      return;
    }
    e.stopPropagation();

    if (item.menu && mobileOpen) {
      setOpenMenu((current) => (current === item.menu ? null : item.menu));
      setActiveName(item.name);
      return;
    }

    setOpenMenu(null);
    setMobileOpen(false);
    setActiveName(item.name);
    if (item.path) {
      if (location.pathname === item.path) {
        // already on this page — click just scrolls back to the top,
        // same as clicking Home
        window.scrollTo({ top: 0, behavior: "smooth" });
      } else {
        navigate(item.path);
      }
    }
  };

  const handleItemKeyDown = (item, e) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      handleItemClick(item, e);
    }
    if (e.key === "Escape") {
      setOpenMenu(null);
    }
  };

  // About Us dropdown links jump straight to their section instead of
  // just landing on the top of the page
  const NAVBAR_OFFSET = 90;

  const scrollToId = (hash) => {
    const el = document.getElementById(hash);
    if (el) {
      const top = el.getBoundingClientRect().top + window.scrollY - NAVBAR_OFFSET;
      window.scrollTo({ top, behavior: "smooth" });
    }
  };

  const handleAboutLinkClick = (hash, e) => {
    e.preventDefault();
    e.stopPropagation();
    setOpenMenu(null);
    setMobileOpen(false);
    setActiveName("About Us");
    if (location.pathname === "/about") {
      scrollToId(hash);
    } else {
      navigate(`/about#${hash}`);
    }
  };

  return (
    <>
    <div className={"stage" + (isTransparent ? "" : " solid")}>
      <header className="dock-bar">
        <Logo onClick={goHome} />

        <button
          type="button"
          className={"nav-hamburger" + (mobileOpen ? " is-open" : "")}
          aria-label={mobileOpen ? "Close menu" : "Open menu"}
          aria-expanded={mobileOpen}
          aria-controls="primary-navigation"
          onClick={(e) => {
            e.stopPropagation();
            setMobileOpen((prev) => {
              if (prev) setOpenMenu(null);
              return !prev;
            });
          }}
        >
          <span />
          <span />
          <span />
        </button>

        <nav
          id="primary-navigation"
          className={"dock" + (mobileOpen ? " mobile-open" : "")}
          ref={dockRef}
          onClick={(e) => e.stopPropagation()}
        >
          <span className="selector-bg" ref={selectorRef} />

          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = activeName === item.name;
            const isMenuOpen = openMenu === item.menu;

            return (
              <React.Fragment key={item.name}>
                <div
                  ref={setItemRef(item.name)}
                  className={
                    "item" +
                    (isActive ? " active" : "") +
                    (isMenuOpen ? " menu-open" : "") +
                    (item.menu ? " has-submenu" : "") +
                    (item.name === "Contact Us" ? " item-cta" : "")
                  }
                  onMouseEnter={() => handleItemEnter(item)}
                  onMouseLeave={() => handleItemLeave(item)}
                >
                  <span className="halo" />
                    <span
                      className="row"
                      role="button"
                      tabIndex={0}
                      aria-haspopup={item.menu ? "true" : undefined}
                      aria-expanded={item.menu ? isMenuOpen : undefined}
                      onClick={(e) => handleItemClick(item, e)}
                      onKeyDown={(e) => handleItemKeyDown(item, e)}
                    >
                    <span className="icon">
                      <Icon />
                    </span>
                    <span className="label">{item.name}</span>
                    {item.menu && <Caret />}
                    {item.name === "Contact Us" && (
                      <span className="cta-arrow">
                        <ArrowRight />
                      </span>
                    )}
                  </span>

                  {item.menu === "about" && (
                    <div
                      className="panel about-panel"
                      onClick={(e) => e.stopPropagation()}
                    >
                      {ABOUT_LINKS.map((link) => (
                        <a
                          className="plain"
                          href={`/about#${link.hash}`}
                          key={link.hash}
                          onClick={(e) => handleAboutLinkClick(link.hash, e)}
                        >
                          {link.label}
                        </a>
                      ))}
                    </div>
                  )}

                  {item.menu === "products" && (
                    <div
                      className="panel about-panel"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <Link
                        className="plain products-portfolio-link"
                        to="/products"
                        onClick={(e) => {
                          e.stopPropagation();
                          setOpenMenu(null);
                          setMobileOpen(false);
                          setActiveName(item.name);
                        }}
                      >
                        Products & Solutions
                      </Link>
                      {productsData.map((col) => {
                        const target =
                          col.category === "industrial"
                            ? "/products/industrial"
                            : col.category === "defense"
                            ? "/products/defense"
                            : col.category === "iot"
                            ? "/products/iot"
                            : "/products";
                        return (
                          <a
                            className="plain"
                            href={target}
                            key={col.title}
                            onClick={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              setOpenMenu(null);
                              setMobileOpen(false);
                              setActiveName(item.name);
                              navigate(target);
                            }}
                          >
                            {col.title}
                          </a>
                        );
                      })}
                    </div>
                  )}
                </div>

                {item.divider && <div className="divider" />}
              </React.Fragment>
            );
          })}
        </nav>
      </header>
    </div>
    {mobileOpen && (
      <div
        className="nav-mobile-backdrop"
        onClick={() => setMobileOpen(false)}
      />
    )}
    </>
  );
}
