const productsData = [
  {
    title: "Industrial",
    category: "industrial"
  },
  {
    title: "Defense",
    category: "defense",
    entries: [
      { name: "Underwater" },
      { name: "Ground" },
      { name: "Aerospace" }
    ]
  },
  {
    title: "IoT",
    category: "iot",
    entries: [
      { name: "Controller for AWG" },
      { name: "Server Front-End Solution" }
    ]
  }
];

export default productsData;
