import React from "react";
import { Link } from "react-router-dom";
import maithriSymbol from "../../assets/maithri-symbol.webp";

export default function Logo({ onClick }) {
  return (
    <Link to="/" className="logo" onClick={onClick}>
      <img src={maithriSymbol} alt="Maithri symbol" className="logo-mark" />
      <span className="logo-text">
        MAITHRI
        <small>ENERGY &amp; DEFENCE</small>
      </span>
    </Link>
  );
}
