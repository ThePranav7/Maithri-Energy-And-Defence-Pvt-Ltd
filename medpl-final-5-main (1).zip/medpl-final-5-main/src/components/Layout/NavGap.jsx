import "./NavGap.css";

// Sky-blue strip that sits directly under the fixed navbar, matching
// the backdrop the Home hero already provides. Drop this as the very
// first element on any page whose hero doesn't already supply that
// light background (dark/photo heroes on Products, Industrial,
// Defense, BMS, Li-Ion, Power System, About Us).
export default function NavGap() {
  return <div className="nav-gap" aria-hidden="true" />;
}
