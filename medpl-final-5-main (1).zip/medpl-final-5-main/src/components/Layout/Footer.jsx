import React from "react";
import { Link } from "react-router-dom";
import maithriSymbol from "../../assets/maithri-symbol.webp";
import { LinkedInIcon, YouTubeIcon, MailIcon } from "./icons";
import "./Footer.css";

const EXPLORE_LINKS = [
  { name: "Home", href: "/" },
  { name: "About Us", href: "/about#about-overview" },
  { name: "Team", href: "/about#leadership" },
  { name: "Mission & Vision", href: "/about#mission" }
];

const PRODUCT_LINKS = [
  { name: "Industrial", href: "/products/industrial" },
  { name: "Defense", href: "/products/defense" },
  { name: "IoT", href: "/products/iot" }
];

const SOLUTIONS_LINKS = [
  { name: "News & Blog", href: "/news" },
  { name: "Careers", href: "/careers" }
];

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="site-footer">
      <div className="footer-top">
        <div className="footer-col footer-brand">
          <Link to="/" className="footer-logo">
            <img
              src={maithriSymbol}
              alt="Maithri symbol"
              className="footer-logo-mark"
            />
            <span className="footer-logo-text">
              MAITHRI
              <small>ENERGY &amp; DEFENCE</small>
            </span>
          </Link>
          <p className="footer-tagline">
            Powering Industry. Securing Defense. Enabling Intelligence.
          </p>
        </div>

        <nav className="footer-col">
          <h4 className="footer-heading">Explore</h4>
          <ul className="footer-list">
            {EXPLORE_LINKS.map((link) => (
              <li key={link.name}>
                <Link to={link.href}>{link.name}</Link>
              </li>
            ))}
          </ul>
        </nav>

        <nav className="footer-col">
          <h4 className="footer-heading">Products</h4>
          <ul className="footer-list">
            {PRODUCT_LINKS.map((link) => (
              <li key={link.name}>
                <Link to={link.href}>{link.name}</Link>
              </li>
            ))}
          </ul>
        </nav>

        <nav className="footer-col">
          <h4 className="footer-heading">Solutions</h4>
          <ul className="footer-list">
            {SOLUTIONS_LINKS.map((link) => (
              <li key={link.name}>
                <Link to={link.href}>{link.name}</Link>
              </li>
            ))}
          </ul>
        </nav>

        <div className="footer-col footer-contact">
          <h4 className="footer-heading">Contact Us</h4>
          <address>
            <span className="footer-company-name">
              Maithri Energy &amp; Defense Private Limited
            </span>
            <br />
            Second Floor, Plot No. 158, Phase III, IDA Cherlapally,
            Hyderabad &ndash; 500 051
          </address>
          <p className="footer-phones">
            <a href="tel:+918790829596">+91 87908 29596</a>
            <span className="sep">|</span>
            <a href="tel:+918885708126">+91 88857 08126</a>
          </p>
          <p>
            <a
              className="footer-email"
              href="mailto:jayachandran.k@maithrienergy.com"
            >
              jayachandran.k@maithrienergy.com
            </a>
          </p>

          <div className="footer-social">
            <a
              href="https://linkedin.com"
              target="_blank"
              rel="noreferrer"
              aria-label="LinkedIn"
            >
              <LinkedInIcon />
            </a>
            <a
              href="https://youtube.com"
              target="_blank"
              rel="noreferrer"
              aria-label="YouTube"
            >
              <YouTubeIcon />
            </a>
            <a href="mailto:jayachandran.k@maithrienergy.com" aria-label="Email">
              <MailIcon />
            </a>
          </div>
        </div>
      </div>

      <div className="footer-bottom">
        <p>
          &copy; {year} Maithri Energy &amp; Defense Private Limited. All
          Rights Reserved.
        </p>
        <p className="footer-legal">
          <Link to="/privacy">Privacy Policy</Link>
          <span className="sep">|</span>
          <Link to="/terms">Terms</Link>
        </p>
      </div>
    </footer>
  );
}
