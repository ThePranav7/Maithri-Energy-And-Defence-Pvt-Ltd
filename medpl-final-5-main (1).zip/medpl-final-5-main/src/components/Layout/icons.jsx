import React from "react";

const base = {
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "1.6",
  strokeLinecap: "round",
  strokeLinejoin: "round"
};

export const HomeIcon = () => (
  <svg {...base}>
    <path d="M3.5 11.5 12 4l8.5 7.5" />
    <path d="M5.5 10v9a1 1 0 0 0 1 1H10v-5.5h4V20h3.5a1 1 0 0 0 1-1v-9" />
  </svg>
);

export const InfoIcon = () => (
  <svg {...base}>
    <circle cx="12" cy="12" r="8.5" />
    <path d="M12 11v5.2" />
    <circle cx="12" cy="8" r="0.9" fill="currentColor" stroke="none" />
  </svg>
);

export const ProductsIcon = () => (
  <svg {...base}>
    <path d="M12 3 L20.5 7.5 V16.5 L12 21 L3.5 16.5 V7.5 Z" />
    <path d="M3.5 7.5 12 12 20.5 7.5" />
    <path d="M12 12v9" />
  </svg>
);

export const ServicesIcon = () => (
  <svg {...base}>
    <path d="M14.5 3.5a4.6 4.6 0 0 0-6 5.9L3 15v3.2a2.8 2.8 0 0 0 2.8 2.8H9v-2.6h2.6V15.9h2.6l1.5-1.5a4.6 4.6 0 0 0 5.9-6l-3.2 3.2-2.6-.6-.6-2.6Z" />
  </svg>
);

export const NewsIcon = () => (
  <svg {...base}>
    <rect x="3.5" y="5" width="17" height="14" rx="1.6" />
    <path d="M7 9h6M7 12.2h10M7 15.4h10" />
  </svg>
);

export const CareersIcon = () => (
  <svg {...base}>
    <rect x="3.5" y="7.5" width="17" height="12" rx="1.8" />
    <path d="M8.5 7.5V6a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v1.5" />
    <path d="M3.5 12.5h17" />
  </svg>
);

export const ContactIcon = () => (
  <svg {...base}>
    <rect x="3.2" y="5.5" width="17.6" height="13" rx="1.8" />
    <path d="M4 7 12 13 20 7" />
  </svg>
);

export const LinkedInIcon = () => (
  <svg {...base} strokeWidth="1.4">
    <rect x="3.5" y="3.5" width="17" height="17" rx="2.6" />
    <path d="M8.2 10.2v6.4" />
    <circle cx="8.2" cy="7.5" r="0.9" fill="currentColor" stroke="none" />
    <path d="M11.8 16.6v-3.7c0-1.5 1-2.4 2.3-2.4 1.3 0 2.1.9 2.1 2.4v3.7" />
    <path d="M11.8 12.9v3.7" />
  </svg>
);

export const YouTubeIcon = () => (
  <svg {...base} strokeWidth="1.4">
    <rect x="3" y="6" width="18" height="12" rx="3.2" />
    <path d="M10.5 9.6 15 12l-4.5 2.4Z" fill="currentColor" stroke="none" />
  </svg>
);

export const MailIcon = () => (
  <svg {...base}>
    <rect x="3.2" y="5.5" width="17.6" height="13" rx="1.8" />
    <path d="M4 7 12 13 20 7" />
  </svg>
);

export const ArrowRight = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M5 12h14" />
    <path d="M13 6l6 6-6 6" />
  </svg>
);

export const Caret = () => (
  <svg viewBox="0 0 10 10" className="caret">
    <path
      d="M1 3l4 4 4-4"
      stroke="currentColor"
      strokeWidth="1.4"
      fill="none"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);
