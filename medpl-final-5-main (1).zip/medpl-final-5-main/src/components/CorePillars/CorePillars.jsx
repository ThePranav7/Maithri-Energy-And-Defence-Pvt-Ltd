import { useEffect, useRef, useState } from "react";
import "./CorePillars.css";
import { GearIcon, ShieldCheckIcon, HandshakeIcon, BulbIcon } from "./PillarIcons";
import bgVideo from "./assets/our-core-bg.mp4";

const PILLARS = [
  {
    id: "precision-engineering",
    title: "Precision Engineering",
    description:
      "Advanced technology designed for dependable performance in demanding real-world applications.",
    Icon: GearIcon,
  },
  {
    id: "dependable-performance",
    title: "Dependable Performance",
    description: "Longer cycle life, higher efficiency, dependable always.",
    Icon: ShieldCheckIcon,
  },
  {
    id: "collaborative-partnership",
    title: "Collaborative Partnership",
    description: "Working closely with partners to build what truly matters.",
    Icon: HandshakeIcon,
  },
  {
    id: "future-ready-innovation",
    title: "Future-Ready Innovation",
    description: "Adaptable technology today for the energy challenges of tomorrow.",
    Icon: BulbIcon,
  },
];

// Intro elements animate in first (title only),
// then the four cards reveal one after another.
const INTRO_STEPS = 1;
const INTRO_STEP_DELAY = 220; // ms between each intro element
const CARDS_START_DELAY = INTRO_STEPS * INTRO_STEP_DELAY + 150; // wait for intro to finish
const CARD_STEP_DELAY = 220; // ms between each card

function PillarCard({ title, description, Icon, index, revealed }) {
  return (
    <div
      className={`approach-card${revealed ? " reveal" : ""}`}
      style={{ transitionDelay: `${CARDS_START_DELAY + index * CARD_STEP_DELAY}ms` }}
    >
      <div className="approach-icon-circle">
        <Icon />
      </div>
      <h3>{title}</h3>
      <p>{description}</p>
    </div>
  );
}

export default function CorePillars() {
  const sectionRef = useRef(null);
  const [revealed, setRevealed] = useState(false);

  useEffect(() => {
    const node = sectionRef.current;
    if (!node) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setRevealed(true);
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.15 }
    );

    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  return (
    <section className="approach" ref={sectionRef}>
      <video
        className="approach-bg-video"
        src={bgVideo}
        autoPlay
        loop
        muted
        playsInline
      />
      <div className="approach-bg-overlay" />
      <div className="approach-grid">
        <div className="approach-intro">
          <h1
            className={`approach-reveal${revealed ? " reveal" : ""}`}
            style={{ transitionDelay: `${0 * INTRO_STEP_DELAY}ms` }}
          >
            Our Core Approach
          </h1>
        </div>

        <div className="approach-cards-grid">
          {PILLARS.map((pillar, index) => (
            <PillarCard key={pillar.id} {...pillar} index={index} revealed={revealed} />
          ))}
        </div>
      </div>
    </section>
  );
}
