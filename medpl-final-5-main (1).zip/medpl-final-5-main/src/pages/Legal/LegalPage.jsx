import { useEffect } from "react";
import NavGap from "../../components/Layout/NavGap.jsx";
import "./LegalPage.css";

export default function LegalPage({ title, updated }) {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="legal-page">
      <NavGap />
      <div className="legal-page__inner">
        <h1>{title}</h1>
        {updated && <p className="legal-page__updated">Last updated: {updated}</p>}
        <p className="legal-page__body">
          This page is currently being finalized. In the meantime, if you have
          any questions about our {title.toLowerCase()}, please reach out to
          us directly at{" "}
          <a href="mailto:jayachandran.k@maithrienergy.com">
            jayachandran.k@maithrienergy.com
          </a>
          .
        </p>
      </div>
    </div>
  );
}
