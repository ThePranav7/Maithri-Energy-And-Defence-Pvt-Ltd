import { useEffect } from 'react'
import NavGap from '../../components/Layout/NavGap.jsx'
import NewsBanner from './components/NewsBanner.jsx'
import FeaturedNews from './components/FeaturedNews.jsx'
import ArticlesSection from './components/ArticlesSection.jsx'
import NewsHighlights from './components/NewsHighlights.jsx'
import './NewsPage.css'

export default function NewsPage() {
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  return (
    <div className="news-page">
      <NavGap />
      <NewsBanner
        title="News & Blogs"
        description="Insights, updates and stories from the world of energy, defense and IoT."
      />
      <FeaturedNews />
      <ArticlesSection />
      <NewsHighlights />
    </div>
  )
}
