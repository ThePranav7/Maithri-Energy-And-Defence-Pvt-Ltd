import LatestArticles from './LatestArticles.jsx'
import Categories from './Categories.jsx'
import './ArticlesSection.css'

function ArticlesSection() {
  return (
    <section className="articles-section">
      <div className="articles-section-grid">
        <LatestArticles />
        <Categories />
      </div>
    </section>
  )
}

export default ArticlesSection
