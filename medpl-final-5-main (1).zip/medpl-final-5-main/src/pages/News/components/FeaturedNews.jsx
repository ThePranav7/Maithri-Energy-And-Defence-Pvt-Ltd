import { useState } from 'react'
import './FeaturedNews.css'
import ArticleModal from './ArticleModal.jsx'
import liionImage from '../assets/featured-liion-battery.webp'
import bmsImage from '../assets/featured-bms-platform.webp'
import defenceImage from '../assets/featured-defence-expo.webp'
import iotImage from '../assets/featured-iot-energy.webp'

const articles = [
  {
    badge: 'PRESS RELEASE',
    date: '15 May 2024',
    title: 'Maithri Energy Launches High-Energy Li-ion Battery for Industrial Applications',
    excerpt:
      'Our new 25.6V / 200Ah Li-ion battery delivers superior performance, safety and longer cycle life.',
    image: liionImage,
  },
  {
    badge: 'COMPANY UPDATE',
    date: '02 May 2024',
    title: 'Advanced BMS Platform for Li-ion and Sodium-ion Battery Systems',
    excerpt:
      'Our intelligent BMS ensures enhanced safety, accurate monitoring and reliable operation across all environments.',
    image: bmsImage,
  },
  {
    badge: 'EVENTS',
    date: '20 Apr 2024',
    title: 'Maithri Energy at Bharat Defence Expo 2024',
    excerpt:
      'We showcased our power solutions for defense, aerospace and mission-critical applications.',
    image: defenceImage,
  },
  {
    badge: 'BLOG',
    date: '10 Apr 2024',
    title: 'The Rise of IoT in Energy Management Systems',
    excerpt:
      'How IoT-powered monitoring and analytics are transforming energy efficiency and operational intelligence.',
    image: iotImage,
  },
]

function CalendarIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="3" y="5" width="18" height="16" rx="2" stroke="currentColor" strokeWidth="1.6" />
      <path d="M3 9.5H21" stroke="currentColor" strokeWidth="1.6" />
      <path d="M8 3V6" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
      <path d="M16 3V6" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
    </svg>
  )
}

function ArrowIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M4 12H20" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <path d="M14 6L20 12L14 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

function FeaturedNews() {
  const [activeArticle, setActiveArticle] = useState(null)

  return (
    <section className="featured-news">
      <div className="featured-news-header">
        <h2>Featured News</h2>
      </div>

      <div className="featured-news-grid">
        {articles.map((article) => (
          <article className="news-card" key={article.title}>
            <div className="news-card-image">
              <img src={article.image} alt={article.title} />
              <span className="news-card-badge">{article.badge}</span>
            </div>

            <div className="news-card-body">
              <div className="news-card-date">
                <CalendarIcon />
                <span>{article.date}</span>
              </div>

              <h3>{article.title}</h3>
              <p>{article.excerpt}</p>

              <button
                type="button"
                className="news-card-link"
                onClick={() => setActiveArticle(article)}
              >
                READ MORE <ArrowIcon />
              </button>
            </div>
          </article>
        ))}
      </div>

      <ArticleModal
        article={activeArticle}
        isOpen={!!activeArticle}
        onClose={() => setActiveArticle(null)}
      />
    </section>
  )
}

export default FeaturedNews
