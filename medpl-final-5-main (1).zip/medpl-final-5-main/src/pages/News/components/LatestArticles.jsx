import { useState } from 'react'
import './LatestArticles.css'
import ArticleModal from './ArticleModal.jsx'
import powerSystemImage from '../assets/article-power-system.webp'
import defenseMissionsImage from '../assets/article-defense-missions.webp'
import sustainableStorageImage from '../assets/article-sustainable-storage.webp'
import iotMonitoringImage from '../assets/article-iot-monitoring.webp'
import bmsBrainsImage from '../assets/article-bms-brains.webp'
import manufacturingCapacityImage from '../assets/article-manufacturing-capacity.webp'
import solarMicrogridsImage from '../assets/article-solar-microgrids.webp'
import yearInReviewImage from '../assets/article-year-in-review.webp'

const initialArticles = [
  {
    title: 'Power System Products: Ensuring Uninterrupted Power',
    excerpt: 'A closer look at our UPS, Inverter and Charger solutions built for reliability and performance.',
    date: '28 Mar 2024',
    image: powerSystemImage,
  },
  {
    title: 'Powering Defense Missions with Advanced Technology',
    excerpt: 'Our rugged, high-performance power solutions engineered for the toughest defense environments.',
    date: '18 Mar 2024',
    image: defenseMissionsImage,
  },
  {
    title: 'Sustainable Energy Storage for a Greener Tomorrow',
    excerpt: 'Exploring how advanced battery technologies are enabling clean energy and sustainability.',
    date: '05 Mar 2024',
    image: sustainableStorageImage,
  },
  {
    title: 'IoT Solutions for Real-time Monitoring and Control',
    excerpt: 'Our AWG controllers and cloud platform enable smarter decisions and remote operations.',
    date: '22 Feb 2024',
    image: iotMonitoringImage,
  },
]

const moreArticles = [
  {
    title: 'Battery Management Systems: The Brains Behind the Pack',
    excerpt: 'How our BMS platform balances safety, performance and battery lifespan.',
    date: '14 Feb 2024',
    image: bmsBrainsImage,
  },
  {
    title: 'Maithri Energy Expands Manufacturing Capacity',
    excerpt: 'A new production line comes online to meet growing demand across sectors.',
    date: '30 Jan 2024',
    image: manufacturingCapacityImage,
  },
  {
    title: 'Solar-Storage Microgrids for Remote Operations',
    excerpt: 'Deploying hybrid power systems where the grid can not reach.',
    date: '18 Jan 2024',
    image: solarMicrogridsImage,
  },
  {
    title: 'A Year in Review: 2023 Milestones',
    excerpt: 'Looking back at the products, partnerships and people that shaped our year.',
    date: '02 Jan 2024',
    image: yearInReviewImage,
  },
]

function ArrowIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M4 12H20" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <path d="M14 6L20 12L14 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

function LatestArticles() {
  const [showAll, setShowAll] = useState(false)
  const [activeArticle, setActiveArticle] = useState(null)
  const articles = showAll ? [...initialArticles, ...moreArticles] : initialArticles

  return (
    <div className="latest-articles">
      <div className="latest-articles-header">
        <h2>Latest Articles</h2>
      </div>

      <ul className="article-list">
        {articles.map((article) => (
          <li className="article-row" key={article.title}>
            <div className="article-thumb">
              {article.image && <img src={article.image} alt={article.title} />}
            </div>

            <div className="article-info">
              <h3>{article.title}</h3>
              <p>{article.excerpt}</p>
            </div>

            <div className="article-meta">
              <span className="article-date">{article.date}</span>
              <button
                type="button"
                className="article-link"
                onClick={() => setActiveArticle(article)}
              >
                READ MORE <ArrowIcon />
              </button>
            </div>
          </li>
        ))}
      </ul>

      <button
        type="button"
        className="view-all-btn"
        onClick={() => setShowAll((prev) => !prev)}
      >
        {showAll ? 'SHOW LESS' : 'VIEW ALL ARTICLES'}
        <ArrowIcon />
      </button>

      <ArticleModal
        article={activeArticle}
        isOpen={!!activeArticle}
        onClose={() => setActiveArticle(null)}
      />
    </div>
  )
}

export default LatestArticles
