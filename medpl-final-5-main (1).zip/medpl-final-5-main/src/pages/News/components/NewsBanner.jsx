import newsBg from '../assets/news-bg.webp'
import './NewsBanner.css'

function NewsBanner({ title, description }) {
  return (
    <div
      className="news-banner"
      style={{ backgroundImage: `url(${newsBg})` }}
    >
      <div className="news-banner-content">
        <h1>{title}</h1>
        <p>{description}</p>
      </div>
      <img src={newsBg} alt="" className="news-banner__mobile-photo" aria-hidden="true" />
    </div>
  )
}

export default NewsBanner
