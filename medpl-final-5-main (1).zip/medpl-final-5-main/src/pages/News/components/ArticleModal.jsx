import { useEffect } from 'react'
import './ArticleModal.css'

function CloseIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  )
}

function CalendarIcon() {
  return (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="3" y="5" width="18" height="16" rx="2" stroke="currentColor" strokeWidth="1.6" />
      <path d="M3 9.5H21" stroke="currentColor" strokeWidth="1.6" />
      <path d="M8 3V6" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
      <path d="M16 3V6" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
    </svg>
  )
}

export default function ArticleModal({ article, isOpen, onClose }) {
  useEffect(() => {
    if (!isOpen) return undefined
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') onClose()
    }
    document.addEventListener('keydown', handleKeyDown)
    const prevOverflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => {
      document.removeEventListener('keydown', handleKeyDown)
      document.body.style.overflow = prevOverflow
    }
  }, [isOpen, onClose])

  if (!isOpen || !article) return null

  const handleBackdropClick = (e) => {
    if (e.target === e.currentTarget) onClose()
  }

  return (
    <div className="article-modal__backdrop" onMouseDown={handleBackdropClick}>
      <div className="article-modal" role="dialog" aria-modal="true" aria-labelledby="article-modal-title">
        <button className="article-modal__close" onClick={onClose} aria-label="Close article">
          <CloseIcon />
        </button>

        {article.image && (
          <div className="article-modal__image">
            <img src={article.image} alt={article.title} />
            {article.badge && <span className="article-modal__badge">{article.badge}</span>}
          </div>
        )}

        <div className="article-modal__body">
          {article.date && (
            <div className="article-modal__date">
              <CalendarIcon />
              <span>{article.date}</span>
            </div>
          )}

          <h2 className="article-modal__title" id="article-modal-title">
            {article.title}
          </h2>

          <p className="article-modal__excerpt">{article.excerpt}</p>

          <p className="article-modal__note">
            More details on this story will be published soon — check back or reach out to our team for
            more information.
          </p>
        </div>
      </div>
    </div>
  )
}
