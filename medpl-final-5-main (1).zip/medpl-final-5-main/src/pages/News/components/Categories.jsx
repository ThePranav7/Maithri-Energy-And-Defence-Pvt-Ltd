import { useState } from 'react'
import './Categories.css'

const categories = [
  { label: 'Company News', count: 12, icon: 'doc' },
  { label: 'Product Updates', count: 15, icon: 'network' },
  { label: 'Events & Exhibitions', count: 9, icon: 'gear-calendar' },
  { label: 'Technology Insights', count: 18, icon: 'gear' },
  { label: 'Industry Trends', count: 11, icon: 'chart' },
  { label: 'Blogs', count: 22, icon: 'check' },
]

function CategoryIcon({ type }) {
  const common = { width: 20, height: 20, viewBox: '0 0 24 24', fill: 'none', xmlns: 'http://www.w3.org/2000/svg' }

  switch (type) {
    case 'doc':
      return (
        <svg {...common}>
          <rect x="5" y="3" width="14" height="18" rx="1.5" stroke="currentColor" strokeWidth="1.6" />
          <path d="M8 8H16" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
          <path d="M8 12H16" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
          <path d="M8 16H13" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
        </svg>
      )
    case 'network':
      return (
        <svg {...common}>
          <circle cx="6" cy="7" r="2.2" stroke="currentColor" strokeWidth="1.6" />
          <circle cx="18" cy="7" r="2.2" stroke="currentColor" strokeWidth="1.6" />
          <circle cx="12" cy="17" r="2.2" stroke="currentColor" strokeWidth="1.6" />
          <path d="M7.7 8.6L10.6 15.2" stroke="currentColor" strokeWidth="1.6" />
          <path d="M16.3 8.6L13.4 15.2" stroke="currentColor" strokeWidth="1.6" />
          <path d="M8.2 7H15.8" stroke="currentColor" strokeWidth="1.6" />
        </svg>
      )
    case 'gear-calendar':
      return (
        <svg {...common}>
          <rect x="3" y="5" width="18" height="15" rx="2" stroke="currentColor" strokeWidth="1.6" />
          <path d="M3 9.5H21" stroke="currentColor" strokeWidth="1.6" />
          <circle cx="12" cy="14.5" r="2.6" stroke="currentColor" strokeWidth="1.6" />
          <path d="M12 11.3V12" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
        </svg>
      )
    case 'gear':
      return (
        <svg {...common}>
          <circle cx="12" cy="12" r="3" stroke="currentColor" strokeWidth="1.6" />
          <path
            d="M12 3.5V6M12 18V20.5M20.5 12H18M6 12H3.5M17.7 6.3L16 8M8 16L6.3 17.7M17.7 17.7L16 16M8 8L6.3 6.3"
            stroke="currentColor"
            strokeWidth="1.6"
            strokeLinecap="round"
          />
        </svg>
      )
    case 'chart':
      return (
        <svg {...common}>
          <path d="M4 20V4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
          <path d="M4 20H20" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
          <path d="M7 16L11 11L14 13.5L19 7" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      )
    case 'check':
      return (
        <svg {...common}>
          <rect x="3.5" y="4" width="17" height="16" rx="2" stroke="currentColor" strokeWidth="1.6" />
          <path d="M7.5 12L10.5 15L16.5 9" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      )
    default:
      return null
  }
}

function ChevronIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M9 6L15 12L9 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

function MailIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="3" y="5" width="18" height="14" rx="2" stroke="currentColor" strokeWidth="1.6" />
      <path d="M3.5 6.5L12 13L20.5 6.5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

function ArrowIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M4 12H20" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <path d="M14 6L20 12L14 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

function Categories({ onSelectCategory }) {
  const [email, setEmail] = useState('')
  const [subscribed, setSubscribed] = useState(false)

  function handleSubscribe(e) {
    e.preventDefault()
    if (!email.trim()) return
    setSubscribed(true)
    setEmail('')
  }

  return (
    <div className="categories-panel">
      <div className="categories-card">
        <div className="categories-header">
          <h2>Categories</h2>
        </div>

        <ul className="category-list">
          {categories.map((cat) => (
            <li key={cat.label}>
              <button
                type="button"
                className="category-row"
                onClick={() => onSelectCategory?.(cat.label)}
              >
                <span className="category-icon">
                  <CategoryIcon type={cat.icon} />
                </span>
                <span className="category-label">{cat.label}</span>
                <span className="category-count">({String(cat.count).padStart(2, '0')})</span>
                <span className="category-chevron">
                  <ChevronIcon />
                </span>
              </button>
            </li>
          ))}
        </ul>
      </div>

      <form className="newsletter-card" onSubmit={handleSubscribe}>
        <div className="newsletter-icon">
          <MailIcon />
        </div>
        <h3>Subscribe to Our Newsletter</h3>
        <p>Get the latest news, product updates and insights delivered straight to your inbox.</p>

        <div className="newsletter-input-row">
          <input
            type="email"
            placeholder="Enter your email address"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <button type="submit">
            SUBSCRIBE <ArrowIcon />
          </button>
        </div>

        {subscribed && <p className="newsletter-success">Thanks — you're subscribed!</p>}
      </form>
    </div>
  )
}

export default Categories
