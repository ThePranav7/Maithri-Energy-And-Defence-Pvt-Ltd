import './NewsHighlights.css'

const stats = [
  { value: '50+', label: 'News Articles Published', icon: 'megaphone' },
  { value: '10+', label: 'Events Participated', icon: 'people' },
  { value: '5+', label: 'Countries Reaching', icon: 'globe' },
  { value: '100+', label: 'Industry Insights Shared', icon: 'trend' },
]

function StatIcon({ type }) {
  const common = {
    width: 34,
    height: 34,
    viewBox: '0 0 24 24',
    fill: 'none',
    xmlns: 'http://www.w3.org/2000/svg',
  }

  switch (type) {
    case 'megaphone':
      return (
        <svg {...common}>
          <path
            d="M3 10V14C3 14.55 3.45 15 4 15H5.5L7 19H9L7.7 15H9L16 18V6L9 9H4C3.45 9 3 9.45 3 10Z"
            stroke="currentColor"
            strokeWidth="1.5"
            strokeLinejoin="round"
          />
          <path d="M16 9.5C17 10.1 17.6 10.9 17.6 12C17.6 13.1 17 13.9 16 14.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
          <path d="M19.5 7.5C21 8.6 22 10.2 22 12C22 13.8 21 15.4 19.5 16.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
        </svg>
      )
    case 'people':
      return (
        <svg {...common}>
          <circle cx="9" cy="8" r="2.6" stroke="currentColor" strokeWidth="1.5" />
          <path d="M4 18.5C4 15.5 6.2 13.5 9 13.5C11.8 13.5 14 15.5 14 18.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
          <circle cx="16.5" cy="9" r="2.1" stroke="currentColor" strokeWidth="1.5" />
          <path d="M14.8 13.7C15.6 13.4 16.6 13.6 17.2 13.9C18.9 14.6 19.9 16.2 19.9 18.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
        </svg>
      )
    case 'globe':
      return (
        <svg {...common}>
          <circle cx="12" cy="12" r="8.5" stroke="currentColor" strokeWidth="1.5" />
          <ellipse cx="12" cy="12" rx="3.6" ry="8.5" stroke="currentColor" strokeWidth="1.5" />
          <path d="M3.5 12H20.5" stroke="currentColor" strokeWidth="1.5" />
          <path d="M4.7 8H19.3" stroke="currentColor" strokeWidth="1.5" />
          <path d="M4.7 16H19.3" stroke="currentColor" strokeWidth="1.5" />
        </svg>
      )
    case 'trend':
      return (
        <svg {...common}>
          <path d="M4 20V4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
          <path d="M4 20H20" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
          <path d="M6.5 16L10.5 11.5L13.5 14L18 8.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M14.5 8.5H18V12" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      )
    default:
      return null
  }
}

function NewsHighlights() {
  return (
    <section className="news-highlights">
      <div className="news-highlights-card">
        <div className="news-highlights-header">
          <h2>News Highlights</h2>
        </div>

        <div className="news-highlights-row">
          {stats.map((stat, index) => (
            <div className="highlight-item" key={stat.label}>
              {index !== 0 && <span className="highlight-divider" aria-hidden="true" />}

              <span className="highlight-icon">
                <StatIcon type={stat.icon} />
              </span>

              <div className="highlight-text">
                <span className="highlight-value">{stat.value}</span>
                <span className="highlight-label">{stat.label}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default NewsHighlights
