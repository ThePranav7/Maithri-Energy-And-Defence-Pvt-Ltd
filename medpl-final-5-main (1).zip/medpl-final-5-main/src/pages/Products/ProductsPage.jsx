import { useEffect } from 'react'
import NavGap from '../../components/Layout/NavGap.jsx'
import IndustrialHero from './Industrial/components/IndustrialHero.jsx'
import ProductPortfolio from './components/ProductPortfolio.jsx'
import EngineeredExcellence from './components/EngineeredExcellence.jsx'
import CtaBanner from './components/CtaBanner.jsx'
import './ProductsPage.css'

export default function ProductsPage() {
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  return (
    <div className="products-page">
      <NavGap />
      <IndustrialHero />
      <ProductPortfolio />
      <EngineeredExcellence />
      <CtaBanner />
    </div>
  )
}
