import { ShieldCheck, PieChart, Settings, Headset } from "lucide-react";
import "./IndustrialFeatureStrip.css";

const features = [
  {
    icon: ShieldCheck,
    title: "Built for Reliability",
    description: "Designed for continuous operation in demanding environments.",
  },
  {
    icon: PieChart,
    title: "High Efficiency",
    description: "Maximize energy utilization and minimize losses.",
  },
  {
    icon: Settings,
    title: "Scalable Solutions",
    description: "Flexible systems that grow with your business.",
  },
  {
    icon: Headset,
    title: "End-to-End Support",
    description: "From consultation to after-sales support, we're with you.",
  },
];

export default function IndustrialFeatureStrip() {
  return (
    <section className="if-strip-wrap">
      <div className="if-strip">
        {features.map((feature, index) => {
          const Icon = feature.icon;
          return (
            <div className="if-item" key={feature.title}>
              <div className="if-icon">
                <Icon size={26} strokeWidth={1.6} />
              </div>
              <div className="if-text">
                <h4>{feature.title}</h4>
                <p>{feature.description}</p>
              </div>
              {index !== features.length - 1 && <div className="if-divider" />}
            </div>
          );
        })}
      </div>
    </section>
  );
}
