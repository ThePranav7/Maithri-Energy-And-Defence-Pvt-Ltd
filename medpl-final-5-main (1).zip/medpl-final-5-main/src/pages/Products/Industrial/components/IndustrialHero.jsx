import heroBg from "../assets/power-system.webp";
import "./IndustrialHero.css";

export default function IndustrialHero() {
  return (
    <section className="industrial-hero">
      <img
        className="industrial-hero__bg"
        src={heroBg}
        alt="Maithri Energy & Defense power systems, battery modules, and rugged electronics staged with a solar array and wind turbines"
      />
      <div className="industrial-hero__content">
        <h1 className="industrial-hero__heading">Our Products</h1>
        <p>
          High-performance energy solutions for industrial and commercial
          applications. Engineered for reliability, efficiency and long
          life.
        </p>
      </div>
    </section>
  );
}
