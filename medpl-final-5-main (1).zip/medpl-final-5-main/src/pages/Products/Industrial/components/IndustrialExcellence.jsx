import { Factory, ShieldCheck, Globe, Users } from "lucide-react";
import excellenceImg from "../assets/excellence.webp";
import "./IndustrialExcellence.css";

const stats = [
  { icon: Factory, value: "500+", label: "Industrial Installations" },
  { icon: ShieldCheck, value: "15+", label: "Years of Experience" },
  { icon: Globe, value: "Global", label: "Quality Standards" },
  { icon: Users, value: "24/7", label: "Technical Support" },
];

export default function IndustrialExcellence() {
  return (
    <section className="ie-section">
      <div
        className="ie-image"
        style={{ backgroundImage: `url(${excellenceImg})` }}
        aria-hidden="true"
      ></div>

      <div className="ie-content">
        <h2>Engineered for Industrial Excellence</h2>
        <p>
          Our industrial solutions are built with cutting-edge technology and
          rigorous testing to deliver unmatched performance, safety and
          durability. We empower industries to achieve energy independence
          and operational efficiency.
        </p>

        <div className="ie-stats">
          {stats.map((stat) => {
            const Icon = stat.icon;
            return (
              <div className="ie-stat" key={stat.label}>
                <div className="ie-stat-icon">
                  <Icon size={26} strokeWidth={1.6} />
                </div>
                <div className="ie-stat-value">{stat.value}</div>
                <div className="ie-stat-label">{stat.label}</div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
