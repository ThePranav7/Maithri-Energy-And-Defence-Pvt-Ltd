import { Link } from "react-router-dom";
import {
  BatteryCharging,
  Zap,
  Cpu,
  ArrowRight,
  Battery,
  Radar,
  LineChart,
  ShieldCheck,
  Scale,
  Radio,
  Layers,
  Box,
  Package,
  Settings,
  BatteryFull,
  Gauge,
  Thermometer,
  SlidersHorizontal,
  BatteryMedium,
  Monitor,
  Wifi,
  Repeat,
  Forklift,
  Truck,
  CarFront,
  PackageSearch,
  Bot,
} from "lucide-react";
import bmsImg from "../assets/bms.webp";
import liionImg from "../assets/liion-battery.webp";
import powerImg from "../assets/power-system.webp";
import "./IndustrialCategories.css";

const categories = [
  {
    id: "bms",
    icon: Cpu,
    image: bmsImg,
    imageFit: "cover",
    title: "BMS Solutions",
    tagline:
      "Intelligent Battery Management. Engineered for Safety. Built for Performance.",
    description:
      "Our Battery Management Systems (BMS) protect, monitor, and optimize battery performance across Lithium-ion and Sodium-ion platforms, ensuring safety, reliability, and longer battery life.",
    technologiesLabel: "OUR TECHNOLOGIES",
    technologies: [
      {
        icon: BatteryCharging,
        title: "Lithium-ion BMS",
        description:
          "Advanced battery monitoring and protection for Lithium-ion systems.",
        bullets: [
          "Cell voltage & temperature monitoring",
          "Overcharge & over-discharge protection",
          "Cell balancing",
          "Modbus (RS485), optional USB & CAN",
          "Configurable 5S–256S",
        ],
      },
      {
        icon: Battery,
        title: "Sodium-ion BMS",
        description:
          "Dedicated management technology optimized for Sodium-ion battery characteristics.",
        bullets: [
          "Chemistry-specific monitoring",
          "Dedicated safety protocols",
          "Advanced cell balancing",
          "Modbus (RS485), optional USB & CAN",
          "Configurable 5S–256S",
        ],
      },
    ],
    productsLabel: "APPLICATIONS",
    products: [
      {
        icon: Forklift,
        title: "Counterbalance & reach forklifts",
        description: "",
      },
      {
        icon: Truck,
        title: "Pallet trucks & stackers",
        description: "",
      },
      {
        icon: CarFront,
        title: "Tow tractors & tuggers",
        description: "",
      },
      {
        icon: PackageSearch,
        title: "Order pickers",
        description: "",
      },
      {
        icon: Bot,
        title: "AGVs / AMRs",
        description: "",
      },
      {
        icon: Package,
        title: "Custom OEM enclosures on request",
        description: "",
      },
    ],
    keyFeatures: [
      { icon: ShieldCheck, label: "Advanced Safety", sub: "Protection & monitoring" },
      { icon: Scale, label: "Cell Balancing", sub: "Optimized performance" },
      { icon: SlidersHorizontal, label: "Wide Configuration", sub: "5S–256S support" },
      { icon: Wifi, label: "Smart Connectivity", sub: "RS485 / USB / CAN" },
      { icon: BatteryMedium, label: "Dual Chemistry", sub: "Li-ion & Na-ion" },
    ],
    linkText: "VIEW BMS SOLUTIONS",
    link: "/products/industrial/bms",
  },
  {
    id: "battery",
    icon: BatteryCharging,
    image: liionImg,
    imageFit: "contain",
    title: "Battery Solutions",
    tagline:
      "Advanced Lithium & Sodium-Ion Technologies. Engineered for Performance. Built for Purpose.",
    description:
      "We design and manufacture high-performance battery cells, modules and packs using the latest Lithium technologies and Sodium-Ion chemistry to deliver safe, reliable and efficient energy solutions for diverse applications.",
    technologiesLabel: "OUR TECHNOLOGIES",
    technologies: [
      {
        icon: BatteryFull,
        title: "Lithium Technologies",
        eyebrow: "LFP | NMC | NCA | LTO",
        description:
          "High energy density, long life, fast charging and superior safety.",
        bullets: [
          "High energy density & long cycle life",
          "Fast charging capability",
          "SOC & SOH estimation",
          "Data logging & event history",
          "Wide chemistry range (LFP, NMC, NCA, LTO)",
        ],
      },
      {
        icon: Battery,
        title: "Sodium-Ion Technology",
        description:
          "Cost-effective, sustainable and thermally stable – Ideal for large scale and long duration applications.",
        bullets: [
          "Cost-effective & sustainable chemistry",
          "Thermally stable across wide temperatures",
          "SOC & SOH estimation",
          "Data logging & diagnostics",
          "Ideal for large-scale, long-duration storage",
        ],
      },
    ],
    productsLabel: "APPLICATIONS",
    products: [
      {
        icon: Forklift,
        title: "Counterbalance & reach forklifts",
        description: "",
      },
      {
        icon: Truck,
        title: "Pallet trucks & stackers",
        description: "",
      },
      {
        icon: CarFront,
        title: "Tow tractors & tuggers",
        description: "",
      },
      {
        icon: PackageSearch,
        title: "Order pickers",
        description: "",
      },
      {
        icon: Bot,
        title: "AGVs / AMRs",
        description: "",
      },
      {
        icon: Package,
        title: "Custom OEM enclosures on request",
        description: "",
      },
    ],
    keyFeatures: [
      { icon: ShieldCheck, label: "High Safety & Reliability", sub: "Certified protection" },
      { icon: Repeat, label: "Extended Lifespan", sub: "Long charge-cycle life" },
      { icon: Zap, label: "High Power Density", sub: "Compact, high output" },
      { icon: Thermometer, label: "Wide Temp. Range", sub: "Extreme heat & cold" },
      { icon: Settings, label: "Customizable Solutions", sub: "Built to your spec" },
    ],
    linkText: "VIEW BATTERY SOLUTIONS",
    link: "/products/industrial/li-ion",
  },
  {
    id: "energy",
    icon: Zap,
    image: powerImg,
    imageFit: "cover",
    title: "Energy Solutions",
    tagline:
      "Reliable Energy Storage. Intelligent Power Management. Built for Continuity.",
    description:
      "We deliver scalable energy storage and power management solutions across Lithium-ion and Sodium-ion platforms—designed to ensure reliable, efficient and uninterrupted power for critical applications.",
    technologiesLabel: "OUR TECHNOLOGIES",
    technologies: [
      {
        icon: Battery,
        title: "Energy Storage Systems (BESS)",
        description:
          "Scalable battery energy storage systems for industrial, commercial and grid applications.",
        bullets: [
          "Modular architecture",
          "500 kWh to 5 MWh",
          "Integrated safety monitoring",
          "Grid-tied & off-grid configurations",
        ],
      },
      {
        icon: Gauge,
        title: "Power Management Systems",
        description:
          "Reliable power conversion and management solutions for continuous operations.",
        bullets: [
          "High-efficiency conversion",
          "UPS & inverter integration",
          "Smart battery integration",
          "Automatic changeover",
        ],
      },
    ],
    productsLabel: "APPLICATIONS",
    products: [
      {
        icon: Battery,
        title: "BESS",
        description:
          "Scalable energy storage for grid support, peak shaving and renewable integration.",
      },
      {
        icon: Monitor,
        title: "UPS Systems",
        description:
          "Uninterruptible power systems for critical industrial and commercial loads.",
      },
      {
        icon: Radar,
        title: "Inverters",
        description:
          "High-efficiency DC-to-AC power conversion from battery or solar charged systems.",
      },
      {
        icon: Package,
        title: "Chargers",
        description:
          "Smart charging solutions optimized for Lithium-ion and Sodium-ion chemistries.",
      },
    ],
    keyFeatures: [
      { icon: Layers, label: "Scalable Storage", sub: "500 kWh – 5 MWh" },
      { icon: ShieldCheck, label: "Reliable Backup", sub: "Critical load protection" },
      { icon: Zap, label: "High Efficiency", sub: "Optimized conversion" },
      { icon: Cpu, label: "Smart Integration", sub: "Battery & BMS integration" },
      { icon: Monitor, label: "Remote Monitoring", sub: "Real-time diagnostics" },
    ],
    linkText: "VIEW ENERGY SOLUTIONS",
    link: "/products/industrial/power-system",
  },
];

export default function IndustrialCategories() {
  return (
    <section className="industrial-categories" id="industrial-categories">
      <div className="ic-header">
        <h2>Our Industrial Product Categories</h2>
        <p>
          Complete energy storage and power conversion solutions for diverse
          industrial applications.
        </p>
      </div>

      <div className="ic-grid">
        {categories.map((cat) => {
          const CatIcon = cat.icon;
          return (
          <div className="ic-panel" key={cat.id}>
            <div className="ic-image">
              <img
                src={cat.image}
                alt={cat.title}
                style={{ objectFit: cat.imageFit }}
              />
            </div>

            <span className="ic-icon-badge">
              <CatIcon size={20} strokeWidth={1.8} />
            </span>

            <div className="ic-body">
            <h3 className="ic-title">{cat.title}</h3>
            <p className="ic-tagline">{cat.tagline}</p>
            <p className="ic-description">{cat.description}</p>

            <div className="ic-sections">
              <div className="ic-section">
                <span className="ic-pill">{cat.technologiesLabel}</span>
                <div className="ic-tech-list">
                  {cat.technologies.map((t) => {
                    const TIcon = t.icon;
                    return (
                      <div className="ic-tech-item" key={t.title}>
                        <span className="ic-tech-icon">
                          <TIcon size={16} strokeWidth={1.8} />
                        </span>
                        <div className="ic-tech-body">
                          <h4>{t.title}</h4>
                          {t.eyebrow && (
                            <div className="ic-tech-eyebrow">{t.eyebrow}</div>
                          )}
                          <p>{t.description}</p>
                          {t.bullets && (
                            <ul className="ic-tech-bullets">
                              {t.bullets.map((b) => (
                                <li key={b}>{b}</li>
                              ))}
                            </ul>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="ic-section">
                <span className="ic-pill">{cat.productsLabel}</span>
                <div className="ic-product-list">
                  {cat.products.map((p) => {
                    const PIcon = p.icon;
                    return (
                      <div className="ic-product-item" key={p.title}>
                        <span className="ic-product-icon">
                          <PIcon size={16} strokeWidth={1.8} />
                        </span>
                        <div className="ic-product-body">
                          <h4>{p.title}</h4>
                          {p.description && <p>{p.description}</p>}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            <div className="ic-keyfeatures-block">
              <span className="ic-pill">KEY FEATURES</span>
              <div className="ic-key-features">
                {cat.keyFeatures.map((f) => {
                  const FIcon = f.icon;
                  return (
                    <div className="ic-kf-item" key={f.label}>
                      <span className="ic-kf-icon">
                        <FIcon size={16} strokeWidth={1.8} />
                      </span>
                      <div className="ic-kf-label">{f.label}</div>
                      <div className="ic-kf-sub">{f.sub || ""}</div>
                    </div>
                  );
                })}
              </div>
            </div>

            <Link
              className="ic-link"
              to={cat.link}
              onClick={() => window.scrollTo(0, 0)}
            >
              {cat.linkText} <ArrowRight size={14} strokeWidth={2.2} />
            </Link>
            </div>
          </div>
          );
        })}
      </div>
    </section>
  );
}
