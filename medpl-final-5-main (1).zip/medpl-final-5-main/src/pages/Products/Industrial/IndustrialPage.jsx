import { useEffect } from "react";
import { useLocation } from "react-router-dom";
import NavGap from "../../../components/Layout/NavGap.jsx";
import ProductsHero from "../components/ProductsHero.jsx";
import IndustrialCategories from "./components/IndustrialCategories.jsx";
import IndustrialFeatureStrip from "./components/IndustrialFeatureStrip.jsx";
import IndustrialExcellence from "./components/IndustrialExcellence.jsx";
import CtaBanner from "../components/CtaBanner.jsx";

const NAVBAR_OFFSET = 90;

export default function IndustrialPage() {
  const location = useLocation();

  useEffect(() => {
    if (location.hash) {
      const el = document.getElementById(location.hash.slice(1));
      if (el) {
        const top = el.getBoundingClientRect().top + window.scrollY - NAVBAR_OFFSET;
        window.scrollTo({ top, behavior: "smooth" });
        return;
      }
    }
    window.scrollTo(0, 0);
  }, [location.pathname, location.hash]);

  return (
    <div className="industrial-page">
      <NavGap />
      <ProductsHero />
      <IndustrialCategories />
      <IndustrialFeatureStrip />
      <IndustrialExcellence />
      <CtaBanner />
    </div>
  );
}
