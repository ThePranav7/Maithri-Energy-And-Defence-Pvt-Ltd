import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './SodiumIonDetailModal.css';
import heroImage from '../assets/sodium-ion-bms.webp';
import {
  CloseIcon,
  ArrowIcon,
  ShieldIcon,
  ChipIcon,
  PuzzleIcon,
  GearIcon,
  BoltIcon,
  GaugeIcon,
  BatteryIcon,
  ThermometerIcon,
  WifiIcon,
  DatabaseIcon,
  RangeIcon,
  CartIcon,
  TruckIcon,
  ForkliftIcon,
  ShipIcon,
  FactoryIcon,
  RobotIcon,
  HeadsetIcon,
} from './SodiumIcons.jsx';

const topHighlights = [
  { icon: ShieldIcon, title: 'Safe & Reliable', desc: 'Advanced protection for people & equipment' },
  { icon: ChipIcon, title: 'Intelligent', desc: 'Smart algorithms for optimum performance' },
  { icon: PuzzleIcon, title: 'Flexible & Scalable', desc: 'From 2 cells to 256 cells & beyond' },
  { icon: GearIcon, title: 'Built For Industry', desc: 'Rugged design for harsh environments' },
  { icon: BoltIcon, title: 'Low Power Design', desc: 'Optimized power for longer battery life' },
];

const products = [
  {
    id: 'pb-06-10',
    variant: 'navy',
    family: 'NaBM-PB (06S–10S)',
    tag: 'Passive Balancing BMS',
    model: 'TTNaB610SBMS',
    desc: '6S–10S Passive Balancing · Na-Ion Compatible',
    comm: 'SMBUS / RS232 / CAN',
    specs: [
      { icon: BoltIcon, label: '15–50VDC' },
      { icon: BatteryIcon, label: '150Ah Max Capacity' },
      { icon: ThermometerIcon, label: '2 Temp Sensors' },
    ],
    footer: '6–10 CELLS · PASSIVE · 20mA BALANCING',
  },
  {
    id: 'pb-9-15',
    variant: 'navy',
    family: 'NaBM-PB (9S–15S)',
    tag: 'Passive Balancing BMS',
    model: 'TTNaB915SBMS',
    desc: '9S–15S Passive Balancing · Na-Ion Compatible',
    comm: 'SMBUS / RS232 / CAN',
    specs: [
      { icon: BoltIcon, label: '18–75VDC' },
      { icon: BatteryIcon, label: '250Ah Max Capacity' },
      { icon: ThermometerIcon, label: '3 Temp Sensors' },
    ],
    footer: '9–15 CELLS · PASSIVE · 20mA BALANCING',
  },
  {
    id: 'ab-6-16',
    variant: 'green',
    family: 'NaEV-AB (6S–16S)',
    tag: 'Active Balancing BMS',
    model: 'TTNaEV616SBMSA',
    desc: '6S–16S Active Balancing · Na-Ion Compatible',
    comm: 'CAN / RS485 / RS232',
    specs: [
      { icon: BoltIcon, label: '12–80VDC' },
      { icon: BatteryIcon, label: '250Ah Max Capacity' },
      { icon: ThermometerIcon, label: '8 Temp Sensors' },
      { icon: GaugeIcon, label: '5000mA Active Balancing' },
    ],
    footer: '6–16 CELLS · ACTIVE · 5000mA BALANCING',
  },
  {
    id: 'pb-12-32',
    variant: 'navy',
    family: 'NaEV-PB (12S–32S)',
    tag: 'Passive Balancing BMS',
    model: 'TTNaEV1232SBMSP',
    desc: '12S–32S Passive Balancing · Na-Ion Compatible',
    comm: 'CAN / RS232 / Bluetooth',
    specs: [
      { icon: BoltIcon, label: '24–135VDC' },
      { icon: BatteryIcon, label: '250Ah Max Capacity' },
      { icon: ThermometerIcon, label: '16 Temp Sensors' },
      { icon: GaugeIcon, label: '200A Cont. Mosfet' },
    ],
    footer: '12–32 CELLS · PASSIVE · 1000mA BALANCING',
  },
  {
    id: 'pb-2-4',
    variant: 'navy',
    family: 'NaBM-PB (2S–4S)',
    tag: 'Passive Balancing BMS',
    model: 'TTNaB24SBMS',
    desc: '2S–4S Passive Balancing · Na-Ion Compatible',
    comm: 'SMBUS',
    specs: [
      { icon: BoltIcon, label: '6–14.4VDC Nominal' },
      { icon: BatteryIcon, label: '35Ah Max Capacity' },
      { icon: ThermometerIcon, label: '1 Temp Sensor' },
    ],
    footer: '2–4 CELLS · PASSIVE · 20mA BALANCING',
  },
  {
    id: 'daisy-chain',
    variant: 'green',
    family: 'Na-MT Daisy-Chain BMS',
    tag: 'Modular BMS (6–256 Cells)',
    model: 'TTDC616SBMS',
    desc: 'Daisy-Chain Architecture · Na-Ion Compatible',
    comm: 'CAN / RS232',
    specs: [
      { icon: BoltIcon, label: '12–1200VDC (Chain-dependent)' },
      { icon: BatteryIcon, label: '250Ah Max Capacity' },
      { icon: PuzzleIcon, label: 'Modular DMB + BCU' },
    ],
    footer: '6–256 CELLS · MODULAR · PASSIVE',
  },
];

const comparisonTable = {
  columns: products.map((p) => p.family),
  rows: [
    { label: 'Cells in Series', values: ['6 – 10', '9 – 15', '6 – 16', '12 – 32', '2 – 4', '6 – 256'] },
    { label: 'System Voltage', values: ['15 – 50 VDC', '18 – 75 VDC', '12 – 80 VDC', '24 – 135 VDC', '6 – 14.4 VDC (Nominal)', '12 – 1200 VDC (Chain-dependent)'] },
    { label: 'Capacity (Max)', values: ['150Ah', '250Ah', '250Ah', '250Ah', '30Ah', '250Ah'] },
    { label: 'Balancing Type', values: ['Passive', 'Passive', 'Active', 'Passive', 'Passive', 'Passive'] },
    { label: 'Balancing Current (Max)', values: ['20mA @ 4.2VDC', '20mA @ 4.2VDC', '5000mA @ 4.2VDC', '1000mA @ 4.2VDC', '20mA @ 3.6VDC', '(Passive)'] },
    { label: 'Temp Sensors', values: ['2', '3', '8', '16', '1', 'Per-module'] },
    { label: 'Communication', values: ['SMBUS / RS232 / CAN', 'SMBUS / RS232 / CAN', 'CAN / RS485 / RS232', 'CAN / RS232 / Bluetooth', 'SMBUS', 'Daisy-Chain / CAN / RS232'] },
    { label: 'Operating Temperature', values: ['−40°C to +85°C', '−40°C to +85°C', '−40°C to +85°C', '−40°C to +85°C', '−40°C to +85°C', '−40°C to +85°C'] },
    { label: 'Key Highlights', values: ['Compact, cost-effective', 'Medium voltage range', 'High current active balancing', '200A continuous (Mosfet), Bluetooth support', 'Low voltage compact', 'Scalable up to 256 cells'] },
  ],
};

const keyFeatures = [
  { icon: GaugeIcon, name: 'Accurate Measurements', desc: 'Cell voltage ±2mV accuracy, precise current & temperature monitoring' },
  { icon: ShieldIcon, name: 'Safety First', desc: 'Monitors & handles safety-critical error modes with proactive protection' },
  { icon: WifiIcon, name: 'Smart Communication', desc: 'CAN 2.0A/B, RS232, RS485, ModBus, Bluetooth (select models)' },
  { icon: DatabaseIcon, name: 'Data Logging', desc: 'Historical data storage for analytics, diagnostics & performance tracking' },
  { icon: RangeIcon, name: 'Wide Operating Range', desc: '−40°C to +85°C operational temperature range' },
  { icon: BoltIcon, name: 'Low Power Design', desc: 'Optimized power consumption for longer battery life' },
  { icon: GearIcon, name: 'Flexible & Configurable', desc: 'User-configurable I/Os and battery parameters for diverse applications' },
];

const applications = [
  { icon: CartIcon, name: 'Utility & Golf Carts' },
  { icon: TruckIcon, name: 'Commercial Trucks' },
  { icon: ForkliftIcon, name: 'Forklifts & Industrial Vehicles' },
  { icon: ShipIcon, name: 'Marine & Defense Vessels' },
  { icon: FactoryIcon, name: 'Energy Storage Systems' },
  { icon: RobotIcon, name: 'Robotics & Automation' },
];

function TopHighlight({ icon: IconCmp, title, desc }) {
  return (
    <div className="nabms-tophi">
      <span className="nabms-tophi-icon">
        <IconCmp />
      </span>
      <div className="nabms-tophi-text">
        <p className="nabms-tophi-title">{title}</p>
        <p className="nabms-tophi-desc">{desc}</p>
      </div>
    </div>
  );
}

function ProductCard({ p }) {
  return (
    <div className="nabms-card">
      <div className={`nabms-card-head nabms-card-head--${p.variant}`}>
        <p className="nabms-card-family">{p.family}</p>
        <p className="nabms-card-tag">{p.tag}</p>
      </div>
      <div className="nabms-card-body">
        <p className="nabms-card-model">{p.model}</p>
        <p className="nabms-card-desc">{p.desc}</p>
        <p className="nabms-card-comm">{p.comm}</p>
        <div className="nabms-card-specs">
          {p.specs.map((s, i) => (
            <div className="nabms-card-spec" key={i}>
              <span className="nabms-card-spec-icon">
                <s.icon />
              </span>
              <span>{s.label}</span>
            </div>
          ))}
        </div>
        <p className="nabms-card-footer">{p.footer}</p>
      </div>
    </div>
  );
}

export default function SodiumIonDetailModal({ isOpen, onClose }) {
  const navigate = useNavigate();

  const goToContact = () => {
    onClose();
    navigate('/contact#contact-details');
  };

  useEffect(() => {
    if (!isOpen) return undefined;
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  useEffect(() => {
    if (!isOpen) return undefined;
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = prevOverflow;
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const handleBackdropClick = (e) => {
    if (e.target === e.currentTarget) onClose();
  };

  return (
    <div className="nabms-backdrop" onMouseDown={handleBackdropClick}>
      <div className="nabms-dialog" role="dialog" aria-modal="true" aria-labelledby="nabms-title">
        <button className="nabms-close" onClick={onClose} aria-label="Close details">
          <CloseIcon />
        </button>

        <div className="nabms-hero">
          <img src={heroImage} alt="Sodium-ion Battery Management System hardware" />
          <div className="nabms-hero-overlay">
            <h2 className="nabms-title" id="nabms-title">
              Sodium-ion BMS
            </h2>
            <p className="nabms-tagline">Advanced BMS Solutions for Automotive &amp; Industrial Applications</p>
          </div>
        </div>

        <div className="nabms-body">
          <div className="nabms-tophi-row">
            {topHighlights.map((h) => (
              <TopHighlight key={h.title} {...h} />
            ))}
          </div>

          <div className="nabms-section">
            <span className="nabms-section-badge">PRODUCT RANGE</span>
            <div className="nabms-card-grid">
              {products.map((p) => (
                <ProductCard key={p.id} p={p} />
              ))}
            </div>
          </div>

          <div className="nabms-section">
            <span className="nabms-section-badge">TECHNICAL COMPARISON</span>
            <div className="nabms-table-wrap">
              <table className="nabms-table">
                <thead>
                  <tr>
                    <th>Parameter</th>
                    {comparisonTable.columns.map((c) => (
                      <th key={c}>{c}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {comparisonTable.rows.map((row) => (
                    <tr key={row.label}>
                      <td className="nabms-table-rowhead">{row.label}</td>
                      {row.values.map((v, i) => (
                        <td key={i}>{v}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="nabms-columns">
            <div className="nabms-column">
              <span className="nabms-section-badge">KEY FEATURES</span>
              <ul className="nabms-list">
                {keyFeatures.map((f) => (
                  <li key={f.name} className="nabms-list-item">
                    <span className="nabms-list-icon">
                      <f.icon />
                    </span>
                    <div className="nabms-list-text">
                      <p className="nabms-list-name">{f.name}</p>
                      <p className="nabms-list-desc">{f.desc}</p>
                    </div>
                  </li>
                ))}
              </ul>
            </div>

            <div className="nabms-column">
              <span className="nabms-section-badge">TYPICAL APPLICATIONS</span>
              <div className="nabms-app-grid">
                {applications.map((a) => (
                  <div className="nabms-app-cell" key={a.name}>
                    <span className="nabms-app-icon">
                      <a.icon />
                    </span>
                    <p className="nabms-app-name">{a.name}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="nabms-banner">
            <span className="nabms-banner-icon">
              <HeadsetIcon />
            </span>
            <div className="nabms-banner-text">
              <p className="nabms-banner-title">Need help selecting the right Sodium-ion BMS?</p>
              <p className="nabms-banner-subtitle">
                Talk to our engineering team about the right configuration for your application.
              </p>
            </div>
            <button className="nabms-banner-cta" onClick={goToContact}>
              Contact Us
              <ArrowIcon />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
