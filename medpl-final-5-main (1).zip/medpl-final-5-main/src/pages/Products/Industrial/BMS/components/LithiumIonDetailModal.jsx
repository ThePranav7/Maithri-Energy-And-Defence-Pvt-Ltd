import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './LithiumIonDetailModal.css';
import heroImage from '../assets/lithium-ion-bms.webp';
import {
  CloseIcon,
  ArrowIcon,
  ShieldIcon,
  ChipIcon,
  PuzzleIcon,
  GearIcon,
  BoltIcon,
  GaugeIcon,
  BatteryIcon,
  ThermometerIcon,
  WifiIcon,
  DatabaseIcon,
  RangeIcon,
  CartIcon,
  TruckIcon,
  ForkliftIcon,
  ShipIcon,
  FactoryIcon,
  RobotIcon,
  HeadsetIcon,
} from './SodiumIcons.jsx';

const topHighlights = [
  { icon: ShieldIcon, title: 'Safe & Reliable', desc: 'Advanced protection for people & equipment' },
  { icon: ChipIcon, title: 'Intelligent', desc: 'Smart algorithms for optimum performance' },
  { icon: PuzzleIcon, title: 'Flexible & Scalable', desc: 'From 2 cells to 256 cells & beyond' },
  { icon: GearIcon, title: 'Built For Industry', desc: 'Rugged design for harsh environments' },
  { icon: BoltIcon, title: 'Low Power Design', desc: 'Optimized power for longer battery life' },
];

const products = [
  {
    id: 'pb-06-10',
    variant: 'navy',
    family: 'LiBM-PB (06S–10S)',
    tag: 'Passive Balancing BMS',
    model: 'TTLiB610SBMS',
    desc: '6S–10S Passive Balancing · Li-Ion & LiFePO4 Compatible',
    comm: 'SMBUS / RS232 / CAN',
    specs: [
      { icon: BoltIcon, label: '15–50VDC' },
      { icon: BatteryIcon, label: '150Ah Max Capacity' },
      { icon: ThermometerIcon, label: '2 Temp Sensors' },
    ],
    footer: '6–10 CELLS · PASSIVE · 20mA BALANCING',
  },
  {
    id: 'pb-9-15',
    variant: 'navy',
    family: 'LiBM-PB (9S–15S)',
    tag: 'Passive Balancing BMS',
    model: 'TTLiB915SBMS',
    desc: '9S–15S Passive Balancing · Li-Ion & LiFePO4 Compatible',
    comm: 'SMBUS / RS232 / CAN',
    specs: [
      { icon: BoltIcon, label: '18–75VDC' },
      { icon: BatteryIcon, label: '250Ah Max Capacity' },
      { icon: ThermometerIcon, label: '3 Temp Sensors' },
    ],
    footer: '9–15 CELLS · PASSIVE · 20mA BALANCING',
  },
  {
    id: 'ab-6-16',
    variant: 'green',
    family: 'LiEV-AB (6S–16S)',
    tag: 'Active Balancing BMS',
    model: 'TTLiEV616SBMSA',
    desc: '6S–16S Active Balancing · Li-Ion & LiFePO4 Compatible',
    comm: 'CAN / RS485 / RS232',
    specs: [
      { icon: BoltIcon, label: '12–80VDC' },
      { icon: BatteryIcon, label: '250Ah Max Capacity' },
      { icon: ThermometerIcon, label: '8 Temp Sensors' },
      { icon: GaugeIcon, label: '5000mA Active Balancing' },
    ],
    footer: '6–16 CELLS · ACTIVE · 5000mA BALANCING',
  },
  {
    id: 'pb-12-32',
    variant: 'navy',
    family: 'LiEV-PB (12S–32S)',
    tag: 'Passive Balancing BMS',
    model: 'TTLiEV1232SBMSP',
    desc: '12S–32S Passive Balancing · Li-Ion & LiFePO4 Compatible',
    comm: 'CAN / RS232 / Bluetooth',
    specs: [
      { icon: BoltIcon, label: '24–135VDC' },
      { icon: BatteryIcon, label: '250Ah Max Capacity' },
      { icon: ThermometerIcon, label: '16 Temp Sensors' },
      { icon: GaugeIcon, label: '200A Cont. Mosfet' },
    ],
    footer: '12–32 CELLS · PASSIVE · 1000mA BALANCING',
  },
  {
    id: 'pb-2-4',
    variant: 'navy',
    family: 'LiBM-PB (2S–4S)',
    tag: 'Passive Balancing BMS',
    model: 'TTLiB24SBMS',
    desc: '2S–4S Passive Balancing · Li-Ion & LiFePO4 Compatible',
    comm: 'SMBUS',
    specs: [
      { icon: BoltIcon, label: '6–14.4VDC Nominal' },
      { icon: BatteryIcon, label: '35Ah Max Capacity' },
      { icon: ThermometerIcon, label: '1 Temp Sensor' },
    ],
    footer: '2–4 CELLS · PASSIVE · 20mA BALANCING',
  },
  {
    id: 'daisy-chain',
    variant: 'green',
    family: 'LI-MT Daisy-Chain BMS',
    tag: 'Modular BMS (6–256 Cells)',
    model: 'TTDC616SBMS',
    desc: 'Daisy-Chain Architecture · Li-Ion & LiFePO4 Compatible',
    comm: 'CAN / RS232',
    specs: [
      { icon: BoltIcon, label: '12–1200VDC (Chain-dependent)' },
      { icon: BatteryIcon, label: '250Ah Max Capacity' },
      { icon: PuzzleIcon, label: 'Modular DMB + BCU' },
    ],
    footer: '6–256 CELLS · MODULAR · PASSIVE',
  },
];

const comparisonTable = {
  columns: products.map((p) => p.family),
  rows: [
    { label: 'Cells in Series', values: ['6 – 10', '9 – 15', '6 – 16', '12 – 32', '2 – 4', '6 – 256'] },
    { label: 'System Voltage', values: ['15 – 50 VDC', '18 – 75 VDC', '12 – 80 VDC', '24 – 135 VDC', '6 – 14.4 VDC (Nominal)', '12 – 1200 VDC (Chain-dependent)'] },
    { label: 'Capacity (Max)', values: ['150Ah', '250Ah', '250Ah', '250Ah', '30Ah', '250Ah'] },
    { label: 'Balancing Type', values: ['Passive', 'Passive', 'Active', 'Passive', 'Passive', 'Passive'] },
    { label: 'Balancing Current (Max)', values: ['20mA @ 4.2VDC', '20mA @ 4.2VDC', '5000mA @ 4.2VDC', '1000mA @ 4.2VDC', '20mA @ 3.6VDC', '(Passive)'] },
    { label: 'Temp Sensors', values: ['2', '3', '8', '16', '1', 'Per-module'] },
    { label: 'Communication', values: ['SMBUS / RS232 / CAN', 'SMBUS / RS232 / CAN', 'CAN / RS485 / RS232', 'CAN / RS232 / Bluetooth', 'SMBUS', 'Daisy-Chain / CAN / RS232'] },
    { label: 'Operating Temperature', values: ['−40°C to +85°C', '−40°C to +85°C', '−40°C to +85°C', '−40°C to +85°C', '−40°C to +85°C', '−40°C to +85°C'] },
    { label: 'Key Highlights', values: ['Compact, cost-effective', 'Medium voltage range', 'High current active balancing', '200A continuous (Mosfet), Bluetooth support', 'Low voltage compact', 'Scalable up to 256 cells'] },
  ],
};

const keyFeatures = [
  { icon: GaugeIcon, name: 'Accurate Measurements', desc: 'Cell voltage ±2mV accuracy, precise current & temperature monitoring' },
  { icon: ShieldIcon, name: 'Safety First', desc: 'Monitors & handles safety-critical error modes with proactive protection' },
  { icon: WifiIcon, name: 'Smart Communication', desc: 'CAN 2.0A/B, RS232, RS485, ModBus, Bluetooth (select models)' },
  { icon: DatabaseIcon, name: 'Data Logging', desc: 'Historical data storage for analytics, diagnostics & performance tracking' },
  { icon: RangeIcon, name: 'Wide Operating Range', desc: '−40°C to +85°C operational temperature range' },
  { icon: BoltIcon, name: 'Low Power Design', desc: 'Optimized power consumption for longer battery life' },
  { icon: GearIcon, name: 'Flexible & Configurable', desc: 'User-configurable I/Os and battery parameters for diverse applications' },
];

const applications = [
  { icon: CartIcon, name: 'Utility & Golf Carts' },
  { icon: TruckIcon, name: 'Commercial Trucks' },
  { icon: ForkliftIcon, name: 'Forklifts & Industrial Vehicles' },
  { icon: ShipIcon, name: 'Marine & Defense Vessels' },
  { icon: BatteryIcon, name: 'Energy Storage Systems' },
  { icon: RobotIcon, name: 'Robotics & Automation' },
];

function TopHighlight({ icon: IconCmp, title, desc }) {
  return (
    <div className="libms-tophi">
      <span className="libms-tophi-icon">
        <IconCmp />
      </span>
      <div className="libms-tophi-text">
        <p className="libms-tophi-title">{title}</p>
        <p className="libms-tophi-desc">{desc}</p>
      </div>
    </div>
  );
}

function ProductCard({ p }) {
  return (
    <div className="libms-card">
      <div className={`libms-card-head libms-card-head--${p.variant}`}>
        <p className="libms-card-family">{p.family}</p>
        <p className="libms-card-tag">{p.tag}</p>
      </div>
      <div className="libms-card-body">
        <p className="libms-card-model">{p.model}</p>
        <p className="libms-card-desc">{p.desc}</p>
        <p className="libms-card-comm">{p.comm}</p>
        <div className="libms-card-specs">
          {p.specs.map((s, i) => (
            <div className="libms-card-spec" key={i}>
              <span className="libms-card-spec-icon">
                <s.icon />
              </span>
              <span>{s.label}</span>
            </div>
          ))}
        </div>
        <p className="libms-card-footer">{p.footer}</p>
      </div>
    </div>
  );
}

export default function LithiumIonDetailModal({ isOpen, onClose }) {
  const navigate = useNavigate();

  const goToContact = () => {
    onClose();
    navigate('/contact#contact-details');
  };

  useEffect(() => {
    if (!isOpen) return undefined;
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  useEffect(() => {
    if (!isOpen) return undefined;
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = prevOverflow;
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const handleBackdropClick = (e) => {
    if (e.target === e.currentTarget) onClose();
  };

  return (
    <div className="libms-backdrop" onMouseDown={handleBackdropClick}>
      <div className="libms-dialog" role="dialog" aria-modal="true" aria-labelledby="libms-title">
        <button className="libms-close" onClick={onClose} aria-label="Close details">
          <CloseIcon />
        </button>

        <div className="libms-hero">
          <img src={heroImage} alt="Lithium-ion Battery Management System hardware" />
          <div className="libms-hero-overlay">
            <h2 className="libms-title" id="libms-title">
              Lithium-ion BMS
            </h2>
            <p className="libms-tagline">
              High-performance Lithium Battery Management Systems designed for safety, reliability and
              long life — precise monitoring, intelligent control and maximum protection for Li-ion
              battery packs across a wide range of applications.
            </p>
          </div>
        </div>

        <div className="libms-body">
          <div className="libms-tophi-row">
            {topHighlights.map((h) => (
              <TopHighlight key={h.title} {...h} />
            ))}
          </div>

          <div className="libms-section">
            <span className="libms-section-badge">PRODUCT RANGE</span>
            <div className="libms-card-grid">
              {products.map((p) => (
                <ProductCard key={p.id} p={p} />
              ))}
            </div>
          </div>

          <div className="libms-section">
            <span className="libms-section-badge">TECHNICAL COMPARISON</span>
            <div className="libms-table-wrap">
              <table className="libms-table">
                <thead>
                  <tr>
                    <th>Parameter</th>
                    {comparisonTable.columns.map((c) => (
                      <th key={c}>{c}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {comparisonTable.rows.map((row) => (
                    <tr key={row.label}>
                      <td className="libms-table-rowhead">{row.label}</td>
                      {row.values.map((v, i) => (
                        <td key={i}>{v}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="libms-columns">
            <div className="libms-column">
              <span className="libms-section-badge">KEY FEATURES</span>
              <ul className="libms-list">
                {keyFeatures.map((f) => (
                  <li key={f.name} className="libms-list-item">
                    <span className="libms-list-icon">
                      <f.icon />
                    </span>
                    <div className="libms-list-text">
                      <p className="libms-list-name">{f.name}</p>
                      <p className="libms-list-desc">{f.desc}</p>
                    </div>
                  </li>
                ))}
              </ul>
            </div>

            <div className="libms-column">
              <span className="libms-section-badge">TYPICAL APPLICATIONS</span>
              <div className="libms-app-grid">
                {applications.map((a) => (
                  <div className="libms-app-cell" key={a.name}>
                    <span className="libms-app-icon">
                      <a.icon />
                    </span>
                    <p className="libms-app-name">{a.name}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="libms-banner">
            <span className="libms-banner-icon">
              <HeadsetIcon />
            </span>
            <div className="libms-banner-text">
              <p className="libms-banner-title">Need help selecting the right Lithium-ion BMS?</p>
              <p className="libms-banner-subtitle">
                Talk to our engineering team about the right configuration for your application.
              </p>
            </div>
            <button className="libms-banner-cta" onClick={goToContact}>
              Contact Us
              <ArrowIcon />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
