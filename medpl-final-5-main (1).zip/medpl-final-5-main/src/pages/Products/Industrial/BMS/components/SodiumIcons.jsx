import React from 'react';

const base = {
  viewBox: '0 0 24 24',
  fill: 'none',
  stroke: 'currentColor',
  strokeWidth: 1.7,
  strokeLinecap: 'round',
  strokeLinejoin: 'round',
};

export const CloseIcon = (p) => (
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...p}>
    <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

export const ArrowIcon = (p) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" {...p}>
    <path d="M5 12h13" />
    <path d="M13 6l6 6-6 6" />
  </svg>
);

export const ShieldIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6l7-3z" />
  </svg>
);

export const ChipIcon = (p) => (
  <svg {...base} {...p}>
    <rect x="7" y="7" width="10" height="10" rx="1.4" />
    <path d="M9 3v3M15 3v3M9 18v3M15 18v3M3 9h3M3 15h3M18 9h3M18 15h3" />
  </svg>
);

export const PuzzleIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M9 4h4a1.5 1.5 0 0 1 0 3 1.5 1.5 0 0 0 0 3h4v4a1.5 1.5 0 0 1-3 0 1.5 1.5 0 0 0-3 0v4H7v-4a1.5 1.5 0 0 0-3 0 1.5 1.5 0 0 1 0-3h3V7H4a1.5 1.5 0 0 1 0-3h5z" />
  </svg>
);

export const GearIcon = (p) => (
  <svg {...base} {...p}>
    <circle cx="12" cy="12" r="3" />
    <path d="M19 12a7 7 0 0 0-.1-1.2l2-1.5-2-3.4-2.3.9a7 7 0 0 0-2.1-1.2L14 3h-4l-.5 2.6a7 7 0 0 0-2.1 1.2l-2.3-.9-2 3.4 2 1.5A7 7 0 0 0 5 12c0 .4 0 .8.1 1.2l-2 1.5 2 3.4 2.3-.9c.6.5 1.3.9 2.1 1.2L10 21h4l.5-2.6c.8-.3 1.5-.7 2.1-1.2l2.3.9 2-3.4-2-1.5c.1-.4.1-.8.1-1.2z" />
  </svg>
);

export const BoltIcon = (p) => (
  <svg {...base} fill="none" {...p}>
    <path d="M13 2 4 14h6l-1 8 9-12h-6l1-8z" />
  </svg>
);

export const GaugeIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M4 15a8 8 0 1 1 16 0" />
    <path d="M12 15l3.5-4.5" />
    <circle cx="12" cy="15" r="1" />
  </svg>
);

export const BatteryIcon = (p) => (
  <svg {...base} {...p}>
    <rect x="2.5" y="8" width="16" height="8" rx="1.4" />
    <path d="M21 10.5v3" />
    <path d="M6 11v2M9.5 11v2M13 11v2" />
  </svg>
);

export const ThermometerIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M12 3a2 2 0 0 0-2 2v9.1a4 4 0 1 0 4 0V5a2 2 0 0 0-2-2z" />
    <path d="M12 12v4" />
  </svg>
);

export const WifiIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M4 9a13 13 0 0 1 16 0" />
    <path d="M7.2 12.5a9 9 0 0 1 9.6 0" />
    <path d="M10 16a4.5 4.5 0 0 1 4 0" />
    <circle cx="12" cy="19" r="1" fill="currentColor" stroke="none" />
  </svg>
);

export const DatabaseIcon = (p) => (
  <svg {...base} {...p}>
    <ellipse cx="12" cy="5.5" rx="7.5" ry="2.5" />
    <path d="M4.5 5.5V18c0 1.4 3.4 2.5 7.5 2.5s7.5-1.1 7.5-2.5V5.5" />
    <path d="M4.5 12c0 1.4 3.4 2.5 7.5 2.5s7.5-1.1 7.5-2.5" />
  </svg>
);

export const RangeIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M12 3v18" />
    <path d="M7 6l-3.5 6L7 18" />
    <path d="M17 6l3.5 6L17 18" />
  </svg>
);

export const CartIcon = (p) => (
  <svg {...base} {...p}>
    <circle cx="7" cy="7" r="4" />
    <path d="M3 15h8v5H3z" />
    <path d="M11 17h5" />
  </svg>
);

export const TruckIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M2 8h11v8H2z" />
    <path d="M13 11h4l3 3v2h-7z" />
    <circle cx="6" cy="18" r="1.6" />
    <circle cx="16.5" cy="18" r="1.6" />
  </svg>
);

export const ForkliftIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M3 3v13" />
    <path d="M3 9h5v7H3z" />
    <path d="M8 14h6l3-6" />
    <circle cx="6" cy="19" r="1.4" />
    <circle cx="15" cy="19" r="1.4" />
  </svg>
);

export const ShipIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M4 13l1.5 6h13L20 13" />
    <path d="M6 13V4h5v9" />
    <path d="M2 13h20" />
  </svg>
);

export const FactoryIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M3 21V10l6 4v-4l6 4V6l6 4v11z" />
    <path d="M3 21h18" />
  </svg>
);

export const RobotIcon = (p) => (
  <svg {...base} {...p}>
    <rect x="5" y="9" width="14" height="10" rx="2" />
    <path d="M12 5v4" />
    <circle cx="12" cy="4" r="1.2" />
    <circle cx="9" cy="14" r="1.2" fill="currentColor" stroke="none" />
    <circle cx="15" cy="14" r="1.2" fill="currentColor" stroke="none" />
    <path d="M2 12v3M22 12v3" />
  </svg>
);

export const HeadsetIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M4 13v-1a8 8 0 0 1 16 0v1" />
    <rect x="3" y="13" width="4" height="6" rx="1.2" />
    <rect x="17" y="13" width="4" height="6" rx="1.2" />
    <path d="M20 19v1a2 2 0 0 1-2 2h-3" />
  </svg>
);
