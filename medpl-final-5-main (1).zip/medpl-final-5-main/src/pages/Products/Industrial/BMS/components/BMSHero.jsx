import HeroContent from './HeroContent.jsx'
import ProductVisual from './ProductVisual.jsx'

export default function BMSHero() {
  return (
    <section className="relative w-full bg-white overflow-hidden">
      <div className="relative flex items-stretch min-h-96">
        <div className="relative z-10 w-full md:w-3/5 bg-white flex items-center">
          <HeroContent />
        </div>
        <ProductVisual />
      </div>
    </section>
  )
}
