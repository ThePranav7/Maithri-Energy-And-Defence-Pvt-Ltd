import { LineChart, ShieldCheck, BatteryCharging, LayoutGrid, UploadCloud } from 'lucide-react'

const CAPABILITIES = [
  {
    icon: LineChart,
    title: 'Real-time Monitoring',
    description: 'Continuous monitoring of all critical battery parameters',
  },
  {
    icon: ShieldCheck,
    title: 'Comprehensive Protection',
    description: 'Electrical, thermal and functional safety at every level',
  },
  {
    icon: BatteryCharging,
    title: 'Cell Balancing',
    description: 'Active balancing for consistent performance and longer life',
  },
  {
    icon: LayoutGrid,
    title: 'Flexible Integration',
    description: 'Easy integration with multiple battery chemistries and systems',
  },
  {
    icon: UploadCloud,
    title: 'Data & Diagnostics',
    description: 'Data logging, diagnostics and remote firmware updates',
  },
]

export default function KeyCapabilities() {
  return (
    <section className="w-full bg-white py-10 px-6 sm:px-10">
      <div className="max-w-6xl mx-auto bg-slate-50 rounded-2xl px-6 sm:px-10 py-8 sm:py-10">
        <h2 className="text-lg sm:text-xl font-extrabold text-navy-900 text-center mb-8">
          Key Capabilities
        </h2>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-x-4 gap-y-8">
          {CAPABILITIES.map(({ icon: Icon, title, description }) => (
            <div
              key={title}
              tabIndex={0}
              className="group flex flex-col items-center text-center gap-2.5 cursor-pointer rounded-lg py-2 transition-colors duration-300 hover:bg-white focus:bg-white focus:outline-none"
            >
              <div className="w-10 h-10 rounded-md flex items-center justify-center transition-colors duration-300 group-hover:bg-accent-500/10">
                <Icon
                  size={22}
                  strokeWidth={1.75}
                  className="text-navy-800 transition-colors duration-300 group-hover:text-accent-500"
                />
              </div>
              <p className="text-xs sm:text-sm font-bold text-navy-900 leading-tight">{title}</p>
              <p className="text-[11px] sm:text-xs leading-snug text-slate-500">{description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
