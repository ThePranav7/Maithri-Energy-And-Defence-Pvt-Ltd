import productImage from '../assets/bms-hardware.webp'

export default function ProductVisual() {
  return (
    <div className="hidden md:block relative w-2/5 shrink-0 overflow-hidden">
      <div className="absolute inset-y-0 left-0 w-24 bg-gradient-to-r from-white to-transparent z-10" />
      <img
        src={productImage}
        alt="BMS battery management hardware modules on a data center floor"
        className="w-full h-full object-cover object-center"
      />
    </div>
  )
}
