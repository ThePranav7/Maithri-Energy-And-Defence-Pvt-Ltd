import { ShieldCheck, Activity, SlidersHorizontal, Cpu } from 'lucide-react'

const FEATURES = [
  {
    icon: ShieldCheck,
    title: 'Enhanced Safety',
    description: 'Multi-level protection against electrical and thermal risks',
  },
  {
    icon: Activity,
    title: 'Accurate Monitoring',
    description: 'Real-time monitoring of voltage, current, temperature and health parameters',
  },
  {
    icon: SlidersHorizontal,
    title: 'Active Balancing',
    description: 'Intelligent cell balancing for improved performance and longer life',
  },
  {
    icon: Cpu,
    title: 'Smart & Reliable',
    description: 'Robust hardware with advanced algorithms for critical applications',
  },
]

export default function FeatureGrid() {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 gap-x-6 gap-y-5 pt-2">
      {FEATURES.map(({ icon: Icon, title, description }) => (
        <div key={title} className="flex flex-col gap-2">
          <div className="w-9 h-9 rounded-full bg-blue-50 flex items-center justify-center">
            <Icon size={16} className="text-blue-700" strokeWidth={2} />
          </div>
          <p className="text-sm font-semibold text-slate-900 leading-tight">{title}</p>
          <p className="text-xs leading-snug text-slate-500">{description}</p>
        </div>
      ))}
    </div>
  )
}
