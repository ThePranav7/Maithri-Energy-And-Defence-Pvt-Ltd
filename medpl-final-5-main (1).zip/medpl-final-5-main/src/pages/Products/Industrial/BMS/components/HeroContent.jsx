import FeatureGrid from './FeatureGrid.jsx'

export default function HeroContent() {
  return (
    <div className="flex flex-col gap-4 w-full px-6 sm:px-10 py-8 sm:py-10">
      <div className="flex flex-col gap-0.5">
        <h1
          className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900 leading-tight sm:leading-none whitespace-normal sm:whitespace-nowrap"
          style={{ fontFamily: "'Times New Roman', Times, serif" }}
        >
          <span className="text-blue-800 font-semibold">Battery Management System</span>
        </h1>
      </div>

      <p className="text-slate-600 text-sm sm:text-base leading-relaxed max-w-md">
        Advanced battery management systems for lithium-ion and sodium-ion
        batteries that ensure safety, reliability, and maximum performance
        throughout the battery lifecycle.
      </p>

      <FeatureGrid />
    </div>
  )
}
