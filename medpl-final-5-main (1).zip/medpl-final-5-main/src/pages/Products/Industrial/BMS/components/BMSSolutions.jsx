import { useState } from 'react'
import { CheckCircle2, ArrowRight } from 'lucide-react'
import lithiumImage from '../assets/lithium-ion-bms.webp'
import sodiumImage from '../assets/sodium-ion-bms.webp'
import SodiumIonDetailModal from './SodiumIonDetailModal.jsx'
import LithiumIonDetailModal from './LithiumIonDetailModal.jsx'

const SOLUTIONS = [
  {
    id: 'lithium-ion',
    title: 'Lithium-ion BMS',
    image: lithiumImage,
    description:
      'High-performance BMS for Li-ion batteries designed to deliver optimal safety, accuracy and efficiency.',
    features: [
      'Cell voltage, current & temperature monitoring',
      'State of Charge (SOC) & State of Health (SOH) estimation',
      'Active cell balancing',
      'Overcharge, overdischarge, overcurrent & short circuit protection',
      'CAN, RS485 & UART communication',
      'Configurable for 7S to 32S applications',
    ],
  },
  {
    id: 'sodium-ion',
    title: 'Sodium-ion BMS',
    image: sodiumImage,
    description:
      'Reliable BMS for Sodium-ion batteries with advanced protection and precise monitoring.',
    features: [
      'Accurate monitoring & cell balancing',
      'Wide operating temperature range',
      'High reliability for demanding environments',
      'Multiple protection mechanisms',
      'CAN, RS485 & UART communication',
      'Scalable for various voltage configurations',
    ],
  },
]

export default function BMSSolutions() {
  const [isSodiumModalOpen, setIsSodiumModalOpen] = useState(false)
  const [isLithiumModalOpen, setIsLithiumModalOpen] = useState(false)

  return (
    <section className="w-full bg-slate-50 py-16 px-6 sm:px-10">
      <div className="max-w-2xl mx-auto text-center flex flex-col gap-2 mb-12">
        <h2 className="text-2xl sm:text-3xl font-extrabold text-navy-900">
          Our BMS Solutions
        </h2>
        <p className="text-slate-500 text-sm sm:text-base">
          Engineered for different chemistries and application requirements.
        </p>
      </div>

      <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-7">
        {SOLUTIONS.map((solution) => (
          <article
            key={solution.id}
            className="flex flex-wrap md:flex-nowrap bg-white rounded-xl border border-slate-100 shadow-sm overflow-hidden"
          >
            <div className="w-full md:w-2/5 shrink-0 min-h-[260px] md:min-h-0">
              <img
                src={solution.image}
                alt={solution.title}
                className="w-full h-full object-cover object-center"
              />
            </div>

            <div className="flex flex-col flex-1 p-6 sm:p-7">
              <h3 className="text-lg font-bold text-navy-900 mb-2">
                {solution.title}
              </h3>
              <p className="text-sm text-slate-500 leading-relaxed mb-5">
                {solution.description}
              </p>

              <ul className="flex flex-col gap-2.5 mb-6 flex-1">
                {solution.features.map((feature) => (
                  <li key={feature} className="flex items-start gap-2 text-sm text-slate-700">
                    <CheckCircle2
                      size={17}
                      className="text-green-600 shrink-0 mt-0.5"
                    />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>

              <a
                href="#"
                onClick={(e) => {
                  e.preventDefault()
                  if (solution.id === 'sodium-ion') {
                    setIsSodiumModalOpen(true)
                  } else if (solution.id === 'lithium-ion') {
                    setIsLithiumModalOpen(true)
                  }
                }}
                className="self-start inline-flex items-center gap-2 px-5 py-2.5 rounded-md border-[1.5px] border-navy-900 text-navy-900 text-xs font-bold tracking-wide hover:bg-navy-900 hover:text-white transition-colors"
              >
                VIEW DETAILS <ArrowRight size={15} />
              </a>
            </div>
          </article>
        ))}
      </div>

      <SodiumIonDetailModal
        isOpen={isSodiumModalOpen}
        onClose={() => setIsSodiumModalOpen(false)}
      />
      <LithiumIonDetailModal
        isOpen={isLithiumModalOpen}
        onClose={() => setIsLithiumModalOpen(false)}
      />
    </section>
  )
}
