import { ArrowRight } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import hardwareImage from '../assets/bms-hardware-devices.webp'

export default function CTABanner() {
  const navigate = useNavigate();
  return (
    <section className="w-full bg-white px-6 sm:px-10 pb-12 pt-2">
      <div className="max-w-6xl mx-auto bg-navy-900 rounded-2xl relative overflow-hidden">
        <div className="flex flex-wrap md:flex-nowrap items-center gap-6 px-6 sm:px-10 py-10 md:py-8">
          <div className="w-full md:w-3/5 flex flex-col gap-3 z-10">
            <h2 className="text-xl sm:text-2xl font-extrabold text-white leading-snug">
              Intelligent Protection. Maximum Performance.
            </h2>
            <p className="text-slate-200 text-sm sm:text-base">
              Power your applications with our advanced BMS solutions.
            </p>

            <a
              href="/contact#contact-details"
              onClick={(e) => {
                e.preventDefault();
                navigate('/contact#contact-details');
              }}
              className="mt-3 self-start inline-flex items-center gap-2 px-6 py-3 rounded-md bg-white text-navy-900 text-xs font-bold tracking-wide hover:bg-slate-100 transition-colors"
            >
              TALK TO OUR EXPERTS <ArrowRight size={15} />
            </a>
          </div>

          <div className="w-full md:w-2/5 flex items-center justify-center md:justify-end">
            <img
              src={hardwareImage}
              alt="BMS hardware devices and controller boards"
              className="w-full max-w-md object-contain"
            />
          </div>
        </div>
      </div>
    </section>
  )
}
