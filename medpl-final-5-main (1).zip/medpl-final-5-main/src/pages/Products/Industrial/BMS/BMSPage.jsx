import { useEffect } from "react";
import NavGap from "../../../../components/Layout/NavGap.jsx";
import BMSHero from "./components/BMSHero.jsx";
import BMSSolutions from "./components/BMSSolutions.jsx";
import KeyCapabilities from "./components/KeyCapabilities.jsx";
import CTABanner from "./components/CTABanner.jsx";

export default function BMSPage() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="bms-page min-h-screen bg-white font-sans">
      <NavGap />
      <BMSHero />
      <BMSSolutions />
      <KeyCapabilities />
      <CTABanner />
    </div>
  );
}
