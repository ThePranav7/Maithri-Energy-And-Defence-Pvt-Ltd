import { ICON_MAP, ArrowRightIcon } from './Icons.jsx'

export default function ProductCard({ product, onViewDetails }) {
  const Icon = ICON_MAP[product.icon]

  const handleClick = (e) => {
    if (onViewDetails) {
      e.preventDefault()
      onViewDetails(product)
    }
  }

  return (
    <div className="card">
      {product.image ? (
        <img className="card-image" src={product.image} alt={product.title} />
      ) : (
        <div className="card-image-placeholder" />
      )}

      <div className="card-body">
        <div className="title-row">
          <Icon className="icon-box" />
          <h2>{product.title}</h2>
        </div>

        <p className="desc">{product.description}</p>

        <ul>
          {product.bullets.map((bullet, i) => (
            <li key={i}>{bullet}</li>
          ))}
        </ul>

        <a className="btn" href="#" onClick={handleClick}>
          View Details <ArrowRightIcon />
        </a>
      </div>
    </div>
  )
}
