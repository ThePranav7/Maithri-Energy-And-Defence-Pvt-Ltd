import React from 'react';

const base = {
  viewBox: '0 0 24 24',
  fill: 'none',
  stroke: 'currentColor',
  strokeWidth: 1.7,
  strokeLinecap: 'round',
  strokeLinejoin: 'round',
};

export const TruckIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M3 7h11v9H3z" />
    <path d="M14 11h4l3 3v2h-7z" />
    <circle cx="7.5" cy="18" r="1.6" />
    <circle cx="17.5" cy="18" r="1.6" />
  </svg>
);

export const PlugPlayIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M9 2v4M15 2v4" />
    <path d="M6 6h12v4a6 6 0 0 1-12 0V6z" />
    <path d="M12 16v3" />
    <path d="M9 21h6" />
  </svg>
);

export const WarrantyIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6l7-3z" />
    <path d="M9 12.2l2 2 4.3-4.6" />
  </svg>
);

export const SolarPanelIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M3 8l3-5h12l3 5-3 5H6l-3-5z" />
    <path d="M6 3l-3 10M18 3l3 10M12 3v10M4.4 5.7h15.2M3.7 10.3h16.6" />
  </svg>
);

export const FactoryBuildingIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M3 21V10l5 3.5V10l5 3.5V10l5 3.5V21H3z" />
    <path d="M7 21v-4M12 21v-4M17 21v-4" />
  </svg>
);

export const InfraCraneIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M4 21V9l8-3 8 4v11" />
    <path d="M4 21h16M9 21v-6h6v6" />
  </svg>
);

export const PipelineIcon = (p) => (
  <svg {...base} {...p}>
    <rect x="2" y="10" width="20" height="4" rx="2" />
    <circle cx="6" cy="12" r="1" />
    <circle cx="18" cy="12" r="1" />
    <path d="M4 6l2.5 4M20 6l-2.5 4M4 18l2.5-4M20 18l-2.5-4" />
  </svg>
);

export const MiningIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M4 21l7-13 4 7-3.5 6z" />
    <path d="M14 9l4-6 3 2-4 5.5" />
  </svg>
);

export const RoadIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M8 21L11 3M16 21L13 3" />
    <path d="M12 4v2M12 10v2M12 16v2" />
  </svg>
);

export const MiniGridIcon = (p) => (
  <svg {...base} {...p}>
    <circle cx="6" cy="6" r="2.2" />
    <circle cx="18" cy="6" r="2.2" />
    <circle cx="12" cy="18" r="2.2" />
    <path d="M7.6 7.6L10.6 16M16.4 7.6L13.4 16M8.2 6h7.6" />
  </svg>
);

export const HospitalIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M4 21V9l8-5 8 5v12" />
    <path d="M4 21h16" />
    <path d="M12 8v5M9.5 10.5h5" />
  </svg>
);

export const RecycleCycleIcon = (p) => (
  <svg {...base} {...p}>
    <circle cx="12" cy="12" r="9.3" />
    <path d="M8 13l-2 2.5L4 13M16 8l2 2.5-2.5.5" />
    <path d="M6 15.5A6 6 0 0 1 12 6h1.5M18 8.5A6 6 0 0 1 12 18h-1.5" />
  </svg>
);

export const LifespanIcon = (p) => (
  <svg {...base} {...p}>
    <circle cx="12" cy="12" r="9" />
    <path d="M12 7v5l3.2 2" />
  </svg>
);

export const PortableIcon = (p) => (
  <svg {...base} {...p}>
    <rect x="4" y="9" width="16" height="11" rx="2" />
    <path d="M8 9V6a4 4 0 0 1 8 0v3" />
  </svg>
);

export const MultiDeviceIcon = (p) => (
  <svg {...base} {...p}>
    <rect x="3" y="4" width="12" height="9" rx="1.4" />
    <rect x="16" y="8" width="5" height="9" rx="1.2" />
    <path d="M3 17h12" />
  </svg>
);

export const LightbulbIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M9 18h6M10 21h4" />
    <path d="M12 3a6 6 0 0 0-3.6 10.8c.6.5.9 1 .9 1.7h5.4c0-.7.3-1.2.9-1.7A6 6 0 0 0 12 3z" />
  </svg>
);

export const LaptopIcon = (p) => (
  <svg {...base} {...p}>
    <rect x="4" y="5" width="16" height="10" rx="1.2" />
    <path d="M2 19.5h20M9 15v2M15 15v2" />
  </svg>
);

export const MobilePhoneIcon = (p) => (
  <svg {...base} {...p}>
    <rect x="7" y="2.5" width="10" height="19" rx="2" />
    <path d="M11 19h2" />
  </svg>
);

export const FanIcon = (p) => (
  <svg {...base} {...p}>
    <circle cx="12" cy="12" r="1.6" />
    <path d="M12 10.4C11 7 9 5 6.5 5.3c-1 3 .3 5.4 3.1 6.6M13.6 12c3.4-1 5.4-3 5.1-5.5-3-1-5.4.3-6.6 3.1M12 13.6c1 3.4 3 5.4 5.5 5.1 1-3-.3-5.4-3.1-6.6M10.4 12c-3.4 1-5.4 3-5.1 5.5 3 1 5.4-.3 6.6-3.1" />
  </svg>
);

export const ProjectorIcon = (p) => (
  <svg {...base} {...p}>
    <rect x="2.5" y="8" width="14" height="8" rx="1.5" />
    <circle cx="9.5" cy="12" r="2.4" />
    <path d="M16.5 11l5-2.5v7L16.5 13" />
  </svg>
);
