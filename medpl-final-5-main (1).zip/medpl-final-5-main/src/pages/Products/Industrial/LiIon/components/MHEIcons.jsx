import React from 'react';

const base = {
  viewBox: '0 0 24 24',
  fill: 'none',
  stroke: 'currentColor',
  strokeWidth: 1.7,
  strokeLinecap: 'round',
  strokeLinejoin: 'round',
};

export const CloseIcon = (p) => (
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...p}>
    <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

export const ArrowIcon = (p) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" {...p}>
    <path d="M5 12h13" />
    <path d="M13 6l6 6-6 6" />
  </svg>
);

export const ClockIcon = (p) => (
  <svg {...base} {...p}>
    <circle cx="12" cy="12" r="9" />
    <path d="M12 7v5l3.2 2" />
  </svg>
);

export const BoltIcon = (p) => (
  <svg {...base} fill="none" {...p}>
    <path d="M13 2 4 14h6l-1 8 9-12h-6l1-8z" />
  </svg>
);

export const ShieldCheckIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6l7-3z" />
    <path d="M9 12l2 2 4-4" />
  </svg>
);

export const LeafIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M5 19c8 1 13-4 14-14-9 0-14 5-14 14z" />
    <path d="M5 19c2.5-4.5 5.5-7.5 9.5-10" />
  </svg>
);

export const TrendUpIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M4 17l5-5 4 4 7-8" />
    <path d="M15 8h5v5" />
  </svg>
);

export const CheckCircleIcon = (p) => (
  <svg {...base} {...p}>
    <circle cx="12" cy="12" r="9.3" />
    <path d="M8 12.2l2.6 2.6L16.2 9" />
  </svg>
);

export const ForkliftIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M3 4v13h5" />
    <path d="M8 17V9l6 2v6" />
    <circle cx="8.5" cy="19.5" r="1.5" />
    <circle cx="16.5" cy="19.5" r="1.5" />
    <path d="M14 17h5v-5l-3-2" />
  </svg>
);

export const PalletTruckIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M2 18h3l2-7h10l3 4v3h-2" />
    <circle cx="7" cy="19.5" r="1.4" />
    <circle cx="17" cy="19.5" r="1.4" />
    <path d="M7 11V6h3" />
  </svg>
);

export const StackerIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M4 20V6" />
    <path d="M4 8h4M4 12h6M4 16h8" />
    <path d="M14 20V10l4 2v8" />
    <circle cx="16" cy="21.3" r="1.1" />
  </svg>
);

export const TowTractorIcon = (p) => (
  <svg {...base} {...p}>
    <rect x="3" y="10" width="8" height="6" rx="1" />
    <path d="M11 12h4l4 2.5V16h-1" />
    <circle cx="6.5" cy="18" r="1.6" />
    <circle cx="16" cy="18" r="1.6" />
  </svg>
);

export const OrderPickerIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M6 21V4" />
    <path d="M6 6h9M6 11h6M6 16h9" />
    <circle cx="9" cy="21.3" r="1.1" />
  </svg>
);

export const AgvIcon = (p) => (
  <svg {...base} {...p}>
    <rect x="3" y="9" width="18" height="8" rx="1.6" />
    <circle cx="7.5" cy="17" r="1.5" />
    <circle cx="16.5" cy="17" r="1.5" />
    <path d="M7 9V6h4l2 3" />
  </svg>
);

export const CubeIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M12 3l8 4.5v9L12 21l-8-4.5v-9L12 3z" />
    <path d="M4 7.5L12 12l8-4.5M12 12v9" />
  </svg>
);

export const HeadsetIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M4 13a8 8 0 0 1 16 0" />
    <rect x="3" y="13" width="4" height="6" rx="1.4" />
    <rect x="17" y="13" width="4" height="6" rx="1.4" />
    <path d="M20 19v1a3 3 0 0 1-3 3h-4" />
  </svg>
);

export const BatteryIcon = (p) => (
  <svg {...base} {...p}>
    <rect x="2" y="7" width="17" height="10" rx="1.5" />
    <line x1="21" y1="10" x2="21" y2="14" />
  </svg>
);
