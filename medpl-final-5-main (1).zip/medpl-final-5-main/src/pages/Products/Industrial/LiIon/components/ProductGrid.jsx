import { useState } from 'react'
import { products } from '../data/products.js'
import ProductCard from './ProductCard.jsx'
import MHEDetailModal from './MHEDetailModal.jsx'
import BESSDetailModal from './BESSDetailModal.jsx'
import PowerCubeDetailModal from './PowerCubeDetailModal.jsx'
import EVDetailModal from './EVDetailModal.jsx'

export default function ProductGrid() {
  const [isMHEOpen, setMHEOpen] = useState(false)
  const [isBESSOpen, setBESSOpen] = useState(false)
  const [isPowerCubeOpen, setPowerCubeOpen] = useState(false)
  const [isEVOpen, setEVOpen] = useState(false)

  const handleViewDetails = (product) => {
    if (product.id === 'mhe') {
      setMHEOpen(true)
    } else if (product.id === 'bess') {
      setBESSOpen(true)
    } else if (product.id === 'power-cube') {
      setPowerCubeOpen(true)
    } else if (product.id === 'ev') {
      setEVOpen(true)
    }
  }

  return (
    <div className="grid">
      {products.map((product) => (
        <ProductCard key={product.id} product={product} onViewDetails={handleViewDetails} />
      ))}

      <MHEDetailModal isOpen={isMHEOpen} onClose={() => setMHEOpen(false)} />
      <BESSDetailModal isOpen={isBESSOpen} onClose={() => setBESSOpen(false)} />
      <PowerCubeDetailModal isOpen={isPowerCubeOpen} onClose={() => setPowerCubeOpen(false)} />
      <EVDetailModal isOpen={isEVOpen} onClose={() => setEVOpen(false)} />
    </div>
  )
}
