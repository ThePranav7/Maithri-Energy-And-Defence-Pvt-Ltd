import heroBg from '../assets/hero-bg.webp'
import heroBgMobile from '../assets/hero-bg-mobile.webp'

const features = [
  {
    title: 'Superior Safety',
    description: 'Advanced protection and thermal management',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
        <path d="M12 2l8 3v6c0 5-3.5 9-8 11-4.5-2-8-6-8-11V5l8-3z" />
        <path d="M9 12l2 2 4-4" />
      </svg>
    ),
  },
  {
    title: 'Long Cycle Life',
    description: 'Engineered for 3000+ cycles at high reliability',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
        <circle cx="12" cy="12" r="9" />
        <path d="M12 7v5l3 3" />
      </svg>
    ),
  },
  {
    title: 'High Energy Density',
    description: 'More power in compact and lightweight design',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
        <rect x="7" y="3" width="10" height="18" rx="2" />
        <rect x="10" y="1" width="4" height="2" />
        <path d="M12 8v5M9.5 10.5h5" />
      </svg>
    ),
  },
]

export default function Hero() {
  return (
    <section className="hero">
      <img
        className="hero-bg-desktop"
        src={heroBg}
        alt="Maithri Li-ion battery packs and BMS staged with an energy storage system"
      />
      <div className="hero-content">
        <h1>
          Li-ion Battery Solutions
        </h1>
        <p className="hero-desc">
          High-performance lithium-ion cells and battery packs designed for safety,
          reliability and long cycle life in demanding industrial applications.
        </p>

        <div className="hero-features">
          {features.map((f) => (
            <div className="hero-feature" key={f.title}>
              <span className="hero-icon">{f.icon}</span>
              <div>
                <h3>{f.title}</h3>
                <p>{f.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
      <img
        className="hero-bg-mobile"
        src={heroBgMobile}
        alt="Maithri Li-ion battery cells and battery energy storage system containers"
      />
    </section>
  )
}
