import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './EVDetailModal.css';
import {
  CloseIcon,
  ArrowIcon,
  ShieldCheckIcon,
  LeafIcon,
  HeadsetIcon,
} from './MHEIcons.jsx';
import {
  ScooterIcon,
  MotorcycleIcon,
  BikeIcon,
  RickshawIcon,
  ChipIcon,
  ThermoIcon,
  GaugeIcon,
} from './EVIcons.jsx';
import { TruckIcon } from './DetailExtraIcons.jsx';

const topHighlights = [
  { icon: ShieldCheckIcon, title: 'Safe & Reliable', desc: 'Advanced protection for vehicles & riders' },
  { icon: ChipIcon, title: 'Smart BMS', desc: 'Real-time monitoring & intelligent control' },
  { icon: GaugeIcon, title: 'High Performance', desc: 'Longer range & higher efficiency' },
  { icon: ThermoIcon, title: 'Thermal Management', desc: 'Optimized temperature for safety & life' },
  { icon: LeafIcon, title: 'Sustainable', desc: 'Eco-friendly & future-ready' },
];

const whyChoose = [
  { icon: GaugeIcon, name: 'High Energy Density' },
  { icon: ShieldCheckIcon, name: 'Advanced Safety & Reliability' },
  { icon: ThermoIcon, name: 'Thermal Management' },
  { icon: ChipIcon, name: 'Seamless BMS Integration' },
  { icon: ChipIcon, name: 'Customizable Solutions' },
  { icon: LeafIcon, name: 'Longer Life & Performance' },
];

const applications = [
  { icon: ScooterIcon, name: 'E-Scooters' },
  { icon: MotorcycleIcon, name: 'E-Motorcycles' },
  { icon: BikeIcon, name: 'E-Bikes' },
  { icon: RickshawIcon, name: 'L3 Auto Rickshaws' },
  { icon: TruckIcon, name: 'Cargo 3-Wheelers' },
];

const comparisonTable = {
  groups: [
    { label: 'LITHIUM-ION (Li-ion) BATTERY PACKS', variant: 'navy', note: 'High energy density, long cycle life and proven performance for maximum range and efficiency.' },
    { label: 'SODIUM-ION (Na-ion) BATTERY PACKS', variant: 'green', note: 'Cost-effective, safe and sustainable alternative with excellent low-temperature performance.' },
  ],
  columns: ['2-Wheelers', '3-Wheelers (L3)', '2-Wheelers', '3-Wheelers (L3)'],
  rows: [
    { label: 'Chemistry', values: ['LiFePO4 (LFP)', 'LiFePO4 (LFP)', 'NaFePO4 (Sodium Iron Phosphate)', 'NaFePO4 (Sodium Iron Phosphate)'] },
    { label: 'Nominal Voltage', values: ['51.2V – 60V', '60V', '51.2V – 60V', '60V'] },
    { label: 'Configurations', values: ['16S / 17S', '16S', '16S / 17S', '16S'] },
    { label: 'Nominal Capacity', values: ['30Ah', '45Ah', '30Ah', '45Ah'] },
    { label: 'Energy (Nominal)', values: ['1.53 – 1.80 kWh', '2.70 kWh', '1.28 – 1.50 kWh', '2.25 kWh'] },
    { label: 'Cycle Life', values: ['1,500+ Cycles', '1,500+ Cycles', '2,000+ Cycles', '2,000+ Cycles'] },
    { label: 'Energy Density', values: ['120 – 140 Wh/kg', '120 – 140 Wh/kg', '90 – 110 Wh/kg', '90 – 110 Wh/kg'] },
    { label: 'BMS Features', values: ['CAN / RS485 / Bluetooth · SoC · SoH · Protections', 'CAN / RS485 / Bluetooth · SoC · SoH · Protections', 'CAN / RS485 / Bluetooth · SoC · SoH · Protections', 'CAN / RS485 / Bluetooth · SoC · SoH · Protections'] },
    { label: 'Thermal Management', values: ['Integrated (Passive / Active)', 'Integrated (Passive / Active)', 'Integrated (Passive / Active)', 'Integrated (Passive / Active)'] },
    { label: 'Safety', values: ['Multi-layer protection · Short circuit · Over-current · Over-charge · Over-discharge · Temp. protection', 'Multi-layer protection · Short circuit · Over-current · Over-charge · Over-discharge · Temp. protection', 'Multi-layer protection · Short circuit · Over-current · Over-charge · Over-discharge · Temp. protection', 'Multi-layer protection · Short circuit · Over-current · Over-charge · Over-discharge · Temp. protection'] },
    { label: 'Applications', values: ['E-Scooters · E-Motorcycles · E-Bikes', 'L3 E-Auto Rickshaws · Cargo 3-Wheelers', 'E-Scooters · E-Motorcycles · E-Bikes', 'L3 E-Auto Rickshaws · Cargo 3-Wheelers'] },
  ],
};

function TopHighlight({ icon: IconCmp, title, desc }) {
  return (
    <div className="evm-tophi">
      <span className="evm-tophi-icon">
        <IconCmp />
      </span>
      <div className="evm-tophi-text">
        <p className="evm-tophi-title">{title}</p>
        <p className="evm-tophi-desc">{desc}</p>
      </div>
    </div>
  );
}

export default function EVDetailModal({ isOpen, onClose }) {
  const navigate = useNavigate();

  const goToContact = () => {
    onClose();
    navigate('/contact#contact-details');
  };

  useEffect(() => {
    if (!isOpen) return undefined;
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  useEffect(() => {
    if (!isOpen) return undefined;
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = prevOverflow;
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const handleBackdropClick = (e) => {
    if (e.target === e.currentTarget) onClose();
  };

  return (
    <div className="evm-backdrop" onMouseDown={handleBackdropClick}>
      <div className="evm-dialog" role="dialog" aria-modal="true" aria-labelledby="evm-title">
        <button className="evm-close" onClick={onClose} aria-label="Close details">
          <CloseIcon />
        </button>

        <div className="evm-hero">
          <h2 className="evm-title" id="evm-title">
            EV (Electric Vehicle Battery Packs)
          </h2>
          <p className="evm-tagline">Powering the Future of Mobility. Safely. Efficiently.</p>
          <p className="evm-description">
            Purpose-built Li-ion and Sodium-ion battery packs for electric vehicles, designed for
            range, safety, and integration with vehicle BMS.
          </p>
        </div>

        <div className="evm-body">
          <div className="evm-tophi-row">
            {topHighlights.map((h) => (
              <TopHighlight key={h.title} {...h} />
            ))}
          </div>

          <div className="evm-section">
            <span className="evm-section-badge">WHY OUR EV BATTERY PACKS</span>
            <div className="evm-why-grid">
              {whyChoose.map((w) => (
                <div className="evm-why-cell" key={w.name}>
                  <span className="evm-why-icon">
                    <w.icon />
                  </span>
                  <p className="evm-why-name">{w.name}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="evm-section">
            <span className="evm-section-badge">LITHIUM-ION VS SODIUM-ION COMPARISON</span>
            <div className="evm-table-wrap">
              <table className="evm-table">
                <thead>
                  <tr>
                    <th className="evm-table-corner"></th>
                    <th colSpan={2} className="evm-table-group evm-table-group--navy">
                      {comparisonTable.groups[0].label}
                    </th>
                    <th colSpan={2} className="evm-table-group evm-table-group--green">
                      {comparisonTable.groups[1].label}
                    </th>
                  </tr>
                  <tr>
                    <th>Parameter</th>
                    {comparisonTable.columns.map((c, i) => (
                      <th key={i}>{c}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {comparisonTable.rows.map((row) => (
                    <tr key={row.label}>
                      <td className="evm-table-rowhead">{row.label}</td>
                      {row.values.map((v, i) => (
                        <td key={i}>{v}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="evm-table-note">
              60V/45Ah LFP for L3 3-wheelers; 51.2V–60V/30Ah for 2-wheelers. 1,500+ cycle life;
              500+ packs field-proven.
            </p>
          </div>

          <div className="evm-section">
            <span className="evm-section-badge">TYPICAL APPLICATIONS</span>
            <div className="evm-app-grid">
              {applications.map((a) => (
                <div className="evm-app-cell" key={a.name}>
                  <span className="evm-app-icon">
                    <a.icon />
                  </span>
                  <p className="evm-app-name">{a.name}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="evm-stats-row">
            <div className="evm-stat">
              <p className="evm-stat-value">1,500+ / 2,000+</p>
              <p className="evm-stat-label">Cycle Life</p>
            </div>
            <div className="evm-stat">
              <p className="evm-stat-value">500+</p>
              <p className="evm-stat-label">Packs Field-Proven</p>
            </div>
          </div>

          <div className="evm-banner">
            <span className="evm-banner-icon">
              <HeadsetIcon />
            </span>
            <div className="evm-banner-text">
              <p className="evm-banner-title">Need the right EV battery pack for your platform?</p>
              <p className="evm-banner-subtitle">
                Talk to our team about Li-ion or Sodium-ion configurations for your vehicle.
              </p>
            </div>
            <button className="evm-banner-cta" onClick={goToContact}>
              Contact Us
              <ArrowIcon />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
