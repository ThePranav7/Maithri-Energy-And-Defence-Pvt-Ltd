import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './BESSDetailModal.css';
import heroImage from '../assets/detail/bess-hero.webp';
import {
  CloseIcon,
  ArrowIcon,
  ClockIcon,
  ShieldCheckIcon,
  HeadsetIcon,
  CheckCircleIcon,
} from './MHEIcons.jsx';
import {
  TruckIcon,
  PlugPlayIcon,
  WarrantyIcon,
  SolarPanelIcon,
  FactoryBuildingIcon,
  InfraCraneIcon,
  PipelineIcon,
  MiningIcon,
  RoadIcon,
  MiniGridIcon,
  HospitalIcon,
} from './DetailExtraIcons.jsx';

const highlights = [
  { icon: ClockIcon, label: 'Quick Installation' },
  { icon: PlugPlayIcon, label: 'Plug and Play Operation' },
  { icon: TruckIcon, label: 'Easy to Transport, Site to Site' },
  { icon: WarrantyIcon, label: 'Single Warranty Window' },
];

const ratingsTable = {
  columns: ['15 AMP', '12 AMP', '10 AMP', '8 AMP', '6 AMP'],
  rows: [
    { voltage: '48V', values: ['2.4 kWh', '1.9 kWh', '1.6 kWh', '1.3 kWh', '1.0 kWh'] },
    { voltage: '60V', values: ['3.0 kWh', '2.4 kWh', '2.0 kWh', '1.6 kWh', '1.2 kWh'] },
    { voltage: '72V', values: ['3.6 kWh', '2.9 kWh', '2.4 kWh', '1.9 kWh', '1.4 kWh'] },
  ],
};

const keyBenefits = [
  { icon: ClockIcon, name: 'Quick Installation', description: 'Factory tested & pre-commissioned for rapid on-site deployment.' },
  { icon: PlugPlayIcon, name: 'Plug & Play Operation', description: 'Easy integration with solar, grid & DG systems.' },
  { icon: TruckIcon, name: 'Easy Transport', description: 'Built-in lifting points for easy site mobility.' },
];

const standardFeatures = [
  'Advanced BMS with multiple layers of protection',
  'Solar-ready with high-power MPPT & AC coupling support',
  'IP 54 rated enclosure, all-weather ready',
  'Compatible with Na-ion, VRLA, GEL, LMLA and other chemistries',
  'End-to-end support with a single point of contact',
  'Single-day installation procedure',
];

const applications = [
  { icon: SolarPanelIcon, name: 'Renewable EPCs' },
  { icon: FactoryBuildingIcon, name: 'Factories & Commercial Buildings' },
  { icon: InfraCraneIcon, name: 'Infra Developers' },
  { icon: PipelineIcon, name: 'Pipeline Construction' },
  { icon: MiningIcon, name: 'Mining' },
  { icon: RoadIcon, name: 'Road Construction' },
  { icon: MiniGridIcon, name: 'Mini Grid Developers' },
  { icon: HospitalIcon, name: 'Hospitals & PHCs' },
];

function HighlightChip({ icon: IconCmp, label }) {
  return (
    <div className="bessm-highlight">
      <span className="bessm-highlight-icon">
        <IconCmp />
      </span>
      <span className="bessm-highlight-label">{label}</span>
    </div>
  );
}

function BenefitItem({ icon: IconCmp, name, description }) {
  return (
    <li className="bessm-list-item">
      <span className="bessm-list-icon">
        <IconCmp />
      </span>
      <div className="bessm-list-text">
        <p className="bessm-list-name">{name}</p>
        <p className="bessm-list-desc">{description}</p>
      </div>
    </li>
  );
}

function ApplicationCell({ icon: IconCmp, name }) {
  return (
    <div className="bessm-app-cell">
      <span className="bessm-app-icon">
        <IconCmp />
      </span>
      <p className="bessm-app-name">{name}</p>
    </div>
  );
}

export default function BESSDetailModal({ isOpen, onClose }) {
  const navigate = useNavigate();

  const goToContact = () => {
    onClose();
    navigate('/contact#contact-details');
  };

  useEffect(() => {
    if (!isOpen) return undefined;
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  useEffect(() => {
    if (!isOpen) return undefined;
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = prevOverflow;
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const handleBackdropClick = (e) => {
    if (e.target === e.currentTarget) onClose();
  };

  return (
    <div className="bessm-backdrop" onMouseDown={handleBackdropClick}>
      <div className="bessm-dialog" role="dialog" aria-modal="true" aria-labelledby="bessm-title">
        <button className="bessm-close" onClick={onClose} aria-label="Close details">
          <CloseIcon />
        </button>

        <div className="bessm-hero">
          <img src={heroImage} alt="TAPOWER+ containerised solar battery energy storage system" />
        </div>

        <div className="bessm-body">
          <span className="bessm-eyebrow">Containerised Solar BESS Series</span>
          <h2 className="bessm-title" id="bessm-title">
            BESS — Battery Energy Storage System
          </h2>
          <p className="bessm-tagline">The B.E.S.S.(T) Solution for Your Green Power Plant</p>
          <p className="bessm-description">
            A containerized, plug &amp; play battery energy storage solution built for decarbonization
            projects across India. Solar-ready with high-power MPPT up to 250 kW — expandable further
            with AC coupling for a flexible source addition as per site requirements. Batteries are
            tested and selected per application, keeping installation to a single day where a
            conventional electrical-panel civil works would normally take much longer.
          </p>

          <div className="bessm-highlights">
            {highlights.map((h) => (
              <HighlightChip key={h.label} {...h} />
            ))}
          </div>

          <div className="bessm-section">
            <span className="bessm-section-badge">STANDARD RATINGS</span>
            <p className="bessm-table-caption">Capacity (kWh) by DC Voltage &amp; Current</p>
            <div className="bessm-table-wrap">
              <table className="bessm-table">
                <thead>
                  <tr>
                    <th>DC Voltage</th>
                    {ratingsTable.columns.map((c) => (
                      <th key={c}>{c}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {ratingsTable.rows.map((row) => (
                    <tr key={row.voltage}>
                      <td className="bessm-table-rowhead">{row.voltage}</td>
                      {row.values.map((v, i) => (
                        <td key={i}>{v}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="bessm-table-note">
              *Customizable ratings available on request. Widely used to replace DC sets and provide
              primary power in mini grids — supporting backup power, peak shaving, peak shifting, time
              of day charge/discharge, load levelling and grid power import/export control.
            </p>
          </div>

          <div className="bessm-columns">
            <div className="bessm-column">
              <span className="bessm-section-badge">KEY BENEFITS</span>
              <ul className="bessm-list">
                {keyBenefits.map((b) => (
                  <BenefitItem key={b.name} {...b} />
                ))}
              </ul>
            </div>

            <div className="bessm-column">
              <span className="bessm-section-badge">STANDARD FEATURES</span>
              <ul className="bessm-check-list">
                {standardFeatures.map((f) => (
                  <li key={f}>
                    <CheckCircleIcon />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="bessm-applications">
            <span className="bessm-section-badge">APPLICATIONS</span>
            <div className="bessm-app-grid">
              {applications.map((a) => (
                <ApplicationCell key={a.name} {...a} />
              ))}
            </div>
          </div>

          <div className="bessm-banner">
            <span className="bessm-banner-icon">
              <HeadsetIcon />
            </span>
            <div className="bessm-banner-text">
              <p className="bessm-banner-title">Ready to Power Your Fleet?</p>
              <p className="bessm-banner-subtitle">
                Upgrade to high-performance, maintenance-free solutions designed for your operations.
                Get in touch with our team today!
              </p>
            </div>
            <button className="bessm-banner-cta" onClick={goToContact}>
              Contact Us
              <ArrowIcon />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
