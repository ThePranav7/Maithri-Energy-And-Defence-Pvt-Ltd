export default function CtaBanner() {
  return (
    <section className="cta-banner">
      <div className="cta-content">
        <div className="cta-text">
          <h2>Power Your Operations with Reliable Energy</h2>
          <p>Talk to our specialists to find the right Li-ion battery solution for your application.</p>
        </div>
        <a className="cta-btn" href="/contact#contact-details">
          Talk to an Expert
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M5 12h14M13 6l6 6-6 6" />
          </svg>
        </a>
      </div>
    </section>
  )
}
