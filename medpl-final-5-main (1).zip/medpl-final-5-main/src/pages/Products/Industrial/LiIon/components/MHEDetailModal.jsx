import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './MHEDetailModal.css';
import heroImage from '../assets/detail/mhe-hero.webp';
import {
  CloseIcon,
  ArrowIcon,
  ClockIcon,
  BoltIcon,
  ShieldCheckIcon,
  LeafIcon,
  TrendUpIcon,
  CheckCircleIcon,
  ForkliftIcon,
  PalletTruckIcon,
  StackerIcon,
  TowTractorIcon,
  OrderPickerIcon,
  AgvIcon,
  CubeIcon,
  HeadsetIcon,
} from './MHEIcons.jsx';

const highlights = [
  { icon: ClockIcon, label: 'Longer Runtime' },
  { icon: BoltIcon, label: 'Faster Charging' },
  { icon: ShieldCheckIcon, label: 'Enhanced Safety' },
  { icon: LeafIcon, label: 'Zero Maintenance' },
  { icon: TrendUpIcon, label: 'Lower Total Cost of Ownership' },
];

const equipmentTypes = [
  { icon: ForkliftIcon, label: 'Forklifts' },
  { icon: PalletTruckIcon, label: 'Pallet Trucks' },
  { icon: StackerIcon, label: 'Stackers' },
  { icon: TowTractorIcon, label: 'Tow Tractors' },
  { icon: OrderPickerIcon, label: 'Order Pickers' },
  { icon: AgvIcon, label: 'AGVs / AMRs' },
];

const ratingsTable = {
  columns: ['100 Ah', '200 Ah', '300 Ah', '400 Ah'],
  rows: [
    { voltage: '24V', values: ['2.4 kWh', '4.8 kWh', '7.2 kWh', '9.6 kWh'] },
    { voltage: '48V', values: ['4.8 kWh', '9.6 kWh', '14.4 kWh', '19.2 kWh'] },
    { voltage: '88.8V', values: ['8.9 kWh', '17.8 kWh', '26.6 kWh', '35.5 kWh'] },
  ],
};

const chemistryTable = {
  columns: ['LFP (LiFePO4)', 'NMC'],
  rows: [
    { parameter: 'Cycle Life (@80% DOD)', values: ['3,000 – 6,000+ cycles', '1,000 – 2,000 cycles'] },
    { parameter: 'Thermal Stability / Safety', values: ['Excellent — high thermal-runaway threshold', 'Good — requires tighter thermal management'] },
    { parameter: 'Energy Density', values: ['Moderate — larger pack for same energy', 'Higher — more compact & lighter pack'] },
    { parameter: 'Charging', values: ['Fast / opportunity charge capable', 'Fast / opportunity charge capable'] },
    { parameter: 'Best Suited For', values: ['Multi-shift, high-cycle, safety-critical duty', 'Space- or weight-constrained applications'] },
  ],
};

const keyBenefits = [
  { icon: ClockIcon, name: 'Longer Runtime', description: 'Extend operations with high usable capacity and consistent performance.' },
  { icon: BoltIcon, name: 'Faster Charging', description: 'Opportunity charging support keeps your fleet always ready.' },
  { icon: ShieldCheckIcon, name: 'Enhanced Safety', description: 'Advanced BMS with cell balancing, protections and thermal management.' },
  { icon: LeafIcon, name: 'Zero Maintenance', description: 'No watering, no equalizing, no routine maintenance.' },
  { icon: TrendUpIcon, name: 'Lower Total Cost of Ownership', description: 'Reduce operating costs with longer life, higher efficiency and lower maintenance.' },
];

const standardFeatures = [
  'Integrated smart BMS with active cell balancing',
  'CAN / RS485 communication for fleet & charger integration',
  'IP54 / IP65 protected enclosure options',
  'Maintenance-free — no watering or equalizing',
  'Over-charge, over-discharge, short-circuit & thermal protection',
  'Fast / opportunity charging compatible',
];

const applications = [
  { icon: ForkliftIcon, name: 'Counterbalance & reach forklifts' },
  { icon: OrderPickerIcon, name: 'Order pickers' },
  { icon: PalletTruckIcon, name: 'Pallet trucks & stackers' },
  { icon: AgvIcon, name: 'AGVs / AMRs' },
  { icon: TowTractorIcon, name: 'Tow tractors & tuggers' },
  { icon: CubeIcon, name: 'Custom OEM enclosures on request' },
];

function HighlightChip({ icon: IconCmp, label }) {
  return (
    <div className="mhem-highlight">
      <span className="mhem-highlight-icon">
        <IconCmp />
      </span>
      <span className="mhem-highlight-label">{label}</span>
    </div>
  );
}

function EquipmentChip({ icon: IconCmp, label }) {
  return (
    <div className="mhem-equip-cell">
      <span className="mhem-equip-icon">
        <IconCmp />
      </span>
      <span className="mhem-equip-label">{label}</span>
    </div>
  );
}

function BenefitItem({ icon: IconCmp, name, description }) {
  return (
    <li className="mhem-list-item">
      <span className="mhem-list-icon">
        <IconCmp />
      </span>
      <div className="mhem-list-text">
        <p className="mhem-list-name">{name}</p>
        <p className="mhem-list-desc">{description}</p>
      </div>
    </li>
  );
}

function ApplicationCell({ icon: IconCmp, name }) {
  return (
    <div className="mhem-app-cell">
      <span className="mhem-app-icon">
        <IconCmp />
      </span>
      <p className="mhem-app-name">{name}</p>
    </div>
  );
}

export default function MHEDetailModal({ isOpen, onClose }) {
  const navigate = useNavigate();

  const goToContact = () => {
    onClose();
    navigate('/contact#contact-details');
  };

  useEffect(() => {
    if (!isOpen) return undefined;
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  useEffect(() => {
    if (!isOpen) return undefined;
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = prevOverflow;
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const handleBackdropClick = (e) => {
    if (e.target === e.currentTarget) onClose();
  };

  return (
    <div className="mhem-backdrop" onMouseDown={handleBackdropClick}>
      <div className="mhem-dialog" role="dialog" aria-modal="true" aria-labelledby="mhem-title">
        <button className="mhem-close" onClick={onClose} aria-label="Close details">
          <CloseIcon />
        </button>

        <div className="mhem-hero">
          <img src={heroImage} alt="Maithri lithium-ion battery packs for material handling equipment" />
        </div>

        <div className="mhem-body">
          <span className="mhem-eyebrow">Powering the Future of Material Handling</span>
          <h2 className="mhem-title" id="mhem-title">
            Material Handling Solutions
          </h2>
          <p className="mhem-tagline">
            High Performance Lithium Power Systems for Every Material Handling Application
          </p>
          <p className="mhem-description">
            Drop-in lithium-ion replacement packs engineered for forklifts, pallet trucks, stackers,
            tow tractors and order pickers. Available across 24V, 48V and 88.8V system voltages from
            100Ah to 400Ah, in your choice of LFP (LiFePO4) or NMC chemistry — built for multi-shift
            duty, opportunity charging and maintenance-free operation.
          </p>

          <div className="mhem-highlights">
            {highlights.map((h) => (
              <HighlightChip key={h.label} {...h} />
            ))}
          </div>

          <div className="mhem-equip-grid">
            {equipmentTypes.map((eq) => (
              <EquipmentChip key={eq.label} {...eq} />
            ))}
          </div>

          <div className="mhem-section">
            <span className="mhem-section-badge">KEY SPECIFICATIONS</span>

            <p className="mhem-table-caption">Available Ratings — Nominal Voltage × Capacity (Energy in kWh)</p>
            <div className="mhem-table-wrap">
              <table className="mhem-table">
                <thead>
                  <tr>
                    <th>Voltage Class</th>
                    {ratingsTable.columns.map((c) => (
                      <th key={c}>{c}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {ratingsTable.rows.map((row) => (
                    <tr key={row.voltage}>
                      <td className="mhem-table-rowhead">{row.voltage}</td>
                      {row.values.map((v, i) => (
                        <td key={i}>{v}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <p className="mhem-table-caption">Chemistry Options — LFP vs NMC</p>
            <div className="mhem-table-wrap">
              <table className="mhem-table mhem-table--chem">
                <thead>
                  <tr>
                    <th>Parameter</th>
                    {chemistryTable.columns.map((c) => (
                      <th key={c}>{c}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {chemistryTable.rows.map((row) => (
                    <tr key={row.parameter}>
                      <td className="mhem-table-rowhead">{row.parameter}</td>
                      {row.values.map((v, i) => (
                        <td key={i}>{v}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="mhem-table-note">
              All ratings above are offered in both LFP and NMC chemistry. Custom voltage, capacity and
              enclosure dimensions are available on request for drop-in lead-acid replacement.
            </p>
          </div>

          <div className="mhem-columns">
            <div className="mhem-column">
              <span className="mhem-section-badge">KEY BENEFITS</span>
              <ul className="mhem-list">
                {keyBenefits.map((b) => (
                  <BenefitItem key={b.name} {...b} />
                ))}
              </ul>
            </div>

            <div className="mhem-column">
              <span className="mhem-section-badge">STANDARD FEATURES</span>
              <ul className="mhem-check-list">
                {standardFeatures.map((f) => (
                  <li key={f}>
                    <CheckCircleIcon />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="mhem-applications">
            <span className="mhem-section-badge">APPLICATIONS</span>
            <div className="mhem-app-grid">
              {applications.map((a) => (
                <ApplicationCell key={a.name} {...a} />
              ))}
            </div>
          </div>

          <div className="mhem-banner">
            <span className="mhem-banner-icon">
              <HeadsetIcon />
            </span>
            <div className="mhem-banner-text">
              <p className="mhem-banner-title">Ready to Power Your Fleet with Lithium?</p>
              <p className="mhem-banner-subtitle">
                Upgrade to high-performance, maintenance-free lithium solutions designed for your
                operations. Get in touch with our team today!
              </p>
            </div>
            <button className="mhem-banner-cta" onClick={goToContact}>
              Contact Us
              <ArrowIcon />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
