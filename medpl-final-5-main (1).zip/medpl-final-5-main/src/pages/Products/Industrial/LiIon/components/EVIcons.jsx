import React from 'react';

const base = {
  viewBox: '0 0 24 24',
  fill: 'none',
  stroke: 'currentColor',
  strokeWidth: 1.7,
  strokeLinecap: 'round',
  strokeLinejoin: 'round',
};

export const ScooterIcon = (p) => (
  <svg {...base} {...p}>
    <circle cx="5.5" cy="18" r="2.2" />
    <circle cx="18" cy="18" r="2.2" />
    <path d="M7.5 18h6l2-6h3" />
    <path d="M13.5 12l-2-5h-3" />
    <path d="M15 6h2" />
  </svg>
);

export const MotorcycleIcon = (p) => (
  <svg {...base} {...p}>
    <circle cx="5" cy="17" r="2.4" />
    <circle cx="18" cy="17" r="2.4" />
    <path d="M7.2 17h5.3l2-5h3.5" />
    <path d="M12.5 12L10 8H6" />
    <path d="M14.5 8h2" />
  </svg>
);

export const BikeIcon = (p) => (
  <svg {...base} {...p}>
    <circle cx="5.5" cy="17.5" r="3" />
    <circle cx="18.5" cy="17.5" r="3" />
    <path d="M5.5 17.5L10 8h4l4.5 9.5" />
    <path d="M10 8h4" />
    <path d="M12 17.5h6.5" />
  </svg>
);

export const RickshawIcon = (p) => (
  <svg {...base} {...p}>
    <circle cx="7" cy="18" r="2" />
    <circle cx="17" cy="18" r="2" />
    <path d="M4 18V9a2 2 0 0 1 2-2h5l4 5v6" />
    <path d="M9 18h6" />
    <path d="M15 12h4l1 4h-1.5" />
  </svg>
);

export const ChipIcon = (p) => (
  <svg {...base} {...p}>
    <rect x="7" y="7" width="10" height="10" rx="1.4" />
    <path d="M9 3v3M15 3v3M9 18v3M15 18v3M3 9h3M3 15h3M18 9h3M18 15h3" />
  </svg>
);

export const ThermoIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M12 3a2 2 0 0 0-2 2v9.1a4 4 0 1 0 4 0V5a2 2 0 0 0-2-2z" />
    <path d="M12 12v4" />
  </svg>
);

export const GaugeIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M4 15a8 8 0 1 1 16 0" />
    <path d="M12 15l3.5-4.5" />
    <circle cx="12" cy="15" r="1" />
  </svg>
);
