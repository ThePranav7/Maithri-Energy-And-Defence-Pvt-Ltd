import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './PowerCubeDetailModal.css';
import heroImage from '../assets/detail/power-cube-hero.webp';
import {
  CloseIcon,
  ArrowIcon,
  ShieldCheckIcon,
  LeafIcon,
  HeadsetIcon,
} from './MHEIcons.jsx';
import {
  PortableIcon,
  MultiDeviceIcon,
  RecycleCycleIcon,
  LightbulbIcon,
  LaptopIcon,
  MobilePhoneIcon,
  FanIcon,
  ProjectorIcon,
  WarrantyIcon,
} from './DetailExtraIcons.jsx';

const highlights = [
  { icon: PortableIcon, label: '0 to 100% Recharge in 2 Hours' },
  { icon: MultiDeviceIcon, label: 'Powers Up to 5 Devices' },
  { icon: LeafIcon, label: 'Light & Portable' },
  { icon: ShieldCheckIcon, label: 'Power Any Situation' },
];

const runtimeApps = [
  { icon: LightbulbIcon, name: 'Light (10W)', hours: '75 hrs' },
  { icon: LaptopIcon, name: 'Laptop (60Wh)', hours: '12 hrs' },
  { icon: MobilePhoneIcon, name: 'Mobile (32.6Wh)', hours: '24 hrs' },
  { icon: FanIcon, name: 'Fan (50W)', hours: '12 hrs' },
  { icon: ProjectorIcon, name: 'Projector (250W)', hours: '3 hrs' },
];

const specTable = {
  columns: ['Cube 1', 'Cube 2', 'Cube 3', 'Cube 4', 'Cube 5', 'Cube 6', 'Cube 7'],
  rows: [
    { label: 'Capacity (Whr)', values: ['256', '512', '768', '1024', '1536', '2048', '3600'] },
    { label: 'Output Power (W)', values: ['300', '500', '800', '1800', '2400', '2400', '3600'] },
    { label: 'Surge Power (W)', values: ['600', '1000', '1600', '2700', '3200', '4800', '7200'] },
    { label: 'Charging Time (mins)', values: ['60', '60', '70', '80', '90', '80', '108'] },
    { label: 'Weight (Kg)', values: ['3.5', '6', '7.8', '12', '16.5', '23', '45'] },
    { label: 'AC Outlets', values: ['2', '2', '3', '3', '4', '4', '6'] },
  ],
};

const standardFeatures = [
  'LFP battery chemistry — 3,000+ cycle life, 10-year lifespan',
  'Solar, USB and car charging supported on every model',
  'BLE / WiFi app monitoring and control',
  'USB-C and USB-A output ports on every model',
  'Rugged sheet-metal enclosure with plastic moulding',
  '5-year warranty across the full range',
];

function HighlightChip({ icon: IconCmp, label }) {
  return (
    <div className="cubem-highlight">
      <span className="cubem-highlight-icon">
        <IconCmp />
      </span>
      <span className="cubem-highlight-label">{label}</span>
    </div>
  );
}

function RuntimeCell({ icon: IconCmp, name, hours }) {
  return (
    <div className="cubem-equip-cell">
      <span className="cubem-equip-icon">
        <IconCmp />
      </span>
      <span className="cubem-equip-label">
        {name}
        <br />
        {hours}
      </span>
    </div>
  );
}

export default function PowerCubeDetailModal({ isOpen, onClose }) {
  const navigate = useNavigate();

  const goToContact = () => {
    onClose();
    navigate('/contact#contact-details');
  };

  useEffect(() => {
    if (!isOpen) return undefined;
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  useEffect(() => {
    if (!isOpen) return undefined;
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = prevOverflow;
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const handleBackdropClick = (e) => {
    if (e.target === e.currentTarget) onClose();
  };

  return (
    <div className="cubem-backdrop" onMouseDown={handleBackdropClick}>
      <div className="cubem-dialog" role="dialog" aria-modal="true" aria-labelledby="cubem-title">
        <button className="cubem-close" onClick={onClose} aria-label="Close details">
          <CloseIcon />
        </button>

        <div className="cubem-hero">
          <img src={heroImage} alt="Maithri Power Cube portable power station" />
        </div>

        <div className="cubem-body">
          <span className="cubem-eyebrow">India's First Portable Power Generator</span>
          <h2 className="cubem-title" id="cubem-title">
            Power Cube
          </h2>
          <p className="cubem-tagline">Power. Anywhere. Anytime.</p>
          <p className="cubem-description">
            Power Cube is a lightweight, high-performance portable power station designed to keep you
            powered in every situation — from home backup and outdoor trips to travel and emergency use.
            It charges from 0 to 100% in as little as an hour and can run drones, laptops, mobiles, fridges,
            projectors, tools and more, all at once.
          </p>

          <div className="cubem-highlights">
            {highlights.map((h) => (
              <HighlightChip key={h.label} {...h} />
            ))}
          </div>

          <div className="cubem-equip-grid">
            {runtimeApps.map((a) => (
              <RuntimeCell key={a.name} {...a} />
            ))}
          </div>

          <div className="cubem-section">
            <span className="cubem-section-badge">KEY SPECIFICATIONS</span>
            <p className="cubem-table-caption">Cube 1 – Cube 7 Range</p>
            <div className="cubem-table-wrap">
              <table className="cubem-table">
                <thead>
                  <tr>
                    <th>Parameter</th>
                    {specTable.columns.map((c) => (
                      <th key={c}>{c}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {specTable.rows.map((row) => (
                    <tr key={row.label}>
                      <td className="cubem-table-rowhead">{row.label}</td>
                      {row.values.map((v, i) => (
                        <td key={i}>{v}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="cubem-table-note">
              Battery type LFP on every model, 3,000+ cycles and a 10-year lifespan, with solar, USB and
              car charging on all seven capacities from 256Whr up to 3600Whr.
            </p>
          </div>

          <div className="cubem-columns">
            <div className="cubem-column">
              <span className="cubem-section-badge">STANDARD FEATURES</span>
              <ul className="cubem-check-list">
                {standardFeatures.map((f) => (
                  <li key={f}>
                    <ShieldCheckIcon />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="cubem-column">
              <span className="cubem-section-badge">WHY POWER CUBE</span>
              <ul className="cubem-list">
                <li className="cubem-list-item">
                  <span className="cubem-list-icon"><WarrantyIcon /></span>
                  <div className="cubem-list-text">
                    <p className="cubem-list-name">5 Years Warranty</p>
                    <p className="cubem-list-desc">Backed across the full Cube 1 – Cube 7 range.</p>
                  </div>
                </li>
                <li className="cubem-list-item">
                  <span className="cubem-list-icon"><RecycleCycleIcon /></span>
                  <div className="cubem-list-text">
                    <p className="cubem-list-name">3000+ Cycles Life</p>
                    <p className="cubem-list-desc">Long-life LFP cells for years of daily use.</p>
                  </div>
                </li>
                <li className="cubem-list-item">
                  <span className="cubem-list-icon"><LeafIcon /></span>
                  <div className="cubem-list-text">
                    <p className="cubem-list-name">Eco Friendly LFP Battery</p>
                    <p className="cubem-list-desc">Safer chemistry with a smaller environmental footprint.</p>
                  </div>
                </li>
              </ul>
            </div>
          </div>

          <div className="cubem-banner">
            <span className="cubem-banner-icon">
              <HeadsetIcon />
            </span>
            <div className="cubem-banner-text">
              <p className="cubem-banner-title">Experience Uninterrupted Power, Anywhere, Anytime</p>
              <p className="cubem-banner-subtitle">
                Talk to our team about the right Power Cube capacity for your needs.
              </p>
            </div>
            <button className="cubem-banner-cta" onClick={goToContact}>
              Contact Us
              <ArrowIcon />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
