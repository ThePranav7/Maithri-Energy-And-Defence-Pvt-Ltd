export function ScooterIcon(props) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" {...props}>
      <circle cx="5" cy="18" r="2.6" />
      <circle cx="18" cy="18" r="2.6" />
      <path d="M5 18h1.5L9 11h3.5" />
      <path d="M9 11h6.5l1.2 3.2" />
      <path d="M15.8 18h-3.3" />
      <path d="M17 11.2h2.2" />
      <path d="M18.5 11.2l1 2.6" />
      <path d="M9 11l-1-2.5H6.3" />
    </svg>
  )
}

export function ForkliftIcon(props) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" {...props}>
      <path d="M3 20V6l6 4v10" />
      <path d="M9 20h9" />
      <path d="M14 20V9h3l2 3v8" />
      <circle cx="7" cy="20.5" r="1.3" />
      <circle cx="17" cy="20.5" r="1.3" />
    </svg>
  )
}

export function BatteryIcon(props) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" {...props}>
      <rect x="7" y="2" width="10" height="20" rx="2" />
      <rect x="10" y="0.5" width="4" height="2.2" />
      <path d="M13 8l-3 5h3l-3 5" />
    </svg>
  )
}

export function CubeIcon(props) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" {...props}>
      <path d="M12 2l9 5v10l-9 5-9-5V7l9-5z" />
      <path d="M3 7l9 5 9-5M12 12v10" />
    </svg>
  )
}

export function ArrowRightIcon(props) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" {...props}>
      <path d="M5 12h14M13 6l6 6-6 6" />
    </svg>
  )
}

export const ICON_MAP = {
  scooter: ScooterIcon,
  forklift: ForkliftIcon,
  battery: BatteryIcon,
  cube: CubeIcon,
}
