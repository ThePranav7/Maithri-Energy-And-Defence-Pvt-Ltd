const features = [
  {
    title: 'Advanced BMS',
    description: 'Multi-level protection for maximum safety and reliability.',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
        <path d="M12 2l8 3v6c0 5-3.5 9-8 11-4.5-2-8-6-8-11V5l8-3z" />
        <path d="M8.5 12l2.5 2.5 5-5" />
      </svg>
    ),
  },
  {
    title: 'Thermal Management',
    description: 'Intelligent thermal design for optimum performance.',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
        <path d="M12 15.5a2.5 2.5 0 1 1-3-2.45V5.5a1.5 1.5 0 0 1 3 0v7.55a2.5 2.5 0 0 1 0 2.45z" />
        <path d="M11.25 5.5v8" />
        <circle cx="11.25" cy="16" r="0.6" fill="currentColor" stroke="none" />
      </svg>
    ),
  },
  {
    title: 'Custom Solutions',
    description: 'Tailored battery solutions to meet your exact application needs.',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
        <path d="M6 4v6M6 13v7M12 4v3M12 10v10M18 4v11M18 18v2" />
        <circle cx="6" cy="10.5" r="1.7" />
        <circle cx="12" cy="7" r="1.7" />
        <circle cx="18" cy="15" r="1.7" />
      </svg>
    ),
  },
  {
    title: 'Quality Assured',
    description: 'Rigorous testing and international quality standards.',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
        <rect x="5" y="4" width="14" height="17" rx="2" />
        <rect x="9" y="2.3" width="6" height="3" rx="1" />
        <path d="M9 12.5l2 2 4-4.5" />
      </svg>
    ),
  },
]

export default function WhyChoose() {
  return (
    <section className="why-choose">
      <div className="why-intro">
        <h2>Why Choose Our Li-ion Batteries?</h2>
        <p>
          Every battery is engineered with precision, tested rigorously and built to
          deliver consistent performance in the most challenging conditions.
        </p>
      </div>

      <div className="why-features">
        {features.map((f) => (
          <div className="why-feature" key={f.title}>
            <span className="why-icon">{f.icon}</span>
            <h3>{f.title}</h3>
            <p>{f.description}</p>
          </div>
        ))}
      </div>
    </section>
  )
}
