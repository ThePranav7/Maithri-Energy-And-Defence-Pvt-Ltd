import { useEffect } from "react";
import NavGap from "../../../../components/Layout/NavGap.jsx";
import Hero from "./components/Hero.jsx";
import ProductGrid from "./components/ProductGrid.jsx";
import WhyChoose from "./components/WhyChoose.jsx";
import CtaBanner from "./components/CtaBanner.jsx";
import "./LiIonPage.css";

export default function LiIonPage() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="li-ion-page">
      <NavGap />
      <Hero />
      <ProductGrid />
      <WhyChoose />
      <CtaBanner />
    </div>
  );
}
