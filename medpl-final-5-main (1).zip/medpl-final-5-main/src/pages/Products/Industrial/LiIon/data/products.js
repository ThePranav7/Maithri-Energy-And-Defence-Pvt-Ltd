import evImage from '../assets/detail/ev-hero.webp'
import mheImage from '../assets/detail/mhe-hero.webp'
import bessImage from '../assets/detail/bess-hero.webp'
import powerCubeImage from '../assets/detail/power-cube-hero.webp'

export const products = [
  {
    id: 'ev',
    title: 'EV (Electric Vehicle Battery Packs)',
    description:
      'Purpose-built Li-ion battery packs for electric vehicles, designed for range, safety, and integration with vehicle BMS.',
    bullets: [
      'High energy density cells',
      'Integrated thermal management',
      'Custom pack configurations',
      '60V/45Ah LFP for L3 3-wheelers; 51.2V–60V/30Ah for 2-wheelers. 1,500+ cycle life; 500+ packs field-proven.',
    ],
    icon: 'scooter',
    image: evImage,
  },
  {
    id: 'mhe',
    title: 'MHE (Material Handling Equipment)',
    description:
      'Li-ion battery solutions for forklifts and material handling equipment, built for continuous-duty industrial use.',
    bullets: [
      'Fast charging capability',
      'Long cycle life for multi-shift operation',
      'Robust enclosure for industrial environments',
    ],
    icon: 'forklift',
    image: mheImage,
  },
  {
    id: 'bess',
    title: 'BESS (Battery Energy Storage System)',
    description:
      'Scalable Li-ion energy storage systems for grid support, peak shaving, and renewable energy integration.',
    bullets: [
      'Modular, scalable architecture',
      'Integrated safety monitoring',
      'Grid-tied and off-grid configurations',
      '500 kWh – 5 MWh capacity range.',
    ],
    icon: 'battery',
    image: bessImage,
  },
  {
    id: 'power-cube',
    title: 'Power Cube',
    description:
      'Compact, portable Li-ion power unit for flexible industrial and field power needs.',
    bullets: [
      'Portable, rugged design',
      'Multiple output options',
      'Up to 5 kWh capacity.',
    ],
    icon: 'cube',
    image: powerCubeImage,
  },
]
