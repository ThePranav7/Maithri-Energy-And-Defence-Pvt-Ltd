import React from 'react';
import heroImage from '../assets/power-system-hero.webp';
import './PowerSystemProducts.css';

const FEATURES = [
  {
    title: 'Reliable Power',
    description: 'Continuous and stable power for mission-critical loads',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 2l7 4v6c0 5-3.5 8.5-7 10-3.5-1.5-7-5-7-10V6l7-4z" />
      </svg>
    ),
  },
  {
    title: 'High Efficiency',
    description: 'Optimized conversion with reduced losses and lower TCO',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
        <path d="M17.5 12a5.5 5.5 0 1 1-2.3-4.47" />
        <path d="M17.5 3v4.5H13" />
      </svg>
    ),
  },
  {
    title: 'Scalable Solutions',
    description: 'Modular designs to meet diverse power and runtime needs',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="3.4" />
        <path d="M12 3v2.4M12 18.6V21M21 12h-2.4M5.4 12H3M18.1 5.9l-1.7 1.7M7.6 16.4l-1.7 1.7M18.1 18.1l-1.7-1.7M7.6 7.6 5.9 5.9" />
      </svg>
    ),
  },
];

export default function PowerSystemProducts() {
  return (
    <section className="psp-banner">
      <div className="psp-content">
        <h1 className="psp-title">Power System Products</h1>

        <p className="psp-lede">
          Complete energy storage and power conversion solutions that ensure uninterrupted power,
          high efficiency and operational reliability for critical industrial applications.
        </p>

        <ul className="psp-features">
          {FEATURES.map((feature) => (
            <li className="psp-feature" key={feature.title}>
              <span className="psp-feature-icon">{feature.icon}</span>
              <span className="psp-feature-text">
                <strong>{feature.title}</strong>
                <span>{feature.description}</span>
              </span>
            </li>
          ))}
        </ul>
      </div>

      <div className="psp-media">
        <img
          src={heroImage}
          alt="MEDPL power system enclosures and battery modules in a data center"
        />
      </div>
    </section>
  );
}
