import React from 'react';
import { useNavigate } from 'react-router-dom';
import ctaBg from '../assets/cta-power-solution-bg.webp';
import './CustomPowerSolution.css';

const ArrowIcon = () => (
  <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path
      d="M3.5 8h9M8.5 3.8 12.7 8l-4.2 4.2"
      stroke="currentColor"
      strokeWidth="1.6"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

export default function CustomPowerSolution() {
  const navigate = useNavigate();
  return (
    <section className="cps-section">
      <div
        className="cps-banner"
        style={{ '--cps-bg-image': `url(${ctaBg})` }}
      >
        <div className="cps-overlay" />

        <div className="cps-content">
          <div className="cps-text">
            <h2>Need a Customized Power Solution?</h2>
            <p>Our experts will help you design the right solution for your application.</p>
          </div>

          <button
            type="button"
            className="cps-btn"
            onClick={() => navigate('/contact#contact-details')}
          >
            TALK TO OUR EXPERTS <ArrowIcon />
          </button>
        </div>
      </div>
    </section>
  );
}
