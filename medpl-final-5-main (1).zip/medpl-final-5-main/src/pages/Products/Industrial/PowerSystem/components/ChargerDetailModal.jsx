import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './ChargerDetailModal.css';
import heroImage from '../assets/detail/charger-hero.webp';
import {
  CloseIcon,
  ArrowIcon,
  ShieldCheckIcon,
  CheckCircleIcon,
  BoltIcon,
  ChipIcon,
  FanCoolingIcon,
  BatteryCompatIcon,
  ScooterIcon,
  RickshawIcon,
  StationIcon,
  AuxBatteryIcon,
  OnboardChargeIcon,
  ControlPowerIcon,
  HeadsetIcon,
  ShortCircuitIcon,
  OverloadIcon,
  OverVoltageIcon,
  TemperatureIcon,
} from './ChargerExtraIcons.jsx';

const highlights = [
  { icon: ShieldCheckIcon, label: 'Multi Protection' },
  { icon: BoltIcon, label: 'High Efficiency — Up to 90%' },
  { icon: ChipIcon, label: 'Active PFC' },
  { icon: FanCoolingIcon, label: 'Forced Air Cooling' },
  { icon: BatteryCompatIcon, label: 'LFP & NMC Compatible' },
];

const seriesTable = {
  columns: ['6A Series', '8A Series', '10A Series'],
  rows: [
    { label: 'DC Voltage', values: ['48V / 60.8V / 73.6V', '48V / 60.8V / 73.6V', '48V / 60.8V / 73.6V'] },
    { label: 'Rated Current', values: ['6A', '8A', '10A'] },
    { label: 'Rated / Peak Power', values: ['288–441.6W / 360–552W', '384–486.4W / 480–608W', '480–600W / 600–750W'] },
    { label: 'Efficiency (Typ.)', values: ['89%', '90%', '90%'] },
    { label: 'Input Voltage Range', values: ['170–264VAC', '170–264VAC', '170–264VAC'] },
    { label: 'Operating Temperature', values: ['0°C to +70°C', '0°C to +70°C', '0°C to +70°C'] },
  ],
};

const ledTable = {
  columns: ['Indication'],
  rows: [
    { label: 'Power ON', values: ['1st LED glows'] },
    { label: 'Charging up to 75%', values: ['LEDs glow progressively, 2nd–4th'] },
    { label: 'Fully Charged', values: ['All LEDs glow'] },
    { label: 'No Battery Connected', values: ['1st & 2nd LED blink together'] },
    { label: 'Reverse / Short Circuit', values: ['4th & 5th LED blink together'] },
  ],
};

const protections = [
  { icon: ShortCircuitIcon, name: 'Short Circuit Protection' },
  { icon: OverloadIcon, name: 'Overload Protection' },
  { icon: OverVoltageIcon, name: 'Over Voltage Protection' },
  { icon: TemperatureIcon, name: 'Over Temperature Protection' },
];

const applications = [
  { icon: ScooterIcon, name: 'Electric Two & Three Wheelers' },
  { icon: RickshawIcon, name: 'E-Rickshaws & LSVs' },
  { icon: StationIcon, name: 'Portable Charging Stations' },
  { icon: AuxBatteryIcon, name: 'Auxiliary & Backup Battery Systems' },
  { icon: OnboardChargeIcon, name: 'Onboard Charging Subsystems' },
  { icon: ControlPowerIcon, name: 'Control Electronics Power Supply' },
];

function HighlightChip({ icon: IconCmp, label }) {
  return (
    <div className="chargerm-highlight">
      <span className="chargerm-highlight-icon">
        <IconCmp />
      </span>
      <span className="chargerm-highlight-label">{label}</span>
    </div>
  );
}

function ApplicationCell({ icon: IconCmp, name }) {
  return (
    <div className="chargerm-app-cell">
      <span className="chargerm-app-icon">
        <IconCmp />
      </span>
      <p className="chargerm-app-name">{name}</p>
    </div>
  );
}

export default function ChargerDetailModal({ isOpen, onClose }) {
  const navigate = useNavigate();

  const goToContact = () => {
    onClose();
    navigate('/contact#contact-details');
  };

  useEffect(() => {
    if (!isOpen) return undefined;
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  useEffect(() => {
    if (!isOpen) return undefined;
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = prevOverflow;
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const handleBackdropClick = (e) => {
    if (e.target === e.currentTarget) onClose();
  };

  return (
    <div className="chargerm-backdrop" onMouseDown={handleBackdropClick}>
      <div className="chargerm-dialog" role="dialog" aria-modal="true" aria-labelledby="chargerm-title">
        <button className="chargerm-close" onClick={onClose} aria-label="Close details">
          <CloseIcon />
        </button>

        <div className="chargerm-hero">
          <img src={heroImage} alt="Maithri EV battery charger compatible with LFP and NMC batteries" />
        </div>

        <div className="chargerm-body">
          <span className="chargerm-eyebrow">Compatible with Both LFP &amp; NMC Batteries</span>
          <h2 className="chargerm-title" id="chargerm-title">
            EV Battery Charger
          </h2>
          <p className="chargerm-tagline">Safe • Reliable • Efficient</p>
          <p className="chargerm-description">
            Advanced, high-efficiency AC-DC chargers designed to deliver reliable and safe charging for
            EV batteries. Compatible with both LFP (Lithium Iron Phosphate) and NMC (Nickel Manganese
            Cobalt) chemistries, these chargers are ideal for low-power EVs, portable charging stations,
            auxiliary battery systems, and onboard charging applications — with voltages tunable at the
            factory to match your battery's requirement.
          </p>

          <div className="chargerm-highlights">
            {highlights.map((h) => (
              <HighlightChip key={h.label} {...h} />
            ))}
          </div>

          <div className="chargerm-section">
            <span className="chargerm-section-badge">KEY SPECIFICATIONS</span>

            <p className="chargerm-table-caption">6A / 8A / 10A Series — Key Parameters</p>
            <div className="chargerm-table-wrap">
              <table className="chargerm-table">
                <thead>
                  <tr>
                    <th>Parameter</th>
                    {seriesTable.columns.map((c) => (
                      <th key={c}>{c}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {seriesTable.rows.map((row) => (
                    <tr key={row.label}>
                      <td className="chargerm-table-rowhead">{row.label}</td>
                      {row.values.map((v, i) => (
                        <td key={i}>{v}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <p className="chargerm-table-caption">LED Charge-Status Indications</p>
            <div className="chargerm-table-wrap">
              <table className="chargerm-table chargerm-table--chem">
                <thead>
                  <tr>
                    <th>Status</th>
                    <th>LED Indication</th>
                  </tr>
                </thead>
                <tbody>
                  {ledTable.rows.map((row) => (
                    <tr key={row.label}>
                      <td className="chargerm-table-rowhead">{row.label}</td>
                      {row.values.map((v, i) => (
                        <td key={i}>{v}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="chargerm-table-note">
              Multi-protection design guards against short circuit, overload, over voltage and over
              temperature, recovering automatically once the fault condition clears. Forced-air cooled
              for reliable performance from 0°C to +70°C.
            </p>
          </div>

          <div className="chargerm-columns">
            <div className="chargerm-column">
              <span className="chargerm-section-badge">PROTECTIONS</span>
              <ul className="chargerm-check-list">
                {protections.map((p) => (
                  <li key={p.name}>
                    <CheckCircleIcon />
                    <span>{p.name}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="chargerm-column">
              <span className="chargerm-section-badge">STANDARD FEATURES</span>
              <ul className="chargerm-check-list">
                {[
                  'Smart charging profile tuned per battery chemistry',
                  'Cold start capable, inrush current > 40A @ 230VAC',
                  'Voltage tolerance ±2%, line/load regulation ±2%',
                  'Leakage current < 4mA @ 240VAC for user safety',
                ].map((f) => (
                  <li key={f}>
                    <CheckCircleIcon />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="chargerm-applications">
            <span className="chargerm-section-badge">APPLICATIONS</span>
            <div className="chargerm-app-grid">
              {applications.map((a) => (
                <ApplicationCell key={a.name} {...a} />
              ))}
            </div>
          </div>

          <div className="chargerm-banner">
            <span className="chargerm-banner-icon">
              <HeadsetIcon />
            </span>
            <div className="chargerm-banner-text">
              <p className="chargerm-banner-title">Ready to Power Your Fleet?</p>
              <p className="chargerm-banner-subtitle">
                Upgrade to high-performance, maintenance-free solutions designed for your operations.
                Get in touch with our team today!
              </p>
            </div>
            <button className="chargerm-banner-cta" onClick={goToContact}>
              Contact Us
              <ArrowIcon />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
