import React from 'react';
import './CriticalPerformance.css';

const DownloadIcon = () => (
  <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M8 1.5v8.4M8 9.9l3-3M8 9.9l-3-3" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
    <path d="M2 11.5v1.6c0 .8.6 1.4 1.4 1.4h9.2c.8 0 1.4-.6 1.4-1.4v-1.6" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const ShieldIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M12 3l7 3v5.5c0 4.7-3 8-7 9.5-4-1.5-7-4.8-7-9.5V6l7-3z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
    <path d="M9 12.2l2 2 4-4.4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const GaugeIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="12" cy="12" r="8.5" stroke="currentColor" strokeWidth="1.5" />
    <path d="M12 12L16 8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    <circle cx="12" cy="12" r="1.3" fill="currentColor" />
    <path d="M8.5 6.5l.7.7M15.5 6.5l-.7.7M5.5 12h1M17.5 12h1" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
  </svg>
);

const GearIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="12" cy="12" r="3.4" stroke="currentColor" strokeWidth="1.5" />
    <path d="M12 3v2.4M12 18.6V21M21 12h-2.4M5.4 12H3M18.1 5.9l-1.7 1.7M7.6 16.4l-1.7 1.7M18.1 18.1l-1.7-1.7M7.6 7.6 5.9 5.9" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
  </svg>
);

const MonitorIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="3" y="4.5" width="18" height="12" rx="1.4" stroke="currentColor" strokeWidth="1.5" />
    <path d="M8.5 21h7M12 16.5V21" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    <path d="M6.5 13.5l3-3.4 2.4 2 3.6-4.6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const FEATURES = [
  {
    icon: <ShieldIcon />,
    title: 'Advanced Protection',
    description: 'Comprehensive electrical and thermal protection for safe operation.',
  },
  {
    icon: <GaugeIcon />,
    title: 'High Availability',
    description: 'Designed for 24/7 reliability with minimal downtime.',
  },
  {
    icon: <GearIcon />,
    title: 'Easy Integration',
    description: 'Seamless integration with battery systems and critical loads.',
  },
  {
    icon: <MonitorIcon />,
    title: 'Smart Monitoring',
    description: 'Real-time monitoring, analytics and remote management.',
  },
];

export default function CriticalPerformance() {
  return (
    <section className="cp-section">
      <div className="cp-banner">
        <div className="cp-left">
          <h2>Built for Critical Performance</h2>
          <p>Every product is designed, tested and validated to perform in the most demanding conditions.</p>
        </div>

        <div className="cp-features">
          {FEATURES.map((feature) => (
            <div className="cp-feature" key={feature.title}>
              <span className="cp-feature-icon">{feature.icon}</span>
              <h3>{feature.title}</h3>
              <p>{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
