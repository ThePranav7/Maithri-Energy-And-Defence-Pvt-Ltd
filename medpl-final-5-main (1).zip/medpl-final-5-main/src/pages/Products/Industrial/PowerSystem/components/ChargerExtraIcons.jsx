import React from 'react';

const base = {
  viewBox: '0 0 24 24',
  fill: 'none',
  stroke: 'currentColor',
  strokeWidth: 1.7,
  strokeLinecap: 'round',
  strokeLinejoin: 'round',
};

export const CloseIcon = (p) => (
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...p}>
    <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

export const ArrowIcon = (p) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" {...p}>
    <path d="M5 12h13" />
    <path d="M13 6l6 6-6 6" />
  </svg>
);

export const ShieldCheckIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6l7-3z" />
    <path d="M9 12l2 2 4-4" />
  </svg>
);

export const CheckCircleIcon = (p) => (
  <svg {...base} {...p}>
    <circle cx="12" cy="12" r="9.3" />
    <path d="M8 12.2l2.6 2.6L16.2 9" />
  </svg>
);

export const BoltIcon = (p) => (
  <svg {...base} fill="none" {...p}>
    <path d="M13 2 4 14h6l-1 8 9-12h-6l1-8z" />
  </svg>
);

export const ChipIcon = (p) => (
  <svg {...base} {...p}>
    <rect x="7" y="7" width="10" height="10" rx="1.4" />
    <rect x="10" y="10" width="4" height="4" />
    <path d="M9 3v3M15 3v3M9 18v3M15 18v3M3 9h3M3 15h3M18 9h3M18 15h3" />
  </svg>
);

export const FanCoolingIcon = (p) => (
  <svg {...base} {...p}>
    <circle cx="12" cy="12" r="1.6" />
    <path d="M12 10.4C11 7 9 5 6.5 5.3c-1 3 .3 5.4 3.1 6.6M13.6 12c3.4-1 5.4-3 5.1-5.5-3-1-5.4.3-6.6 3.1M12 13.6c1 3.4 3 5.4 5.5 5.1 1-3-.3-5.4-3.1-6.6M10.4 12c-3.4 1-5.4 3-5.1 5.5 3 1 5.4-.3 6.6-3.1" />
  </svg>
);

export const BatteryCompatIcon = (p) => (
  <svg {...base} {...p}>
    <rect x="2" y="7" width="17" height="10" rx="1.5" />
    <line x1="21" y1="10" x2="21" y2="14" />
    <path d="M9.5 9.5L7 13h3l-1.5 2.5" />
  </svg>
);

export const ScooterIcon = (p) => (
  <svg {...base} {...p}>
    <circle cx="5" cy="18" r="2.6" />
    <circle cx="18" cy="18" r="2.6" />
    <path d="M5 18h1.5L9 11h3.5" />
    <path d="M9 11h6.5l1.2 3.2" />
    <path d="M15.8 18h-3.3" />
  </svg>
);

export const RickshawIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M3 20V9l5-3h5l3 5h2l2 3v6" />
    <circle cx="7" cy="20.3" r="1.4" />
    <circle cx="17" cy="20.3" r="1.4" />
    <path d="M7 9h6" />
  </svg>
);

export const StationIcon = (p) => (
  <svg {...base} {...p}>
    <rect x="6" y="3" width="9" height="15" rx="1.4" />
    <path d="M15 8h2l2 3v7h-2" />
    <circle cx="10" cy="20.3" r="1" />
    <path d="M9 6h3M9 10h3" />
  </svg>
);

export const AuxBatteryIcon = (p) => (
  <svg {...base} {...p}>
    <rect x="3" y="7" width="14" height="10" rx="1.5" />
    <line x1="19" y1="10" x2="19" y2="14" />
    <path d="M8 9.5L6 13h2l-1 2.5" />
    <path d="M11.5 9.5L13.5 13h-2l1 2.5" />
  </svg>
);

export const OnboardChargeIcon = (p) => (
  <svg {...base} {...p}>
    <rect x="3" y="10" width="14" height="8" rx="1.6" />
    <circle cx="7" cy="18.5" r="1.2" />
    <circle cx="13" cy="18.5" r="1.2" />
    <path d="M6 10V7a3 3 0 0 1 3-3h2l3 4" />
  </svg>
);

export const ControlPowerIcon = (p) => (
  <svg {...base} {...p}>
    <rect x="4" y="3" width="16" height="18" rx="1.6" />
    <path d="M8 8h3M8 12h8M8 16h5" />
    <circle cx="17" cy="8" r="1.1" />
  </svg>
);

export const HeadsetIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M4 13a8 8 0 0 1 16 0" />
    <rect x="3" y="13" width="4" height="6" rx="1.4" />
    <rect x="17" y="13" width="4" height="6" rx="1.4" />
    <path d="M20 19v1a3 3 0 0 1-3 3h-4" />
  </svg>
);

export const ShortCircuitIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6l7-3z" />
    <path d="M13 8l-4 5h3l-1 4 4-5h-3l1-4z" />
  </svg>
);

export const OverloadIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M4 19h16" />
    <path d="M7 19V9M12 19V5M17 19v-7" />
    <path d="M2 21h20" />
  </svg>
);

export const OverVoltageIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M13 2 4 14h6l-1 8 9-12h-6l1-8z" />
    <circle cx="19" cy="5" r="2.2" />
  </svg>
);

export const TemperatureIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M12 14.5V4.5a2 2 0 0 0-4 0v10a4 4 0 1 0 4 0z" />
  </svg>
);
