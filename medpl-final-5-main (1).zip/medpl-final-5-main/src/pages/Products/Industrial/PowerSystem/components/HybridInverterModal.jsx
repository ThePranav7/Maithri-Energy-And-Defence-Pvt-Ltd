import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './HybridInverterModal.css';
import heroImage from '../assets/detail/hybrid-inverter-hero.webp';
import {
  CloseIcon,
  ArrowIcon,
  SolarIcon,
  BatteryIcon,
  SineWaveIcon,
  ShieldPlusIcon,
  BarChartIcon,
  GearIcon,
  DataAnalyticsIcon,
  BellIcon,
  ShieldCheckIcon,
  NetworkIcon,
  HomeIcon,
  ShopIcon,
  SchoolIcon,
  OfficeIcon,
  ClinicIcon,
  TowerIcon,
  BatteryIcon as EnergyStorageIcon,
  PlugIcon,
  FactoryIcon,
  TruckIcon,
  ShieldHomeIcon,
  HeadsetIcon,
} from './HybridInverterIcons.jsx';

const highlights = [
  { icon: SolarIcon, label: 'Solar Charging' },
  { icon: BatteryIcon, label: 'Battery Backup' },
  { icon: SineWaveIcon, label: 'Pure Sine Wave' },
  { icon: ShieldPlusIcon, label: 'Complete Protection' },
];

const capabilities = [
  {
    icon: BarChartIcon,
    name: 'Real-time Monitoring',
    description: 'Monitor systems and assets in real time with accurate and reliable data.',
  },
  {
    icon: GearIcon,
    name: 'Remote Control',
    description: 'Remotely control and manage your systems from anywhere.',
  },
  {
    icon: DataAnalyticsIcon,
    name: 'Data Analytics',
    description: 'Data-driven insights and advanced analytics to optimize performance.',
  },
  {
    icon: BellIcon,
    name: 'Alerts & Notifications',
    description: 'Instant alerts and notifications to keep you informed at all times.',
  },
  {
    icon: ShieldCheckIcon,
    name: 'Security & Reliability',
    description: 'Enterprise-grade security and reliable connectivity you can trust.',
  },
  {
    icon: NetworkIcon,
    name: 'Seamless Integration',
    description: 'Easily integrate with your existing systems and third-party platforms.',
  },
];

const applications = [
  {
    icon: HomeIcon,
    name: 'Homes',
    description: 'Reliable power backup and solar integration for uninterrupted comfort.',
  },
  {
    icon: ShopIcon,
    name: 'Shops & Retail Outlets',
    description: 'Keep your business running with efficient and stable power.',
  },
  {
    icon: SchoolIcon,
    name: 'Schools & Educational Institutions',
    description: 'Ensure continuous power for classrooms, labs and administration.',
  },
  {
    icon: OfficeIcon,
    name: 'Offices & Workspaces',
    description: 'Protect critical equipment and maintain productivity without downtime.',
  },
  {
    icon: ClinicIcon,
    name: 'Clinics & Healthcare Centers',
    description: 'Support essential medical equipment with clean and reliable power.',
  },
  {
    icon: TowerIcon,
    name: 'Remote Sites & Installations',
    description: 'Ideal for locations where reliable power and monitoring are critical.',
  },
];

const industryApplications = [
  {
    icon: EnergyStorageIcon,
    name: 'Energy Storage',
    description: 'Monitor and optimize battery systems for maximum performance.',
  },
  {
    icon: PlugIcon,
    name: 'Power Systems',
    description: 'Real-time monitoring and control of power infrastructure.',
  },
  {
    icon: FactoryIcon,
    name: 'Industrial Automation',
    description: 'Improve operational efficiency with smart IoT applications.',
  },
  {
    icon: SolarIcon,
    name: 'Renewable Energy',
    description: 'Monitor solar, wind and hybrid systems in real time.',
  },
  {
    icon: TruckIcon,
    name: 'Fleet Management',
    description: 'Track, monitor and optimize fleet performance.',
  },
  {
    icon: ShieldHomeIcon,
    name: 'Critical Infrastructure',
    description: 'Ensure reliability and security for critical operations.',
  },
];

function ListItem({ icon: IconCmp, name, description }) {
  return (
    <li className="hinvm-list-item">
      <span className="hinvm-list-icon">
        <IconCmp />
      </span>
      <div className="hinvm-list-text">
        <p className="hinvm-list-name">{name}</p>
        <p className="hinvm-list-desc">{description}</p>
      </div>
    </li>
  );
}

function ApplicationCell({ icon: IconCmp, name, description }) {
  return (
    <div className="hinvm-app-cell">
      <span className="hinvm-app-icon">
        <IconCmp />
      </span>
      <p className="hinvm-app-name">{name}</p>
      <p className="hinvm-app-desc">{description}</p>
    </div>
  );
}

export default function HybridInverterModal({ isOpen, onClose }) {
  const navigate = useNavigate();

  const goToContact = () => {
    onClose();
    navigate('/contact#contact-details');
  };

  useEffect(() => {
    if (!isOpen) return undefined;
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  useEffect(() => {
    if (!isOpen) return undefined;
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = prevOverflow;
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const handleBackdropClick = (e) => {
    if (e.target === e.currentTarget) onClose();
  };

  return (
    <div className="hinvm-backdrop" onMouseDown={handleBackdropClick}>
      <div className="hinvm-dialog" role="dialog" aria-modal="true" aria-labelledby="hinvm-title">
        <button className="hinvm-close" onClick={onClose} aria-label="Close details">
          <CloseIcon />
        </button>

        <div className="hinvm-hero">
          <img src={heroImage} alt="Maithri hybrid inverter range with home solar installation" />
        </div>

        <div className="hinvm-body">
          <h2 className="hinvm-title" id="hinvm-title">
            Hybrid Inverter Solutions
          </h2>
          <p className="hinvm-tagline">1 KVA – 5 KVA</p>
          <p className="hinvm-description">
            Hybrid grid &amp; solar-charging inverters for home backup, plus a lithium solar model
            with app monitoring — built around the same MPPT charging core and pure sine wave output.
          </p>

          <div className="hinvm-highlights">
            {highlights.map((h) => (
              <div className="hinvm-highlight" key={h.label}>
                <span className="hinvm-highlight-icon">
                  <h.icon />
                </span>
                <span className="hinvm-highlight-label">{h.label}</span>
              </div>
            ))}
          </div>

          <div className="hinvm-columns">
            <div className="hinvm-column">
              <span className="hinvm-section-badge">OUR CAPABILITIES</span>
              <ul className="hinvm-list">
                {capabilities.map((c) => (
                  <ListItem key={c.name} {...c} />
                ))}
              </ul>
            </div>

            <div className="hinvm-column">
              <span className="hinvm-section-badge">APPLICATIONS</span>
              <ul className="hinvm-list">
                {applications.map((a) => (
                  <ListItem key={a.name} {...a} />
                ))}
              </ul>
            </div>
          </div>

          <div className="hinvm-applications">
            <span className="hinvm-section-badge">INDUSTRY APPLICATIONS</span>
            <div className="hinvm-app-grid">
              {industryApplications.map((a) => (
                <ApplicationCell key={a.name} {...a} />
              ))}
            </div>
          </div>

          <div className="hinvm-banner">
            <span className="hinvm-banner-icon">
              <HeadsetIcon />
            </span>
            <div className="hinvm-banner-text">
              <p className="hinvm-banner-title">Monitor your inverter any time, anywhere with WiFi connectivity.</p>
              <p className="hinvm-banner-subtitle">
                Stay connected, gain real-time insights and drive your business forward.
              </p>
            </div>
            <button className="hinvm-banner-cta" onClick={goToContact}>
              Contact Us
              <ArrowIcon />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
