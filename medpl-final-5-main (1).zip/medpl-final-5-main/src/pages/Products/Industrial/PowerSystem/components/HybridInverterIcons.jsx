import React from 'react';

const base = {
  viewBox: '0 0 24 24',
  fill: 'none',
  stroke: 'currentColor',
  strokeWidth: 1.7,
  strokeLinecap: 'round',
  strokeLinejoin: 'round',
};

export const CloseIcon = (p) => (
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...p}>
    <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

export const ArrowIcon = (p) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" {...p}>
    <path d="M5 12h13" />
    <path d="M13 6l6 6-6 6" />
  </svg>
);

export const SolarIcon = (p) => (
  <svg {...base} {...p}>
    <circle cx="12" cy="7" r="2.5" />
    <path d="M12 1.5v1.3M12 12.2v1.3M6.3 7h1.3M16.4 7h1.3M8.2 3.2l.9.9M14.9 3.2l-.9.9" />
    <path d="M4 21l3-8h10l3 8H4z" />
  </svg>
);

export const BatteryIcon = (p) => (
  <svg {...base} {...p}>
    <rect x="2" y="7" width="17" height="10" rx="1.5" />
    <line x1="21" y1="10" x2="21" y2="14" />
    <path d="M9.5 9.5L7 13h3l-1.5 2.5" />
  </svg>
);

export const SineWaveIcon = (p) => (
  <svg {...base} {...p}>
    <circle cx="12" cy="12" r="9.3" />
    <path d="M6 12c1.2-3 2.4-3 3.6 0s2.4 3 3.6 0 2.4-3 3.6 0" />
  </svg>
);

export const ShieldPlusIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M12 3l7 3v5c0 5-3 8.5-7 10-4-1.5-7-5-7-10V6l7-3z" />
    <path d="M12 9v6M9 12h6" />
  </svg>
);

export const BarChartIcon = (p) => (
  <svg {...base} {...p}>
    <line x1="6" y1="20" x2="6" y2="12" />
    <line x1="12" y1="20" x2="12" y2="6" />
    <line x1="18" y1="20" x2="18" y2="15" />
  </svg>
);

export const GearIcon = (p) => (
  <svg {...base} {...p}>
    <circle cx="12" cy="12" r="3" />
    <path d="M19.4 13.5c.06-.5.1-1 .1-1.5s-.04-1-.1-1.5l2.1-1.6-2-3.5-2.5 1a7.6 7.6 0 0 0-2.6-1.5L14 2h-4l-.4 2.9c-.95.35-1.83.86-2.6 1.5l-2.5-1-2 3.5 2.1 1.6c-.06.5-.1 1-.1 1.5s.04 1 .1 1.5L2.5 15l2 3.5 2.5-1c.77.64 1.65 1.15 2.6 1.5L10 22h4l.4-2.9c.95-.35 1.83-.86 2.6-1.5l2.5 1 2-3.5-2.1-1.6z" />
  </svg>
);

export const DataAnalyticsIcon = (p) => (
  <svg {...base} {...p}>
    <circle cx="6" cy="17" r="1.6" />
    <circle cx="12" cy="10" r="1.6" />
    <circle cx="18" cy="14" r="1.6" />
    <path d="M7.3 15.8L10.7 11.2M13.3 11.2L16.7 12.9" />
  </svg>
);

export const BellIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M18 16v-5a6 6 0 1 0-12 0v5l-1.5 2.5h15L18 16z" />
    <path d="M9.5 20a2.5 2.5 0 0 0 5 0" />
  </svg>
);

export const ShieldCheckIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6l7-3z" />
    <path d="M9 12l2 2 4-4" />
  </svg>
);

export const NetworkIcon = (p) => (
  <svg {...base} {...p}>
    <circle cx="5" cy="6" r="2" />
    <circle cx="19" cy="6" r="2" />
    <circle cx="5" cy="18" r="2" />
    <circle cx="12" cy="12" r="2" />
    <path d="M6.7 7.2L10.5 10.7M17.3 7.2L13.5 10.7M6.7 16.8L10.5 13.3" />
  </svg>
);

export const HomeIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M4 11.5L12 4l8 7.5" />
    <path d="M6 10v9.5a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1V10" />
    <path d="M10 20.5V14h4v6.5" />
  </svg>
);

export const ShopIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M4 9.5V20a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1V9.5" />
    <path d="M3 4h18l1.2 4.3a2 2 0 0 1-2 2.7 2.2 2.2 0 0 1-2.2-2M15.8 9c0 1.5-1.1 2.5-2.5 2.5S10.8 10.5 10.8 9M10.8 9c0 1.5-1.1 2.5-2.5 2.5S5.8 10.5 5.8 9M3.8 9c-.1 1.5-1.2 2.5-2.3 2.3a2 2 0 0 1-1.7-2.6L1 4" />
    <path d="M9 21v-5.5h6V21" />
  </svg>
);

export const SchoolIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M12 3L2 8l10 5 10-5-10-5z" />
    <path d="M6 10.5V16c0 1.5 2.7 3 6 3s6-1.5 6-3v-5.5" />
    <path d="M22 8v6.5" />
  </svg>
);

export const OfficeIcon = (p) => (
  <svg {...base} {...p}>
    <rect x="5" y="3" width="9" height="18" rx="0.8" />
    <rect x="14" y="9" width="6" height="12" rx="0.8" />
    <path d="M8 7h.01M11 7h.01M8 11h.01M11 11h.01M8 15h.01M11 15h.01M17 13h.01M17 17h.01" />
  </svg>
);

export const ClinicIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M4 21V9l8-5 8 5v12" />
    <path d="M4 21h16" />
    <path d="M12 8v5M9.5 10.5h5" />
  </svg>
);

export const TowerIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M12 3l4.5 18M12 3L7.5 21M9 12h6M7.7 16.5h8.6" />
    <path d="M9 8a4.2 4.2 0 0 1 6 0M7 5.3a7.4 7.4 0 0 1 10 0" />
  </svg>
);

export const PlugIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M9 2v4M15 2v4" />
    <path d="M6 6h12v4a6 6 0 0 1-12 0V6z" />
    <path d="M12 16v3" />
    <path d="M9 21h6" />
  </svg>
);

export const FactoryIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M3 21V10l5 3.5V10l5 3.5V10l5 3.5V21H3z" />
    <path d="M7 21v-4M12 21v-4M17 21v-4" />
  </svg>
);

export const TruckIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M3 7h11v9H3z" />
    <path d="M14 11h4l3 3v2h-7z" />
    <circle cx="7.5" cy="18" r="1.6" />
    <circle cx="17.5" cy="18" r="1.6" />
  </svg>
);

export const ShieldHomeIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M12 2l8 3v6c0 5-3.5 8.5-8 11-4.5-2.5-8-6-8-11V5l8-3z" />
    <path d="M9 13.5l3-2.3 3 2.3V16h-6z" />
  </svg>
);

export const HeadsetIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M4 13a8 8 0 0 1 16 0" />
    <rect x="3" y="13" width="4" height="6" rx="1.4" />
    <rect x="17" y="13" width="4" height="6" rx="1.4" />
    <path d="M20 19v1a3 3 0 0 1-3 3h-4" />
  </svg>
);
