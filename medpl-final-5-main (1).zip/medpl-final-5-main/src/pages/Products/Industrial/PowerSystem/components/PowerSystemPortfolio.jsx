import React, { useState } from 'react';
import './PowerSystemPortfolio.css';
import HybridInverterModal from './HybridInverterModal.jsx';
import ChargerDetailModal from './ChargerDetailModal.jsx';
import chargerImage from '../assets/detail/charger-hero.webp';
import hybridInverterImage from '../assets/detail/hybrid-inverter-hero.webp';

const CheckIcon = () => (
  <svg viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="10" cy="10" r="9" stroke="currentColor" strokeWidth="1.4" />
    <path d="M6.2 10.2l2.4 2.4 5.2-5.6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const ImagePlaceholderIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="3" y="4.5" width="18" height="15" rx="1.6" stroke="currentColor" strokeWidth="1.4" />
    <circle cx="8.3" cy="9.5" r="1.6" stroke="currentColor" strokeWidth="1.4" />
    <path d="M3.8 16.5l5-5 3.4 3.4 2.3-2.3 5.5 5.4" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const PORTFOLIO = [
  {
    id: 'hybrid-inverter',
    title: 'Hybrid Inverter',
    description:
      'Hybrid inverters for reliable AC output with seamless switching between battery, solar and grid-connected DC systems.',
    bullets: ['High efficiency conversion', '1 KVA – 5 KVA range'],
    note: 'Wall-mount design with smart BMS integration.',
    image: hybridInverterImage,
    imageCaption: 'Hybrid inverter unit — product photo',
  },
  {
    id: 'charger',
    title: 'Charger',
    description:
      "Smart charging systems for MEDPL's dual-chemistry battery platform, supporting Lithium-ion and Sodium-ion packs with intelligent charge algorithms and protection.",
    bullets: [
      'Lithium-ion (LFP / NMC) & Sodium-ion compatible',
      'Chemistry-specific adaptive charge profiles',
      'Overcharge, thermal & safety protection',
    ],
    image: chargerImage,
    imageCaption: 'Charger unit — product photo (Lithium-ion / Sodium-ion)',
  },
];

export default function PowerSystemPortfolio() {
  const [isHybridInverterOpen, setHybridInverterOpen] = useState(false);
  const [isChargerOpen, setChargerOpen] = useState(false);

  const handleViewDetails = (item) => (e) => {
    e.preventDefault();
    if (item.id === 'hybrid-inverter') {
      setHybridInverterOpen(true);
    } else if (item.id === 'charger') {
      setChargerOpen(true);
    }
  };

  return (
    <section className="psport-section">
      <div className="psport-header">
        <h2>Our Power System Portfolio</h2>
        <p>Engineered to deliver dependable power across a wide range of industrial environments.</p>
      </div>

      <div className="psport-grid">
        {PORTFOLIO.map((item) => (
          <article className="psport-card" key={item.title}>
            {item.image ? (
              <div className="psport-image">
                <img src={item.image} alt={item.imageCaption} />
              </div>
            ) : (
              <div className="psport-image-placeholder">
                <ImagePlaceholderIcon />
                <span className="psport-image-label">Website image placeholder</span>
                <span className="psport-image-caption">{item.imageCaption}</span>
              </div>
            )}

            <div className="psport-body">
              <h3>{item.title}</h3>
              <p className="psport-desc">{item.description}</p>

              <ul className="psport-list">
                {item.bullets.map((bullet) => (
                  <li key={bullet}>
                    <CheckIcon />
                    <span>{bullet}</span>
                  </li>
                ))}
              </ul>

              {item.note && <p className="psport-note">{item.note}</p>}

              <a className="psport-link" href="#" onClick={handleViewDetails(item)}>
                VIEW DETAILS <span aria-hidden="true">→</span>
              </a>
            </div>
          </article>
        ))}
      </div>

      <HybridInverterModal
        isOpen={isHybridInverterOpen}
        onClose={() => setHybridInverterOpen(false)}
      />
      <ChargerDetailModal
        isOpen={isChargerOpen}
        onClose={() => setChargerOpen(false)}
      />
    </section>
  );
}
