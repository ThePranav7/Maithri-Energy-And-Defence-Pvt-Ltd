import { useEffect } from "react";
import NavGap from "../../../../components/Layout/NavGap.jsx";
import PowerSystemProducts from "./components/PowerSystemProducts.jsx";
import PowerSystemPortfolio from "./components/PowerSystemPortfolio.jsx";
import CriticalPerformance from "./components/CriticalPerformance.jsx";
import CustomPowerSolution from "./components/CustomPowerSolution.jsx";

export default function PowerSystemPage() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <main className="power-system-page">
      <NavGap />
      <PowerSystemProducts />
      <PowerSystemPortfolio />
      <CriticalPerformance />
      <CustomPowerSolution />
    </main>
  );
}
