import ctaBg from "../assets/cta-bg.webp";
import "./CtaBanner.css";

export default function CtaBanner() {
  return (
    <section className="cta-banner-wrap">
      <div className="cta-banner">
        <img
          className="cta-banner-bg"
          src={ctaBg}
          alt="Silhouette of a person standing on a mountain peak overlooking a range of snow-capped mountains"
        />
        <div className="cta-banner-overlay"></div>

        <div className="cta-banner-content">
          <h2>Looking for the right solution?</h2>
          <p>
            Our experts are here to help you build smarter, safer and more
            efficient systems.
          </p>
        </div>

        <a className="cta-banner-btn" href="/contact#contact-details">
          TALK TO OUR EXPERTS <span className="arrow">&rarr;</span>
        </a>
      </div>
    </section>
  );
}
