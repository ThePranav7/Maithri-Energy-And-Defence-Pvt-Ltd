import { Link } from "react-router-dom";
import industrialEnergy from "../../../assets/solutions-preview/industrial-energy.webp";
import defenseSystems from "../../../assets/solutions-preview/defense-systems.webp";
import iotSolutions from "../../../assets/solutions-preview/iot-solutions.webp";
import "./ProductPortfolio.css";

const categories = [
  {
    id: "industrial",
    title: "Industrial",
    image: industrialEnergy,
    description:
      "Advanced energy solutions for industrial and commercial applications.",
    items: [
      { label: "Li-ion Battery", icon: "battery", to: "/products/industrial/li-ion" },
      { label: "Power System Products", icon: "plug", to: "/products/industrial/power-system" },
      { label: "BMS", icon: "shield", to: "/products/industrial/bms" },
    ],
    cta: "Explore Industrial",
  },
  {
    id: "defense",
    title: "Defense",
    image: defenseSystems,
    description:
      "Advanced power solutions for critical defense operations across land, sea, air and space.",
    items: [
      { label: "Lithium-ion", icon: "battery", to: "/products/defense" },
      { label: "Sodium-ion", icon: "clock", to: "/products/defense" },
      { label: "Underwater", icon: "person", to: "/products/defense" },
      { label: "Ground", icon: "person", to: "/products/defense" },
      { label: "Aerospace", icon: "person", to: "/products/defense" },
    ],
    cta: "Explore Defense",
  },
  {
    id: "iot",
    title: "IoT",
    image: iotSolutions,
    description:
      "Intelligent systems for real-time monitoring, control and data-driven decisions.",
    items: [
      { label: "Controller for AWG", icon: "controller", to: "/products/iot" },
      { label: "Server Front-End Solution", icon: "server", to: "/products/iot" },
    ],
    cta: "Explore IoT",
  },
];

function Icon({ type }) {
  const common = {
    width: 18,
    height: 18,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "#1b2a6b",
    strokeWidth: 1.6,
    strokeLinecap: "round",
    strokeLinejoin: "round",
  };

  switch (type) {
    case "battery":
      return (
        <svg {...common}>
          <rect x="2" y="7" width="17" height="10" rx="1.5" />
          <line x1="21" y1="10" x2="21" y2="14" />
          <line x1="6" y1="10" x2="6" y2="14" />
        </svg>
      );
    case "plug":
      return (
        <svg {...common}>
          <path d="M9 2v4M15 2v4" />
          <path d="M6 6h12v4a6 6 0 0 1-12 0V6z" />
          <path d="M12 16v3" />
          <path d="M9 21h6" />
        </svg>
      );
    case "shield":
      return (
        <svg {...common}>
          <path d="M12 2l8 3v6c0 5-3.5 8.5-8 11-4.5-2.5-8-6-8-11V5l8-3z" />
          <path d="M9 12l2 2 4-4" />
        </svg>
      );
    case "clock":
      return (
        <svg {...common}>
          <circle cx="12" cy="12" r="9" />
          <path d="M12 7v5l3 3" />
        </svg>
      );
    case "person":
      return (
        <svg {...common}>
          <circle cx="12" cy="8" r="3.2" />
          <path d="M5 20c0-3.5 3-6 7-6s7 2.5 7 6" />
        </svg>
      );
    case "controller":
      return (
        <svg {...common}>
          <path d="M4 12h4M6 10v4" />
          <circle cx="16" cy="10.5" r="1" fill="#1b2a6b" />
          <circle cx="18.5" cy="13" r="1" fill="#1b2a6b" />
          <rect x="2" y="8" width="20" height="9" rx="4.5" />
        </svg>
      );
    case "server":
      return (
        <svg {...common}>
          <rect x="3" y="4" width="18" height="6" rx="1.2" />
          <rect x="3" y="14" width="18" height="6" rx="1.2" />
          <circle cx="7" cy="7" r="0.6" fill="#1b2a6b" />
          <circle cx="7" cy="17" r="0.6" fill="#1b2a6b" />
        </svg>
      );
    default:
      return null;
  }
}

export default function ProductPortfolio() {
  return (
    <section className="portfolio" id="portfolio">
      <div className="portfolio-header">
        <h2>Explore Our Product Portfolio</h2>
        <p>
          From high-performance energy systems to mission-critical defense
          technologies and intelligent IoT solutions,
          <br />
          our products are built to power progress and protect what matters.
        </p>
      </div>

      <div className="portfolio-grid">
        {categories.map((cat) => (
          <div className="portfolio-card" id={cat.id} key={cat.id}>
            <div
              className="card-image"
              style={{ backgroundImage: `url(${cat.image})` }}
              aria-hidden="true"
            ></div>

            <div className="card-body">
              <h3>{cat.title}</h3>
              <p className="card-desc">{cat.description}</p>

              <ul className="card-list">
                {cat.items.map((item) => (
                  <li key={item.label}>
                    <Link
                      className="card-list-link"
                      to={item.to}
                      onClick={() => window.scrollTo(0, 0)}
                    >
                      <span className="icon-wrap">
                        <Icon type={item.icon} />
                      </span>
                      <span>{item.label}</span>
                    </Link>
                  </li>
                ))}
              </ul>

              {cat.id === "industrial" ? (
                <Link className="card-cta" to="/products/industrial">
                  {cat.cta} <span className="arrow">&rarr;</span>
                </Link>
              ) : cat.id === "defense" ? (
                <Link
                  className="card-cta"
                  to="/products/defense"
                  onClick={() => window.scrollTo(0, 0)}
                >
                  {cat.cta} <span className="arrow">&rarr;</span>
                </Link>
              ) : cat.id === "iot" ? (
                <Link
                  className="card-cta"
                  to="/products/iot"
                  onClick={() => window.scrollTo(0, 0)}
                >
                  {cat.cta} <span className="arrow">&rarr;</span>
                </Link>
              ) : (
                <a className="card-cta" href={`#${cat.id}`}>
                  {cat.cta} <span className="arrow">&rarr;</span>
                </a>
              )}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
