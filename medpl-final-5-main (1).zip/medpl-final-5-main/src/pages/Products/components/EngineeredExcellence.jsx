import "./EngineeredExcellence.css";

const features = [
  {
    id: "rd",
    title: "Advanced R&D",
    description: "Continuous innovation to solve complex challenges.",
    icon: "flask",
  },
  {
    id: "quality",
    title: "Quality Assured",
    description: "Tested to global standards for safety and reliability.",
    icon: "shield",
  },
  {
    id: "scalable",
    title: "Scalable Solutions",
    description: "Designed to grow with your evolving needs.",
    icon: "scale",
  },
  {
    id: "support",
    title: "End-to-End Support",
    description: "From consultation to after-sales support, we're with you.",
    icon: "headset",
  },
];

function FeatureIcon({ type }) {
  const common = {
    width: 32,
    height: 32,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "#0f1f5c",
    strokeWidth: 1.5,
    strokeLinecap: "round",
    strokeLinejoin: "round",
  };

  switch (type) {
    case "flask":
      return (
        <svg {...common}>
          <path d="M9 2h6" />
          <path d="M10 2v6.2a2 2 0 0 1-.4 1.2L4.8 16.9A2.5 2.5 0 0 0 6.8 21h10.4a2.5 2.5 0 0 0 2-4.1l-4.8-7.5a2 2 0 0 1-.4-1.2V2" />
          <path d="M6.5 15h11" />
        </svg>
      );
    case "shield":
      return (
        <svg {...common}>
          <path d="M12 3l7 3v5.5c0 4.6-3 8.6-7 9.5-4-.9-7-4.9-7-9.5V6l7-3z" />
          <path d="M9.5 12l1.8 1.8 3.2-3.6" />
        </svg>
      );
    case "scale":
      return (
        <svg {...common}>
          <path d="M9 3H3v6" />
          <path d="M3 3l6.5 6.5" />
          <path d="M15 21h6v-6" />
          <path d="M21 21l-6.5-6.5" />
          <path d="M9 21H3v-6" />
          <path d="M3 21l6.5-6.5" />
          <path d="M15 3h6v6" />
          <path d="M21 3l-6.5 6.5" />
        </svg>
      );
    case "headset":
      return (
        <svg {...common}>
          <path d="M4 13v-1a8 8 0 0 1 16 0v1" />
          <rect x="3" y="13" width="4" height="6" rx="1.5" />
          <rect x="17" y="13" width="4" height="6" rx="1.5" />
          <path d="M19 19v1a3 3 0 0 1-3 3h-3" />
        </svg>
      );
    default:
      return null;
  }
}

export default function EngineeredExcellence() {
  return (
    <section className="excellence">
      <div className="excellence-inner">
        <div className="excellence-intro">
          <h2>Engineered for Excellence</h2>
          <p>
            We combine cutting-edge technology with rigorous testing and
            quality standards to deliver products that exceed expectations.
          </p>
        </div>

        <div className="excellence-features">
          {features.map((feature) => (
            <div className="excellence-feature" key={feature.id}>
              <div className="feature-icon">
                <FeatureIcon type={feature.icon} />
              </div>
              <h3>{feature.title}</h3>
              <p>{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
