import heroBg from '../assets/products-hero-bg.webp'
import './ProductsHero.css'

export default function ProductsHero() {
  return (
    <section className="products-hero">
      <img
        className="products-hero__bg"
        src={heroBg}
        alt="Maithri industrial control cabinets and battery enclosures inside a factory floor"
      />
      <div className="products-hero__content">
        <h1>Industrial Energy Solutions</h1>
        <p>
          Innovative and reliable solutions across Industrial, Defense and
          IoT domains, engineered for performance, safety and long-term
          value.
        </p>
      </div>
    </section>
  )
}
