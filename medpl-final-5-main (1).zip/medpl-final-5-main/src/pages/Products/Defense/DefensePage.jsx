import { useEffect } from "react";
import { useLocation } from "react-router-dom";
import NavGap from "../../../components/Layout/NavGap.jsx";
import DefenseHero from "./components/DefenseHero.jsx";
import ProductPortfolio from "./components/ProductPortfolio.jsx";
import ExtremeConditions from "./components/ExtremeConditions.jsx";
import MissionCTA from "./components/MissionCTA.jsx";

const NAVBAR_OFFSET = 90;

export default function DefensePage() {
  const location = useLocation();

  useEffect(() => {
    if (location.hash) {
      const el = document.getElementById(location.hash.slice(1));
      if (el) {
        const top = el.getBoundingClientRect().top + window.scrollY - NAVBAR_OFFSET;
        window.scrollTo({ top, behavior: "smooth" });
        return;
      }
    }
    window.scrollTo(0, 0);
  }, [location.pathname, location.hash]);

  return (
    <div className="defense-page">
      <NavGap />
      <DefenseHero />
      <ProductPortfolio />
      <ExtremeConditions />
      <MissionCTA />
    </div>
  );
}
