import React from 'react';
import '../styles/DefenseHero.css';

import missionCriticalIcon from '../assets/icons/mission-critical.svg';
import ruggedReliableIcon from '../assets/icons/rugged-reliable.svg';
import highPerformanceIcon from '../assets/icons/high-performance.svg';
import customSolutionsIcon from '../assets/icons/custom-solutions.svg';

/* ---------------- Hero heading + description ---------------- */
function HeroContent() {
  return (
    <>
      <h1 className="dps-heading">
        <span>Defense Power Solutions</span>
      </h1>
      <p className="dps-description">
        Mission-ready power systems engineered for reliability, resilience
        and performance in the most demanding defense environments.
      </p>
    </>
  );
}

/* ---------------- Single feature item ---------------- */
function FeatureItem({ icon, title, lines }) {
  return (
    <div className="dps-feature">
      <span className="dps-feature-icon" aria-hidden="true">
        <img src={icon} alt="" />
      </span>
      <div className="dps-feature-text">
        <h3>{title}</h3>
        <p>
          {lines.map((line, i) => (
            <React.Fragment key={i}>
              {line}
              {i < lines.length - 1 && <br />}
            </React.Fragment>
          ))}
        </p>
      </div>
    </div>
  );
}

/* ---------------- Feature list (4 items) ---------------- */
function FeatureList() {
  const features = [
    {
      icon: missionCriticalIcon,
      title: 'Mission Critical',
      lines: ['Designed for', 'uncompromised', 'reliability'],
    },
    {
      icon: ruggedReliableIcon,
      title: 'Rugged & Reliable',
      lines: ['Built to withstand', 'extreme conditions'],
    },
    {
      icon: highPerformanceIcon,
      title: 'High Performance',
      lines: ['Optimized for', 'continuous', 'performance'],
    },
    {
      icon: customSolutionsIcon,
      title: 'Custom Solutions',
      lines: ['Tailored systems for', 'specific mission', 'requirements'],
    },
  ];

  return (
    <div className="dps-features">
      {features.map((f) => (
        <FeatureItem key={f.title} icon={f.icon} title={f.title} lines={f.lines} />
      ))}
    </div>
  );
}

/* ---------------- Root component ---------------- */
export default function DefenseHero() {
  return (
    <section className="dps-hero">
      <div className="dps-content">
        <HeroContent />
        <FeatureList />
      </div>
    </section>
  );
}
