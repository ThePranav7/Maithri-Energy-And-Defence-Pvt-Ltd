import React from 'react';
import '../styles/MissionCTA.css';

import arrowIcon from '../assets/icons/arrow-right.svg';
import ctaBg from '../assets/cta-soldiers-bg.webp';

export default function MissionCTA() {
  return (
    <section className="mcta-wrap">
      <div
        className="mcta-panel"
        style={{ backgroundImage: `url(${ctaBg})` }}
      >
        <span className="mcta-curve mcta-curve--tl" aria-hidden="true" />
        <span className="mcta-curve mcta-curve--tr" aria-hidden="true" />
        <span className="mcta-curve mcta-curve--bl" aria-hidden="true" />
        <span className="mcta-curve mcta-curve--br" aria-hidden="true" />

        <div className="mcta-overlay" />

        <div className="mcta-content">
          <div className="mcta-text">
            <h2>Powering Missions. Enabling Success.</h2>
            <p>Partner with us for reliable defense power solutions.</p>
          </div>

          <a className="mcta-btn" href="/contact#contact-details">
            TALK TO OUR EXPERTS
            <img src={arrowIcon} alt="" />
          </a>
        </div>
      </div>
    </section>
  );
}
