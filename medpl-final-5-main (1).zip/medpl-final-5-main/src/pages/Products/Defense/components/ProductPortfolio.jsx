import React, { useState } from 'react';
import '../styles/ProductPortfolio.css';

import checkIcon from '../assets/icons/check-circle.svg';
import arrowIcon from '../assets/icons/arrow-right.svg';

import ProductDetailModal, { ICONS } from './ProductDetailModal.jsx';
import lithiumDetailHero from '../assets/detail/lithium-detail-hero.webp';
import sodiumDetailHero from '../assets/detail/sodium-detail-hero.webp';
import portfolioCardImage from '../assets/detail/defense-portfolio-card.webp';
import lithiumPortfolioCardImage from '../assets/detail/lithium-portfolio-card.webp';

/* ---------------- Section heading ---------------- */
function PortfolioHeading() {
  return (
    <div className="dpp-heading-wrap">
      <h2 className="dpp-heading">Our Defense Product Portfolio</h2>
      <p className="dpp-subtitle">
        Advanced power and energy solutions for land, air, sea and space applications.
      </p>
    </div>
  );
}

/* ---------------- Image placeholder block ---------------- */
function MediaPlaceholder({ label }) {
  return (
    <div className="dpp-placeholder">
      <span className="dpp-placeholder-icon" role="img" aria-label="placeholder">
        🏟️
      </span>
      <span className="dpp-placeholder-title">Website Image Placeholder</span>
      <span className="dpp-placeholder-caption">{label}</span>
    </div>
  );
}

/* ---------------- One Application / Description row ---------------- */
function ApplicationItem({ name, description }) {
  return (
    <li className="dpp-app-item">
      <span className="dpp-app-icon">
        <img src={checkIcon} alt="" />
      </span>
      <div className="dpp-app-text">
        <p className="dpp-app-name">{name}</p>
        <p className="dpp-app-desc">{description}</p>
      </div>
    </li>
  );
}

/* ---------------- Product card ---------------- */
function ProductCard({ title, applications, placeholderLabel, imageSrc, onViewDetails }) {
  return (
    <div className="dpp-card">
      <div className="dpp-card-media">
        {imageSrc ? (
          <img src={imageSrc} alt={title} />
        ) : (
          <MediaPlaceholder label={placeholderLabel} />
        )}
      </div>

      <div className="dpp-card-body">
        <h3 className="dpp-card-title">{title}</h3>

        <ul className="dpp-app-list">
          {applications.map((a) => (
            <ApplicationItem key={a.name} name={a.name} description={a.description} />
          ))}
        </ul>

        <button type="button" className="dpp-view-details" onClick={onViewDetails}>
          VIEW DETAILS
          <img src={arrowIcon} alt="" />
        </button>
      </div>
    </div>
  );
}

/* ---------------- Root section ---------------- */
export default function ProductPortfolio() {
  const [activeIndex, setActiveIndex] = useState(null);

  const products = [
    {
      title: 'Lithium-ion — Defense Platforms',
      placeholderLabel: 'Defense platform — Lithium-ion system photo/render',
      imageSrc: lithiumPortfolioCardImage,
      applications: [
        {
          name: 'Underwater',
          description:
            'Lithium-ion power systems engineered for underwater defense platforms, including the HEAUV (High Endurance Autonomous Underwater Vehicle) programme delivered to NSTL, DRDO.',
        },
        {
          name: 'Ground',
          description: 'Rugged Lithium-ion power systems for ground defense systems and vehicles.',
        },
        {
          name: 'Aerospace',
          description: 'Lightweight, high-reliability Lithium-ion systems for aerospace defense applications.',
        },
      ],
      detail: {
        heroImage: lithiumDetailHero,
        badgeLabel: 'Li+',
        title: 'Lithium-ion — Defense Platforms',
        tagline: 'High Performance. Mission Ready. Built for Defense.',
        description:
          'Advanced Lithium-ion power systems engineered for mission-critical defense platforms across underwater, ground and aerospace applications. Trusted performance in the most demanding environments.',
        solutions: [
          {
            icon: ICONS.droplet,
            name: 'Underwater',
            description:
              'Lithium-ion power systems engineered for underwater defense platforms, including the HEAUV (High Endurance Autonomous Underwater Vehicle) programme delivered to NSTL, DRDO.',
          },
          {
            icon: ICONS.shieldCheck,
            name: 'Ground',
            description: 'Rugged Lithium-ion power systems for ground defense systems and vehicles.',
          },
          {
            icon: ICONS.pulse,
            name: 'Aerospace',
            description: 'Lightweight, high-reliability Lithium-ion systems for aerospace defense applications.',
          },
        ],
        advantages: [
          {
            icon: ICONS.highPerformance,
            name: 'High Energy Density',
            description: 'Maximum power in compact form factors for extended mission duration.',
          },
          {
            icon: ICONS.ruggedReliable,
            name: 'Rugged & Reliable',
            description: 'Built to withstand extreme environments and harsh conditions.',
          },
          {
            icon: ICONS.missionCritical,
            name: 'Mission Critical Safety',
            description: 'Advanced BMS and protection for uncompromised safety.',
          },
          {
            icon: ICONS.temperature,
            name: 'Wide Operating Range',
            description: 'Reliable performance in extreme temperatures and conditions.',
          },
          {
            icon: ICONS.customSolutions,
            name: 'Custom Engineered',
            description: 'Tailored solutions for specific mission requirements.',
          },
        ],
        technicalHighlights: [
          { icon: ICONS.check, label: 'Technology', value: 'Lithium-ion (LFP / NMC)' },
          { icon: ICONS.highPerformance, label: 'Voltage Range', value: '24V – 800V+' },
          { icon: ICONS.pulse, label: 'Capacity Range', value: 'Customizable from Ah to kWh' },
          { icon: ICONS.temperature, label: 'Operating Temp.', value: '-40°C to +60°C' },
          { icon: ICONS.shieldCheck, label: 'Protection', value: 'Multi-layer BMS & Safety' },
          { icon: ICONS.ruggedReliable, label: 'Certifications', value: 'MIL-STD Compliant (As required)' },
        ],
        bannerTitle: 'Engineered for Critical Missions',
        bannerSubtitle: 'Trusted by defense agencies. Built for performance.',
      },
    },
    {
      title: 'Sodium-ion — Defense Platforms',
      placeholderLabel: 'Defense platform — Sodium-ion system photo/render',
      imageSrc: portfolioCardImage,
      applications: [
        {
          name: 'Underwater',
          description:
            'Sodium-ion power systems for underwater defense applications, offering an alternative chemistry profile for specific mission requirements.',
        },
        {
          name: 'Ground',
          description: 'Sodium-ion power systems for ground-based defense platforms.',
        },
        {
          name: 'Aerospace',
          description: 'Sodium-ion systems engineered for aerospace defense use cases.',
        },
      ],
      detail: {
        heroImage: sodiumDetailHero,
        badgeLabel: 'Na+',
        title: 'Sodium-ion — Defense Platforms',
        tagline: 'Safe. Sustainable. Reliable for Critical Missions.',
        description:
          'Sodium-ion power systems deliver excellent safety, thermal stability and sustainability for defense platforms. An alternative chemistry profile for mission-specific requirements.',
        solutions: [
          {
            icon: ICONS.droplet,
            name: 'Underwater',
            description:
              'Sodium-ion power systems for underwater defense applications, offering an alternative chemistry profile for specific mission requirements.',
          },
          {
            icon: ICONS.shieldCheck,
            name: 'Ground',
            description: 'Sodium-ion power systems for ground-based defense platforms.',
          },
          {
            icon: ICONS.pulse,
            name: 'Aerospace',
            description: 'Sodium-ion systems engineered for aerospace defense use cases.',
          },
        ],
        advantages: [
          {
            icon: ICONS.missionCritical,
            name: 'Enhanced Safety',
            description: 'Inherent safety and thermal stability for reliable operations.',
          },
          {
            icon: ICONS.tools,
            name: 'Cost Effective',
            description: 'Abundant and affordable raw materials for reduced lifecycle cost.',
          },
          {
            icon: ICONS.customSolutions,
            name: 'Sustainable Choice',
            description: 'Environmentally friendly chemistry with lower carbon footprint.',
          },
          {
            icon: ICONS.shieldCheck,
            name: 'Long Cycle Life',
            description: 'Excellent cycle life and calendar life for demanding missions.',
          },
          {
            icon: ICONS.ruggedReliable,
            name: 'Reliable Performance',
            description: 'Consistent performance across a wide range of conditions.',
          },
        ],
        technicalHighlights: [
          { icon: ICONS.check, label: 'Technology', value: 'Sodium-ion (Na-ion)' },
          { icon: ICONS.highPerformance, label: 'Voltage Range', value: '24V – 800V+' },
          { icon: ICONS.pulse, label: 'Capacity Range', value: 'Customizable from Ah to kWh' },
          { icon: ICONS.temperature, label: 'Operating Temp.', value: '-40°C to +60°C' },
          { icon: ICONS.shieldCheck, label: 'Protection', value: 'Advanced BMS & Safety' },
          { icon: ICONS.ruggedReliable, label: 'Certifications', value: 'MIL-STD Compliant (As required)' },
        ],
        bannerTitle: 'Powering a Sustainable Defense Future',
        bannerSubtitle: 'Reliable. Sustainable. Mission Ready.',
      },
    },
  ];

  const activeProduct = activeIndex !== null ? products[activeIndex].detail : null;

  return (
    <section className="dpp-section" id="defense-portfolio">
      <PortfolioHeading />
      <div className="dpp-grid">
        {products.map((p, i) => (
          <ProductCard key={p.title} {...p} imageSrc={p.imageSrc} onViewDetails={() => setActiveIndex(i)} />
        ))}
      </div>

      <ProductDetailModal
        isOpen={activeIndex !== null}
        onClose={() => setActiveIndex(null)}
        product={activeProduct}
      />
    </section>
  );
}
