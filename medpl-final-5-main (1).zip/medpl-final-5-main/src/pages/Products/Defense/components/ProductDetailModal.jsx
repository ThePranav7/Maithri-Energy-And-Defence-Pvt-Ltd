import React, { useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/ProductDetailModal.css';

import shieldCheckIcon from '../assets/icons/shield-check.svg';
import highPerformanceIcon from '../assets/icons/high-performance.svg';
import ruggedReliableIcon from '../assets/icons/rugged-reliable.svg';
import missionCriticalIcon from '../assets/icons/mission-critical.svg';
import temperatureIcon from '../assets/icons/temperature.svg';
import customSolutionsIcon from '../assets/icons/custom-solutions.svg';
import checkIcon from '../assets/icons/check-circle.svg';
import pulseIcon from '../assets/icons/pulse.svg';
import droplet from '../assets/icons/droplet.svg';
import tools from '../assets/icons/tools.svg';

const CloseIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

const ArrowRightIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <path d="M5 12h14M13 6l6 6-6 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

/* ---------------- One "Our Solutions" row ---------------- */
function SolutionItem({ icon, name, description }) {
  return (
    <li className="pdm-solution-item">
      <span className="pdm-solution-icon">
        <img src={icon} alt="" />
      </span>
      <div className="pdm-solution-text">
        <p className="pdm-solution-name">{name}</p>
        <p className="pdm-solution-desc">{description}</p>
      </div>
    </li>
  );
}

/* ---------------- One "Key Advantages" row ---------------- */
function AdvantageItem({ icon, name, description }) {
  return (
    <li className="pdm-advantage-item">
      <span className="pdm-advantage-icon">
        <img src={icon} alt="" />
      </span>
      <div className="pdm-advantage-text">
        <p className="pdm-advantage-name">{name}</p>
        <p className="pdm-advantage-desc">{description}</p>
      </div>
    </li>
  );
}

/* ---------------- One "Technical Highlights" cell ---------------- */
function HighlightCell({ icon, label, value }) {
  return (
    <div className="pdm-highlight-cell">
      <span className="pdm-highlight-icon">
        <img src={icon} alt="" />
      </span>
      <p className="pdm-highlight-label">{label}</p>
      <p className="pdm-highlight-value">{value}</p>
    </div>
  );
}

export default function ProductDetailModal({ isOpen, onClose, product }) {
  const dialogRef = useRef(null);
  const navigate = useNavigate();

  const goToContact = () => {
    onClose();
    navigate('/contact#contact-details');
  };

  useEffect(() => {
    if (!isOpen) return undefined;
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  useEffect(() => {
    if (!isOpen) return undefined;
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = prevOverflow;
    };
  }, [isOpen]);

  if (!isOpen || !product) return null;

  const handleBackdropClick = (e) => {
    if (e.target === e.currentTarget) onClose();
  };

  return (
    <div className="pdm-backdrop" onMouseDown={handleBackdropClick}>
      <div
        className="pdm-dialog"
        role="dialog"
        aria-modal="true"
        aria-labelledby="pdm-title"
        ref={dialogRef}
      >
        <button className="pdm-close" onClick={onClose} aria-label="Close details">
          <CloseIcon />
        </button>

        {/* ---- Hero image ---- */}
        <div className="pdm-hero">
          <img src={product.heroImage} alt={product.title} />
          <span className="pdm-hero-badge">{product.badgeLabel}</span>
        </div>

        <div className="pdm-body">
          <h2 className="pdm-title" id="pdm-title">
            {product.title}
          </h2>
          <p className="pdm-tagline">{product.tagline}</p>
          <p className="pdm-description">{product.description}</p>

          <div className="pdm-columns">
            {/* ---- Our Solutions ---- */}
            <div className="pdm-column">
              <span className="pdm-section-badge">OUR SOLUTIONS</span>
              <ul className="pdm-solution-list">
                {product.solutions.map((s) => (
                  <SolutionItem key={s.name} {...s} />
                ))}
              </ul>
            </div>

            {/* ---- Key Advantages ---- */}
            <div className="pdm-column">
              <span className="pdm-section-badge">KEY ADVANTAGES</span>
              <ul className="pdm-advantage-list">
                {product.advantages.map((a) => (
                  <AdvantageItem key={a.name} {...a} />
                ))}
              </ul>
            </div>
          </div>

          {/* ---- Technical Highlights ---- */}
          <div className="pdm-technical">
            <span className="pdm-section-badge">TECHNICAL HIGHLIGHTS</span>
            <div className="pdm-highlight-grid">
              {product.technicalHighlights.map((h) => (
                <HighlightCell key={h.label} {...h} />
              ))}
            </div>
          </div>

          {/* ---- Bottom banner ---- */}
          <div className="pdm-banner">
            <span className="pdm-banner-badge">{product.badgeLabel}</span>
            <div className="pdm-banner-text">
              <p className="pdm-banner-title">{product.bannerTitle}</p>
              <p className="pdm-banner-subtitle">{product.bannerSubtitle}</p>
            </div>
            <button className="pdm-banner-cta" onClick={goToContact}>
              Contact Us
              <ArrowRightIcon />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export const ICONS = {
  shieldCheck: shieldCheckIcon,
  highPerformance: highPerformanceIcon,
  ruggedReliable: ruggedReliableIcon,
  missionCritical: missionCriticalIcon,
  temperature: temperatureIcon,
  customSolutions: customSolutionsIcon,
  check: checkIcon,
  pulse: pulseIcon,
  droplet,
  tools,
};
