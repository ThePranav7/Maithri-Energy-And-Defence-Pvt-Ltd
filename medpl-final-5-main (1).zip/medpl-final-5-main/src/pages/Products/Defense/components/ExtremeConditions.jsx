import React from 'react';
import '../styles/ExtremeConditions.css';

import temperatureIcon from '../assets/icons/temperature.svg';
import shieldCheckIcon from '../assets/icons/shield-check.svg';
import dropletIcon from '../assets/icons/droplet.svg';
import pulseIcon from '../assets/icons/pulse.svg';
import toolsIcon from '../assets/icons/tools.svg';

const FEATURES = [
  {
    icon: temperatureIcon,
    title: 'Wide Temperature Range',
    description: '-40°C to +85°C operation',
  },
  {
    icon: shieldCheckIcon,
    title: 'MIL-STD Compliant',
    description: 'Designed to meet military standards',
  },
  {
    icon: dropletIcon,
    title: 'Environmental Protection',
    description: 'Waterproof, dustproof & corrosion resistant',
  },
  {
    icon: pulseIcon,
    title: 'High Reliability',
    description: 'Built for continuous mission critical operations',
  },
  {
    icon: toolsIcon,
    title: 'Customizable Solutions',
    description: 'Tailored to meet specific mission needs',
  },
];

function Feature({ icon, title, description }) {
  return (
    <div className="bfe-feature">
      <span className="bfe-feature-icon">
        <img src={icon} alt="" />
      </span>
      <h3>{title}</h3>
      <p>{description}</p>
    </div>
  );
}

export default function ExtremeConditions() {
  return (
    <section className="bfe-wrap">
      <div className="bfe-panel">
        <span className="bfe-curve bfe-curve--one" aria-hidden="true" />
        <span className="bfe-curve bfe-curve--two" aria-hidden="true" />

        <div className="bfe-intro">
          <h2>
            Built for
            <br />
            Extreme Conditions
          </h2>
          <p>
            Our defense solutions are engineered to perform in the harshest
            environments and critical mission scenarios.
          </p>
        </div>

        <div className="bfe-features">
          {FEATURES.map((f) => (
            <Feature key={f.title} {...f} />
          ))}
        </div>
      </div>
    </section>
  );
}
