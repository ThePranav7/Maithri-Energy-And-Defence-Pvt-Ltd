import { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import NavGap from "../../../components/Layout/NavGap.jsx";
import bannerImage from "./assets/iot-1.webp";
import IoTShowcaseCard from "./components/IoTShowcaseCard.jsx";
import IoTDetailModal from "./components/IoTDetailModal.jsx";
import "./IoTPage.css";

const features = [
  {
    label: "Real-time Monitoring",
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M3 17l6-6 4 4 8-8" />
        <path d="M17 7h4v4" />
      </svg>
    ),
  },
  {
    label: "Remote Control",
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <line x1="5" y1="4" x2="5" y2="20" />
        <circle cx="5" cy="9" r="2" />
        <line x1="12" y1="4" x2="12" y2="20" />
        <circle cx="12" cy="15" r="2" />
        <line x1="19" y1="4" x2="19" y2="20" />
        <circle cx="19" cy="7" r="2" />
      </svg>
    ),
  },
  {
    label: "Secure Communication",
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 3l7 3v6c0 4.5-3 7.5-7 9-4-1.5-7-4.5-7-9V6l7-3z" />
        <path d="M9 12l2 2 4-4" />
      </svg>
    ),
  },
  {
    label: "Data-driven Insights",
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <line x1="5" y1="20" x2="5" y2="12" />
        <line x1="12" y1="20" x2="12" y2="7" />
        <line x1="19" y1="20" x2="19" y2="14" />
      </svg>
    ),
  },
];

function LaptopDashboard() {
  return (
    <div className="laptop-overlay">
      <div className="dash-topbar">
        <div className="dash-brand"><span className="b" />MAITHRI</div>
        <div className="dash-dots"><span /><span /><span /></div>
      </div>
      <div className="dash-body">
        <div className="dash-sidebar">
          <span className="active" /><span /><span /><span /><span /><span />
        </div>
        <div className="dash-main">
          <div className="kpi-row">
            <div className="kpi">
              <div className="kpi-label">DEVICES ONLINE</div>
              <div className="kpi-val">248</div>
              <div className="kpi-bar"><i style={{ width: "82%" }} /></div>
            </div>
            <div className="kpi">
              <div className="kpi-label">POWER OUTPUT</div>
              <div className="kpi-val">4.6 kW</div>
              <div className="kpi-bar"><i style={{ width: "64%" }} /></div>
            </div>
            <div className="kpi">
              <div className="kpi-label">UPTIME</div>
              <div className="kpi-val">99.8%</div>
              <div className="kpi-bar"><i style={{ width: "98%" }} /></div>
            </div>
          </div>
          <div className="chart-row">
            <div className="panel">
              <div className="p-title">SYSTEM PERFORMANCE</div>
              <svg className="line-mini" viewBox="0 0 200 50" preserveAspectRatio="none">
                <polyline points="0,38 20,30 40,34 60,20 80,25 100,12 120,18 140,8 160,15 180,6 200,10" fill="none" stroke="#2f6fed" strokeWidth="2" />
                <polyline points="0,38 20,30 40,34 60,20 80,25 100,12 120,18 140,8 160,15 180,6 200,10 200,50 0,50" fill="#2f6fed" opacity="0.08" stroke="none" />
              </svg>
            </div>
            <div className="panel">
              <div className="p-title">ENERGY MIX</div>
              <div className="donut" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function PhoneDashboard() {
  return (
    <div className="phone-overlay">
      <div className="phone-topbar">
        <div className="pt-title">MAITHRI</div>
        <div className="pt-sub">Dashboard</div>
      </div>
      <div className="phone-cards">
        <div className="phone-card"><div className="pc-label">DEVICES ONLINE</div><div className="pc-val">248</div></div>
        <div className="phone-card"><div className="pc-label">POWER OUTPUT</div><div className="pc-val">4.6 kW</div></div>
        <div className="phone-card"><div className="pc-label">UPTIME</div><div className="pc-val">99.8%</div></div>
      </div>
    </div>
  );
}

function CheckIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="9" />
      <path d="M8.5 12.2l2.4 2.4 4.6-5.2" />
    </svg>
  );
}

function ArrowIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
      <path d="M5 12h13" />
      <path d="M13 6l6 6-6 6" />
    </svg>
  );
}

const capabilities = [
  {
    title: "Wide Connectivity",
    description: "Supports Wi-Fi, Ethernet, 4G/5G, LoRa, RS485, CAN & more.",
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 19.5h.01" />
        <path d="M8.5 16.2a5 5 0 0 1 7 0" />
        <path d="M5.2 13a9.5 9.5 0 0 1 13.6 0" />
        <path d="M2 9.8a14 14 0 0 1 20 0" />
      </svg>
    ),
  },
  {
    title: "Edge Intelligence",
    description: "Local data processing, filtering and analytics at the edge.",
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
        <ellipse cx="12" cy="5.5" rx="7.5" ry="2.8" />
        <path d="M4.5 5.5v6c0 1.55 3.36 2.8 7.5 2.8s7.5-1.25 7.5-2.8v-6" />
        <path d="M4.5 11.5v6c0 1.55 3.36 2.8 7.5 2.8s7.5-1.25 7.5-2.8v-6" />
      </svg>
    ),
  },
  {
    title: "Cloud Integration",
    description: "Seamless integration with secure cloud platforms and APIs.",
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
        <path d="M7 18.5a4.5 4.5 0 0 1-.6-8.96A6 6 0 0 1 18 9.6a4 4 0 0 1-1 7.9H7z" />
        <rect x="10.1" y="15.5" width="3.8" height="4.5" rx="1" />
        <path d="M12 15.5v-1" />
      </svg>
    ),
  },
  {
    title: "Smart Alerts",
    description: "Configurable alerts via SMS, email and in-app notifications.",
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
        <path d="M18 16v-5a6 6 0 1 0-12 0v5l-1.5 2.5h15L18 16z" />
        <path d="M9.5 20a2.5 2.5 0 0 0 5 0" />
      </svg>
    ),
  },
  {
    title: "Scalable & Reliable",
    description: "Built to scale with high availability and data redundancy.",
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
        <path d="M4 20V13" />
        <path d="M9.5 20V10" />
        <path d="M15 20V6" />
        <path d="M20 20V3" />
      </svg>
    ),
  },
  {
    title: "Data Security",
    description: "End-to-end encryption, secure authentication and access control.",
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 3l7 3v6c0 4.5-3 7.5-7 9-4-1.5-7-4.5-7-9V6l7-3z" />
        <path d="M9 12l2 2 4-4" />
      </svg>
    ),
  },
];

function Capabilities() {
  return (
    <section className="capabilities">
      <div className="offerings-header">
        <h2>Key Capabilities</h2>
      </div>

      <div className="capabilities-row">
        {capabilities.map((c) => (
          <div className="capability" key={c.title}>
            <div className="capability-icon">{c.icon}</div>
            <h3>{c.title}</h3>
            <p>{c.description}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

function CtaBanner() {
  const navigate = useNavigate();
  return (
    <section className="cta-wrap">
      <div className="cta-banner">
        <div className="cta-dots">
          <span /><span /><span /><span /><span /><span />
        </div>
        <div className="cta-text">
          <h2>Connect. Monitor. Optimize.</h2>
          <p>Leverage the power of IoT to make smarter, faster and data-driven decisions.</p>
        </div>
        <button
          type="button"
          className="cta-btn"
          onClick={() => navigate('/contact#contact-details')}
        >
          TALK TO OUR EXPERTS <ArrowIcon />
        </button>
      </div>
    </section>
  );
}

const NAVBAR_OFFSET = 90;

export default function IoTPage() {
  const [isModalOpen, setModalOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    if (location.hash) {
      const el = document.getElementById(location.hash.slice(1));
      if (el) {
        const top = el.getBoundingClientRect().top + window.scrollY - NAVBAR_OFFSET;
        window.scrollTo({ top, behavior: "smooth" });
        return;
      }
    }
    window.scrollTo(0, 0);
  }, [location.pathname, location.hash]);

  return (
    <div className="iot-page">
      <NavGap />

      <div className="banner">
        <div className="banner-media" style={{ backgroundImage: `url(${bannerImage})` }} aria-hidden="true"></div>

        <div className="content">
          <div className="left">
            <h1 className="title">IoT Solutions</h1>

            <div className="eyebrow-row">
              <div className="eyebrow-text">Intelligent Connectivity. Real-time Control.</div>
            </div>

            <p className="desc">
              Our IoT solutions enable real-time monitoring, remote control and advanced data analytics
              for energy and industrial systems. Built for reliability, security and seamless integration.
            </p>

            <div className="features">
              {features.map((f) => (
                <div className="feature" key={f.label}>
                  <div className="icon-wrap">{f.icon}</div>
                  <div className="label">{f.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div id="iot-showcase">
        <IoTShowcaseCard onExplore={() => setModalOpen(true)} />
      </div>
      <Capabilities />
      <CtaBanner />

      <IoTDetailModal isOpen={isModalOpen} onClose={() => setModalOpen(false)} />
    </div>
  );
}
