import React, { useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import './IoTDetailModal.css';
import heroImage from '../assets/detail/iot-solutions-hero.webp';
import {
  WifiIcon,
  CloseIcon,
  BarChartIcon,
  GearIcon,
  DataAnalyticsIcon,
  BellIcon,
  ShieldCheckIcon,
  NetworkIcon,
  ShieldStarIcon,
  DollarIcon,
  LightbulbIcon,
  BatteryIcon,
  PlugIcon,
  FactoryIcon,
  SolarIcon,
  TruckIcon,
  ShieldHomeIcon,
  HeadsetIcon,
  ArrowIcon,
} from './icons.jsx';

const capabilities = [
  {
    icon: BarChartIcon,
    name: 'Real-time Monitoring',
    description: 'Monitor systems and assets in real time with accurate and reliable data.',
  },
  {
    icon: GearIcon,
    name: 'Remote Control',
    description: 'Remotely control and manage your systems from anywhere.',
  },
  {
    icon: DataAnalyticsIcon,
    name: 'Data Analytics',
    description: 'Data-driven insights and advanced analytics to optimize performance.',
  },
  {
    icon: BellIcon,
    name: 'Alerts & Notifications',
    description: 'Instant alerts and notifications to keep you informed at all times.',
  },
  {
    icon: ShieldCheckIcon,
    name: 'Security & Reliability',
    description: 'Enterprise-grade security and reliable connectivity you can trust.',
  },
  {
    icon: NetworkIcon,
    name: 'Seamless Integration',
    description: 'Easily integrate with your existing systems and third-party platforms.',
  },
];

const benefits = [
  {
    icon: ShieldCheckIcon,
    name: 'Improved Efficiency',
    description: 'Optimize operations and reduce downtime.',
  },
  {
    icon: DollarIcon,
    name: 'Cost Savings',
    description: 'Reduce operational costs and increase ROI.',
  },
  {
    icon: ShieldStarIcon,
    name: 'Enhanced Reliability',
    description: 'Ensure system reliability and business continuity.',
  },
  {
    icon: LightbulbIcon,
    name: 'Actionable Insights',
    description: 'Make smarter decisions with real-time insights.',
  },
];

const industryApplications = [
  {
    icon: BatteryIcon,
    name: 'Energy Storage',
    description: 'Monitor and optimize battery systems for maximum performance.',
  },
  {
    icon: PlugIcon,
    name: 'Power Systems',
    description: 'Real-time monitoring and control of power infrastructure.',
  },
  {
    icon: FactoryIcon,
    name: 'Industrial Automation',
    description: 'Improve operational efficiency with smart IoT applications.',
  },
  {
    icon: SolarIcon,
    name: 'Renewable Energy',
    description: 'Monitor solar, wind and hybrid systems in real time.',
  },
  {
    icon: TruckIcon,
    name: 'Fleet Management',
    description: 'Track, monitor and optimize fleet performance.',
  },
  {
    icon: ShieldHomeIcon,
    name: 'Critical Infrastructure',
    description: 'Ensure reliability and security for critical operations.',
  },
];

function CapabilityItem({ icon: IconCmp, name, description }) {
  return (
    <li className="iotm-list-item">
      <span className="iotm-list-icon">
        <IconCmp />
      </span>
      <div className="iotm-list-text">
        <p className="iotm-list-name">{name}</p>
        <p className="iotm-list-desc">{description}</p>
      </div>
    </li>
  );
}

function ApplicationCell({ icon: IconCmp, name, description }) {
  return (
    <div className="iotm-app-cell">
      <span className="iotm-app-icon">
        <IconCmp />
      </span>
      <p className="iotm-app-name">{name}</p>
      <p className="iotm-app-desc">{description}</p>
    </div>
  );
}

export default function IoTDetailModal({ isOpen, onClose }) {
  const dialogRef = useRef(null);
  const navigate = useNavigate();

  const goToContact = () => {
    onClose();
    navigate('/contact#contact-details');
  };

  useEffect(() => {
    if (!isOpen) return undefined;
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  useEffect(() => {
    if (!isOpen) return undefined;
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = prevOverflow;
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const handleBackdropClick = (e) => {
    if (e.target === e.currentTarget) onClose();
  };

  return (
    <div className="iotm-backdrop" onMouseDown={handleBackdropClick}>
      <div
        className="iotm-dialog"
        role="dialog"
        aria-modal="true"
        aria-labelledby="iotm-title"
        ref={dialogRef}
      >
        <button className="iotm-close" onClick={onClose} aria-label="Close details">
          <CloseIcon />
        </button>

        <div className="iotm-hero">
          <img src={heroImage} alt="IoT Solutions" />
          <span className="iotm-hero-badge">
            <WifiIcon />
          </span>
        </div>

        <div className="iotm-body">
          <h2 className="iotm-title" id="iotm-title">
            IOT Solutions
          </h2>
          <p className="iotm-tagline">Intelligent Systems. Real-time Insights. Smarter Decisions.</p>
          <p className="iotm-description">
            Our IoT solutions connect your systems and assets to provide real-time monitoring, remote
            control and actionable analytics for improved efficiency, reliability and performance.
          </p>

          <div className="iotm-columns">
            <div className="iotm-column">
              <span className="iotm-section-badge">OUR CAPABILITIES</span>
              <ul className="iotm-list">
                {capabilities.map((c) => (
                  <CapabilityItem key={c.name} {...c} />
                ))}
              </ul>
            </div>

            <div className="iotm-column">
              <span className="iotm-section-badge">KEY BENEFITS</span>
              <ul className="iotm-list">
                {benefits.map((b) => (
                  <CapabilityItem key={b.name} {...b} />
                ))}
              </ul>
            </div>
          </div>

          <div className="iotm-applications">
            <span className="iotm-section-badge">INDUSTRY APPLICATIONS</span>
            <div className="iotm-app-grid">
              {industryApplications.map((a) => (
                <ApplicationCell key={a.name} {...a} />
              ))}
            </div>
          </div>

          <div className="iotm-banner">
            <span className="iotm-banner-icon">
              <HeadsetIcon />
            </span>
            <div className="iotm-banner-text">
              <p className="iotm-banner-title">Ready to transform your operations with IoT?</p>
              <p className="iotm-banner-subtitle">
                Connect your systems, gain real-time insights and drive your business forward.
              </p>
            </div>
            <button className="iotm-banner-cta" onClick={goToContact}>
              Contact Us
              <ArrowIcon />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
