import React from 'react';

const base = {
  viewBox: '0 0 24 24',
  fill: 'none',
  stroke: 'currentColor',
  strokeWidth: 1.7,
  strokeLinecap: 'round',
  strokeLinejoin: 'round',
};

export const WifiIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M5 12.5a10 10 0 0 1 14 0" />
    <path d="M8 15.8a6 6 0 0 1 8 0" />
    <path d="M11 19h.01" />
  </svg>
);

export const BarChartIcon = (p) => (
  <svg {...base} {...p}>
    <line x1="6" y1="20" x2="6" y2="12" />
    <line x1="12" y1="20" x2="12" y2="6" />
    <line x1="18" y1="20" x2="18" y2="15" />
  </svg>
);

export const GearIcon = (p) => (
  <svg {...base} {...p}>
    <circle cx="12" cy="12" r="3" />
    <path d="M19.4 13.5c.06-.5.1-1 .1-1.5s-.04-1-.1-1.5l2.1-1.6-2-3.5-2.5 1a7.6 7.6 0 0 0-2.6-1.5L14 2h-4l-.4 2.9c-.95.35-1.83.86-2.6 1.5l-2.5-1-2 3.5 2.1 1.6c-.06.5-.1 1-.1 1.5s.04 1 .1 1.5L2.5 15l2 3.5 2.5-1c.77.64 1.65 1.15 2.6 1.5L10 22h4l.4-2.9c.95-.35 1.83-.86 2.6-1.5l2.5 1 2-3.5-2.1-1.6z" />
  </svg>
);

export const DataAnalyticsIcon = (p) => (
  <svg {...base} {...p}>
    <circle cx="6" cy="17" r="1.6" />
    <circle cx="12" cy="10" r="1.6" />
    <circle cx="18" cy="14" r="1.6" />
    <path d="M7.3 15.8L10.7 11.2M13.3 11.2L16.7 12.9" />
  </svg>
);

export const BellIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M18 16v-5a6 6 0 1 0-12 0v5l-1.5 2.5h15L18 16z" />
    <path d="M9.5 20a2.5 2.5 0 0 0 5 0" />
  </svg>
);

export const ShieldCheckIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6l7-3z" />
    <path d="M9 12l2 2 4-4" />
  </svg>
);

export const NetworkIcon = (p) => (
  <svg {...base} {...p}>
    <circle cx="5" cy="6" r="2" />
    <circle cx="19" cy="6" r="2" />
    <circle cx="5" cy="18" r="2" />
    <circle cx="12" cy="12" r="2" />
    <path d="M6.7 7.2L10.5 10.7M17.3 7.2L13.5 10.7M6.7 16.8L10.5 13.3" />
  </svg>
);

export const ShieldStarIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M12 2l8 3v6c0 5-3.5 8.5-8 11-4.5-2.5-8-6-8-11V5l8-3z" />
    <path d="M12 7.5l1 2.2 2.4.2-1.8 1.6.6 2.3-2.2-1.3-2.2 1.3.6-2.3-1.8-1.6 2.4-.2z" />
  </svg>
);

export const DollarIcon = (p) => (
  <svg {...base} {...p}>
    <circle cx="12" cy="12" r="9" />
    <path d="M12 7v10M14.5 9.3c0-1-1-1.8-2.5-1.8s-2.5.9-2.5 2 1 1.6 2.5 1.9 2.5.9 2.5 2-1 2-2.5 2-2.5-.8-2.5-1.8" />
  </svg>
);

export const LightbulbIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M9 18h6M10 21h4" />
    <path d="M12 3a6 6 0 0 0-3.5 10.9c.6.45 1 1.15 1 1.9v.2h5v-.2c0-.75.4-1.45 1-1.9A6 6 0 0 0 12 3z" />
  </svg>
);

export const BatteryIcon = (p) => (
  <svg {...base} {...p}>
    <rect x="2" y="7" width="17" height="10" rx="1.5" />
    <line x1="21" y1="10" x2="21" y2="14" />
    <line x1="6" y1="10" x2="6" y2="14" />
  </svg>
);

export const PlugIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M9 2v4M15 2v4" />
    <path d="M6 6h12v4a6 6 0 0 1-12 0V6z" />
    <path d="M12 16v3" />
    <path d="M9 21h6" />
  </svg>
);

export const FactoryIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M3 21V10l5 3.5V10l5 3.5V10l5 3.5V21H3z" />
    <path d="M7 21v-4M12 21v-4M17 21v-4" />
  </svg>
);

export const SolarIcon = (p) => (
  <svg {...base} {...p}>
    <circle cx="12" cy="7" r="2.5" />
    <path d="M12 1.5v1.3M12 12.2v1.3M6.3 7h1.3M16.4 7h1.3M8.2 3.2l.9.9M14.9 3.2l-.9.9" />
    <path d="M4 21l3-8h10l3 8H4z" />
  </svg>
);

export const TruckIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M3 7h11v9H3z" />
    <path d="M14 11h4l3 3v2h-7z" />
    <circle cx="7.5" cy="18" r="1.6" />
    <circle cx="17.5" cy="18" r="1.6" />
  </svg>
);

export const ShieldHomeIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M12 2l8 3v6c0 5-3.5 8.5-8 11-4.5-2.5-8-6-8-11V5l8-3z" />
    <path d="M9 13.5l3-2.3 3 2.3V16h-6z" />
  </svg>
);

export const HeadsetIcon = (p) => (
  <svg {...base} {...p}>
    <path d="M4 13a8 8 0 0 1 16 0" />
    <rect x="3" y="13" width="4" height="6" rx="1.4" />
    <rect x="17" y="13" width="4" height="6" rx="1.4" />
    <path d="M20 19v1a3 3 0 0 1-3 3h-4" />
  </svg>
);

export const ArrowIcon = (p) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" {...p}>
    <path d="M5 12h13" />
    <path d="M13 6l6 6-6 6" />
  </svg>
);

export const CloseIcon = (p) => (
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...p}>
    <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
  </svg>
);
