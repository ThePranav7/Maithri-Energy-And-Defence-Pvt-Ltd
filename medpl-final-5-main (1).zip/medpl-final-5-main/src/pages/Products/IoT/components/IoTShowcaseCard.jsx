import React from 'react';
import './IoTShowcaseCard.css';
import heroImage from '../assets/detail/iot-solutions-hero.webp';
import {
  WifiIcon,
  BarChartIcon,
  GearIcon,
  DataAnalyticsIcon,
  ShieldCheckIcon,
  ArrowIcon,
} from './icons.jsx';

const features = [
  {
    icon: BarChartIcon,
    title: 'Real-time Monitoring',
    description: 'Monitor systems and assets in real time with accurate and reliable data.',
  },
  {
    icon: GearIcon,
    title: 'Remote Control',
    description: 'Remotely control and manage your systems from anywhere.',
  },
  {
    icon: DataAnalyticsIcon,
    title: 'Data Analytics',
    description: 'Data-driven insights and analytics to optimize performance.',
  },
  {
    icon: ShieldCheckIcon,
    title: 'Secure & Reliable',
    description: 'Enterprise-grade security and reliable connectivity you can trust.',
  },
];

export default function IoTShowcaseCard({ onExplore }) {
  return (
    <section className="iot-showcase">
      <div className="offerings-header iot-showcase-heading">
        <h2>Our IoT Offerings</h2>
      </div>

      <div className="iot-showcase-card">
        <div className="iot-showcase-media">
          <img src={heroImage} alt="Maithri IoT systems in an industrial facility" />
          <span className="iot-showcase-badge">
            <WifiIcon />
          </span>
        </div>

        <div className="iot-showcase-body">
          <h2 className="iot-showcase-title">IOT</h2>
          <p className="iot-showcase-tagline">
            Intelligent Systems. Real-time Insights. Smarter Decisions.
          </p>
          <p className="iot-showcase-desc">
            Our IoT solutions connect your systems and assets to provide real-time monitoring, remote
            control and actionable analytics for improved efficiency, reliability and performance.
          </p>

          <div className="iot-showcase-features">
            {features.map((f) => (
              <div className="iot-showcase-feature" key={f.title}>
                <span className="iot-showcase-feature-icon">
                  <f.icon />
                </span>
                <div className="iot-showcase-feature-text">
                  <p className="iot-showcase-feature-title">{f.title}</p>
                  <p className="iot-showcase-feature-desc">{f.description}</p>
                </div>
              </div>
            ))}
          </div>

          <button type="button" className="iot-showcase-cta" onClick={onExplore}>
            EXPLORE IOT SOLUTIONS <ArrowIcon />
          </button>
        </div>
      </div>
    </section>
  );
}
