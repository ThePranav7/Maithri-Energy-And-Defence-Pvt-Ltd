import React from "react";
import { useNavigate, useLocation } from "react-router-dom";
import "./CareersHero.css";
import heroBg from "../../assets/careers-hero-bg-clean.webp";

const NAVBAR_OFFSET = 90;

/**
 * CareersHero
 * Full-width hero banner used at the top of the Careers page.
 * Shows a breadcrumb trail, headline, supporting copy, and a primary CTA
 * over a background photo with a navy gradient scrim for text contrast.
 */
const CareersHero = ({
  title = "Build the Future With Purpose",
  description = "Join a team that is powering innovation in energy, defense and IoT solutions that make a real impact on the world.",
  buttonText = "Explore Opportunities",
  buttonHref = "#open-positions",
  bgImage = heroBg,
}) => {
  const navigate = useNavigate();
  const location = useLocation();

  const handleClick = (e) => {
    e.preventDefault();
    const hash = buttonHref.startsWith("#") ? buttonHref.slice(1) : buttonHref;
    const el = document.getElementById(hash);
    if (el) {
      const top = el.getBoundingClientRect().top + window.scrollY - NAVBAR_OFFSET;
      window.scrollTo({ top, behavior: "smooth" });
    } else {
      navigate(`${location.pathname}#${hash}`);
    }
  };

  return (
    <section className="careers-hero">
      <div
        className="careers-hero__photo"
        style={{ backgroundImage: `url(${bgImage})` }}
      >
        <div className="careers-hero__seam" />
      </div>

      <div className="careers-hero__inner">
        <h1 className="careers-hero__title">{title}</h1>

        <p className="careers-hero__description">{description}</p>

        <a className="careers-hero__cta" href={buttonHref} onClick={handleClick}>
          {buttonText.toUpperCase()}
          <span className="careers-hero__cta-icon" aria-hidden="true">
            →
          </span>
        </a>
      </div>
    </section>
  );
};

export default CareersHero;
