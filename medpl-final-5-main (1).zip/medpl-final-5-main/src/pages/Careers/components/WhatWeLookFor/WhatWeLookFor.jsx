import React from "react";
import "./WhatWeLookFor.css";

/**
 * WhatWeLookFor
 * "What We Look For" panel — a heading over a strip of trait icons.
 */

const ICONS = {
  gear: (
    <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="24" cy="24" r="7" stroke="currentColor" strokeWidth="2" />
      <path
        d="M24 6v5M24 37v5M42 24h-5M11 24H6M36.5 11.5l-3.5 3.5M15 29.5 11.5 33M36.5 36.5 33 33M15 18.5 11.5 15"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
      />
    </svg>
  ),
  puzzle: (
    <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M18 8h8v4.5a3 3 0 0 0 5.5 1.7 3 3 0 1 1 0 5.6A3 3 0 0 0 26 22.5V27h4.5a3 3 0 1 1 0 8 3 3 0 0 0-3-3 3 3 0 0 0-3 3H18v-8h-4.5a3 3 0 1 1 0-8H18V8Z"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinejoin="round"
      />
    </svg>
  ),
  ownership: (
    <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="24" cy="16" r="7" stroke="currentColor" strokeWidth="2" />
      <path d="M10 40c1.5-8 6.8-13 14-13s12.5 5 14 13" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <path d="M32 12l3 3 5-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
  team: (
    <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="16" cy="16" r="5.5" stroke="currentColor" strokeWidth="2" />
      <circle cx="32" cy="16" r="5.5" stroke="currentColor" strokeWidth="2" />
      <path d="M5 39c0-7 4.9-11.5 11-11.5S27 32 27 39" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <path d="M21 39c0-7 4.9-11.5 11-11.5S43 32 43 39" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  ),
  book: (
    <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M24 12c-3-3-8-4-14-3v25c6-1 11 0 14 3 3-3 8-4 14-3V9c-6-1-11 0-14 3Z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
      <path d="M24 12v25" stroke="currentColor" strokeWidth="2" />
    </svg>
  ),
  shield: (
    <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M24 5 8 11v11c0 10 6.8 17.7 16 21 9.2-3.3 16-11 16-21V11L24 5Z"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinejoin="round"
      />
      <path d="M17 24l5 5 9-10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
};

const DEFAULT_TRAITS = [
  { icon: "gear", label: "Passion for Technology" },
  { icon: "puzzle", label: "Problem Solver" },
  { icon: "ownership", label: "Ownership Mindset" },
  { icon: "team", label: "Team Player" },
  { icon: "book", label: "Continuous Learner" },
  { icon: "shield", label: "Ethical & Reliable" },
];

const WhatWeLookFor = ({ title = "What We Look For", traits = DEFAULT_TRAITS }) => {
  return (
    <section className="what-we-look-for">
      <div className="what-we-look-for__inner">
        <div className="what-we-look-for__panel">
          <h2 className="what-we-look-for__title">{title}</h2>

          <div className="what-we-look-for__grid">
            {traits.map((trait) => (
              <div className="what-we-look-for__item" key={trait.label} tabIndex={0}>
                <div className="what-we-look-for__icon">{ICONS[trait.icon]}</div>
                <p className="what-we-look-for__label">{trait.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default WhatWeLookFor;
