import React, { useEffect, useMemo, useRef, useState } from "react";
import emailjs from "@emailjs/browser";
import "./ApplicationModal.css";

/**
 * ApplicationModal
 * Job-application form shown in a modal dialog. Opened from "Apply Now"
 * on a job card (with a job title in context) or from "Send Your
 * Resume" in the CTA banner (general / speculative application).
 *
 * Submission is sent via EmailJS directly to the careers inbox.
 */

// EmailJS credentials for the careers application form
const EMAILJS_SERVICE_ID = "service_opfjeym";
const EMAILJS_TEMPLATE_ID = "template_kt0j8eb";
const EMAILJS_PUBLIC_KEY = "cUj4mGTeSMqORRJ9S";

const AREA_OPTIONS = ["Industrial", "Defense", "IoT", "Other"];
const ACCEPTED_RESUME_TYPES = ".pdf,.doc,.docx";
const MAX_RESUME_SIZE_BYTES = 5 * 1024 * 1024; // 5MB

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PHONE_RE = /^[0-9+\-\s()]{7,20}$/;

function makeCaptcha() {
  const a = Math.floor(Math.random() * 8) + 2; // 2-9
  const b = Math.floor(Math.random() * 8) + 2; // 2-9
  return { a, b, answer: a + b };
}

const CloseIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

const UploadIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <path d="M12 16V4M12 4l-4 4M12 4l4 4" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    <path d="M4 16v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
  </svg>
);

const CheckIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="1.8" />
    <path d="M8 12.5l2.5 2.5L16 9.5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const FIELD_ORDER = ["fullName", "email", "phone", "areaOfInterest", "resume", "captcha"];
const FIELD_ELEMENT_ID = {
  fullName: "af-name",
  email: "af-email",
  phone: "af-phone",
  areaOfInterest: "af-area",
  resume: "af-resume-btn",
  captcha: "af-captcha",
};

const initialFields = {
  fullName: "",
  email: "",
  phone: "",
  areaOfInterest: "",
  coverMessage: "",
  captchaInput: "",
};

const ApplicationModal = ({ isOpen, onClose, jobTitle }) => {
  const [fields, setFields] = useState(initialFields);
  const [resumeFile, setResumeFile] = useState(null);
  const [errors, setErrors] = useState({});
  const [captcha, setCaptcha] = useState(makeCaptcha);
  // status: 'idle' | 'sending' | 'success' | 'error'
  const [status, setStatus] = useState("idle");
  const dialogRef = useRef(null);
  const fileInputRef = useRef(null);
  const formRef = useRef(null);

  const isGeneral = !jobTitle;
  const submitted = status === "success";

  // Reset the form each time the modal is freshly opened.
  useEffect(() => {
    if (isOpen) {
      setFields(initialFields);
      setResumeFile(null);
      setErrors({});
      setCaptcha(makeCaptcha());
      setStatus("idle");
    }
  }, [isOpen]);

  // Close on Escape key.
  useEffect(() => {
    if (!isOpen) return undefined;
    const handleKeyDown = (e) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, onClose]);

  // Lock page scroll while the modal is open.
  useEffect(() => {
    if (!isOpen) return undefined;
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prevOverflow;
    };
  }, [isOpen]);

  const heading = useMemo(
    () => (isGeneral ? "Send Your Resume" : `Apply for ${jobTitle}`),
    [isGeneral, jobTitle]
  );

  if (!isOpen) return null;

  const handleField = (key) => (e) => {
    const { value } = e.target;
    setFields((f) => ({ ...f, [key]: value }));
    setErrors((er) => (er[key] ? { ...er, [key]: undefined } : er));
  };

  const handleFile = (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) {
      setResumeFile(null);
      return;
    }
    const validExt = /\.(pdf|doc|docx)$/i.test(file.name);
    if (!validExt) {
      setErrors((er) => ({ ...er, resume: "Please upload a .pdf, .doc, or .docx file." }));
      setResumeFile(null);
      e.target.value = "";
      return;
    }
    if (file.size > MAX_RESUME_SIZE_BYTES) {
      setErrors((er) => ({ ...er, resume: "File is too large — please upload a resume under 5MB." }));
      setResumeFile(null);
      e.target.value = "";
      return;
    }
    setErrors((er) => ({ ...er, resume: undefined }));
    setResumeFile(file);
  };

  const validate = () => {
    const next = {};
    if (!fields.fullName.trim()) next.fullName = "Full name is required.";
    if (!fields.email.trim()) next.email = "Email address is required.";
    else if (!EMAIL_RE.test(fields.email.trim())) next.email = "Enter a valid email address.";
    if (!fields.phone.trim()) next.phone = "Phone number is required.";
    else if (!PHONE_RE.test(fields.phone.trim())) next.phone = "Enter a valid phone number.";
    if (!fields.areaOfInterest) next.areaOfInterest = "Please select an area of interest.";
    if (!resumeFile) next.resume = "Please upload your resume.";
    else if (resumeFile.size > MAX_RESUME_SIZE_BYTES) next.resume = "File is too large — please upload a resume under 5MB.";
    if (!fields.captchaInput.trim()) next.captcha = "Please answer the verification question.";
    else if (Number(fields.captchaInput.trim()) !== captcha.answer) next.captcha = "That answer isn't correct.";
    return next;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const nextErrors = validate();
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) {
      const firstKey = FIELD_ORDER.find((key) => nextErrors[key]);
      const elId = firstKey && FIELD_ELEMENT_ID[firstKey];
      const el = elId && document.getElementById(elId);
      if (el && el.scrollIntoView) {
        el.scrollIntoView({ behavior: "smooth", block: "center" });
        if (typeof el.focus === "function") el.focus({ preventScroll: true });
      }
      return;
    }
    if (!formRef.current) return;

    setStatus("sending");

    emailjs
      .sendForm(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, formRef.current, {
        publicKey: EMAILJS_PUBLIC_KEY,
      })
      .then(() => {
        setStatus("success");
      })
      .catch((error) => {
        console.error("EmailJS send failed:", error);
        setStatus("error");
      });
  };

  const handleBackdropClick = (e) => {
    if (e.target === e.currentTarget) onClose();
  };

  return (
    <div className="application-modal__backdrop" onMouseDown={handleBackdropClick}>
      <div
        className="application-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="application-modal-title"
        ref={dialogRef}
      >
        <button className="application-modal__close" onClick={onClose} aria-label="Close application form">
          <CloseIcon />
        </button>

        {submitted ? (
          <div className="application-modal__success">
            <div className="application-modal__success-icon">
              <CheckIcon />
            </div>
            <h2>Application Sent</h2>
            <p>
              Thanks{fields.fullName ? `, ${fields.fullName.trim()}` : ""} — we've received your application
              {isGeneral ? "" : ` for ${jobTitle}`}. Our team will be in touch if there's a match.
            </p>
            <button className="application-modal__submit" onClick={onClose}>
              Done
            </button>
          </div>
        ) : (
          <>
            <h2 className="application-modal__title" id="application-modal-title">
              {heading}
            </h2>
            <p className="application-modal__subtitle">
              {isGeneral
                ? "Share your profile with us — we're always looking for great talent."
                : "Fill in your details below and we'll get back to you."}
            </p>

            <form className="application-modal__form" ref={formRef} onSubmit={handleSubmit} noValidate>
              {/* Hidden context fields sent along with the form to EmailJS */}
              <input type="hidden" name="position" value={isGeneral ? "General Application" : jobTitle} />
              <input type="hidden" name="title" value={isGeneral ? "General Application" : `Apply for ${jobTitle}`} />

              <div className="application-modal__field">
                <label htmlFor="af-name">Full Name</label>
                <input
                  id="af-name"
                  name="fullName"
                  type="text"
                  value={fields.fullName}
                  onChange={handleField("fullName")}
                  placeholder="Jane Doe"
                  aria-invalid={!!errors.fullName}
                />
                {errors.fullName && <span className="application-modal__error">{errors.fullName}</span>}
              </div>

              <div className="application-modal__row">
                <div className="application-modal__field">
                  <label htmlFor="af-email">Email Address</label>
                  <input
                    id="af-email"
                    name="email"
                    type="email"
                    value={fields.email}
                    onChange={handleField("email")}
                    placeholder="jane@example.com"
                    aria-invalid={!!errors.email}
                  />
                  {errors.email && <span className="application-modal__error">{errors.email}</span>}
                </div>

                <div className="application-modal__field">
                  <label htmlFor="af-phone">Phone Number</label>
                  <input
                    id="af-phone"
                    name="phone"
                    type="tel"
                    value={fields.phone}
                    onChange={handleField("phone")}
                    placeholder="+91 98765 43210"
                    aria-invalid={!!errors.phone}
                  />
                  {errors.phone && <span className="application-modal__error">{errors.phone}</span>}
                </div>
              </div>

              <div className="application-modal__field">
                <label htmlFor="af-area">Area of Interest</label>
                <select
                  id="af-area"
                  name="areaOfInterest"
                  value={fields.areaOfInterest}
                  onChange={handleField("areaOfInterest")}
                  aria-invalid={!!errors.areaOfInterest}
                >
                  <option value="" disabled>
                    Select an area
                  </option>
                  {AREA_OPTIONS.map((opt) => (
                    <option key={opt} value={opt}>
                      {opt}
                    </option>
                  ))}
                </select>
                {errors.areaOfInterest && (
                  <span className="application-modal__error">{errors.areaOfInterest}</span>
                )}
              </div>

              <div className="application-modal__field">
                <label htmlFor="af-resume">Resume Upload (under 5MB)</label>
                <div className="application-modal__upload">
                  <button
                    type="button"
                    id="af-resume-btn"
                    className="application-modal__upload-btn"
                    onClick={() => fileInputRef.current && fileInputRef.current.click()}
                  >
                    <UploadIcon />
                    {resumeFile ? "Replace File" : "Choose File"}
                  </button>
                  <span className="application-modal__upload-name">
                    {resumeFile ? resumeFile.name : "No file selected"}
                  </span>
                  <input
                    id="af-resume"
                    name="resume"
                    ref={fileInputRef}
                    type="file"
                    accept={ACCEPTED_RESUME_TYPES}
                    onChange={handleFile}
                    hidden
                  />
                </div>
                <span className="application-modal__hint">Accepted formats: .pdf, .doc, .docx — max size 5MB</span>
                {errors.resume && <span className="application-modal__error">{errors.resume}</span>}
              </div>

              <div className="application-modal__field">
                <label htmlFor="af-message">Cover Message (optional)</label>
                <textarea
                  id="af-message"
                  name="message"
                  rows={4}
                  value={fields.coverMessage}
                  onChange={handleField("coverMessage")}
                  placeholder="Tell us a little about yourself..."
                />
              </div>

              <div className="application-modal__field">
                <label htmlFor="af-captcha">Verification: What is {captcha.a} + {captcha.b}?</label>
                <div className="application-modal__captcha-row">
                  <input
                    id="af-captcha"
                    type="text"
                    inputMode="numeric"
                    value={fields.captchaInput}
                    onChange={handleField("captchaInput")}
                    placeholder="Your answer"
                    aria-invalid={!!errors.captcha}
                  />
                  <button
                    type="button"
                    className="application-modal__captcha-refresh"
                    onClick={() => setCaptcha(makeCaptcha())}
                    aria-label="Get a new verification question"
                    title="Get a new question"
                  >
                    ↻
                  </button>
                </div>
                {errors.captcha && <span className="application-modal__error">{errors.captcha}</span>}
              </div>

              <button type="submit" className="application-modal__submit" disabled={status === "sending"}>
                {status === "sending" ? "Sending..." : "Send My Application"}
              </button>

              {status === "error" && (
                <p className="application-modal__error application-modal__status" role="alert">
                  Sorry, something went wrong while sending your application. Please try again or reach us directly.
                </p>
              )}
            </form>
          </>
        )}
      </div>
    </div>
  );
};

export default ApplicationModal;
