import React from "react";
import "./OpenPositions.css";

/**
 * OpenPositions
 * "Open Positions" section — a list of job cards.
 */

const ICONS = {
  embedded: (
    <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="14" y="14" width="20" height="20" rx="2" stroke="currentColor" strokeWidth="2" />
      <rect x="20" y="20" width="8" height="8" rx="1" stroke="currentColor" strokeWidth="2" />
      <path
        d="M20 6v6M28 6v6M20 36v6M28 36v6M6 20h6M6 28h6M36 20h6M36 28h6"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
      />
    </svg>
  ),
  hardware: (
    <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="8" y="10" width="32" height="22" rx="2" stroke="currentColor" strokeWidth="2" />
      <path d="M8 26h32" stroke="currentColor" strokeWidth="2" />
      <circle cx="16" cy="18" r="2" stroke="currentColor" strokeWidth="2" />
      <path d="M22 15h12M22 21h8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <path d="M16 32v6M32 32v6M12 42h24" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  ),
  iot: (
    <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M10 30l6-16 6 16M13 24h6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M26 30V14h6a5 5 0 0 1 0 10h-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
  qa: (
    <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M24 5 8 11v11c0 10 6.8 17.7 16 21 9.2-3.3 16-11 16-21V11L24 5Z"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinejoin="round"
      />
      <path d="M17 24l5 5 9-10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
};

const DEFAULT_JOBS = [
  {
    id: "embedded-sw-engineer",
    icon: "embedded",
    title: "Embedded Software Engineer",
    department: "Engineering",
    location: "Hyderabad, India",
    type: "Full-time",
    description: "Design, develop and test embedded software for energy, defense and IoT products.",
    experience: "2-5 Years Experience",
    applyHref: "#",
  },
  {
    id: "hardware-design-engineer",
    icon: "hardware",
    title: "Hardware Design Engineer",
    department: "Engineering",
    location: "Hyderabad, India",
    type: "Full-time",
    description: "Design and develop high-performance hardware for power electronics and embedded systems.",
    experience: "2-5 Years Experience",
    applyHref: "#",
  },
  {
    id: "qa-engineer",
    icon: "qa",
    title: "Quality Assurance Engineer",
    department: "Quality",
    location: "Hyderabad, India",
    type: "Full-time",
    description: "Ensure product quality through testing, validation and compliance.",
    experience: "1-3 Years Experience",
    applyHref: "#",
  },
];

const CalendarIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <rect x="3" y="5" width="18" height="16" rx="2" stroke="currentColor" strokeWidth="1.6" />
    <path d="M3 9.5h18" stroke="currentColor" strokeWidth="1.6" />
    <path d="M8 3v4M16 3v4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
  </svg>
);

const ArrowIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <path d="M5 12h14M13 6l6 6-6 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const OpenPositions = ({ title = "Open Positions", jobs = DEFAULT_JOBS, onApply }) => {
  return (
    <section className="open-positions" id="open-positions">
      <div className="open-positions__inner">
        <h2 className="open-positions__title">{title}</h2>

        <div className="open-positions__list">
          {jobs.length === 0 ? (
            <p className="open-positions__empty">No open roles right now. Please check back soon.</p>
          ) : (
            jobs.map((job) => (
              <div className="open-positions__card" key={job.id}>
                <div className="open-positions__icon">{ICONS[job.icon]}</div>

                <div className="open-positions__info">
                  <h3 className="open-positions__job-title">{job.title}</h3>
                  <p className="open-positions__meta">
                    {job.department} &bull; {job.location} &bull; {job.type}
                  </p>
                </div>

                <p className="open-positions__desc">{job.description}</p>

                <div className="open-positions__experience">
                  <span className="open-positions__cal-icon" aria-hidden="true">
                    <CalendarIcon />
                  </span>
                  {job.experience}
                </div>

                <button
                  type="button"
                  className="open-positions__apply"
                  onClick={() => onApply && onApply(job.title)}
                >
                  APPLY NOW
                  <span className="open-positions__apply-icon" aria-hidden="true">
                    <ArrowIcon />
                  </span>
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </section>
  );
};

export default OpenPositions;
