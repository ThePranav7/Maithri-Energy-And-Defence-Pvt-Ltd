import React from "react";
import "./ResumeCTA.css";

/**
 * ResumeCTA
 * "Don't see the right role?" navy banner encouraging speculative
 * resume submissions, with a paper-plane icon and a primary CTA.
 */

const PlaneIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <path
      d="M21 3 3 10.5l7 2.5M21 3 13.5 21l-3.5-8M21 3 10 13.5"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

const ArrowIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <path d="M5 12h14M13 6l6 6-6 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const ResumeCTA = ({
  title = "Don't see the right role?",
  description = "Share your profile with us. We're always looking for great talent.",
  buttonText = "Send Your Resume",
  onApply,
}) => {
  return (
    <section className="resume-cta">
      <div className="resume-cta__inner">
        <div className="resume-cta__left">
          <span className="resume-cta__icon" aria-hidden="true">
            <PlaneIcon />
          </span>
          <div className="resume-cta__text">
            <h2 className="resume-cta__title">{title}</h2>
            <p className="resume-cta__desc">{description}</p>
          </div>
        </div>

        <button type="button" className="resume-cta__button" onClick={() => onApply && onApply(null)}>
          {buttonText.toUpperCase()}
          <span className="resume-cta__button-icon" aria-hidden="true">
            <ArrowIcon />
          </span>
        </button>
      </div>
    </section>
  );
};

export default ResumeCTA;
