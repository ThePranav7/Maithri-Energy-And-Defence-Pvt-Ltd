import React from "react";
import "./CareerValues.css";

/**
 * CareerValues
 * "Why Build Your Career With Us" section — a row of value cards,
 * each with an icon, title, and short description. Cards lift and
 * highlight on hover.
 */

const ICONS = {
  bulb: (
    <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M24 6a13 13 0 0 0-7 24c1.4 1 2 2.3 2 3.8V36h10v-2.2c0-1.5.6-2.8 2-3.8a13 13 0 0 0-7-24Z"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinejoin="round"
      />
      <path d="M20 40h8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <path d="M21 44h6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <path d="M24 6V3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  ),
  growth: (
    <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M8 38V26" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <path d="M18 38V18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <path d="M28 38V22" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <path d="M38 38V10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <path
        d="M8 20 18 12l10 6 12-12"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path d="M32 6h8v8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
  collab: (
    <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="17" cy="14" r="5" stroke="currentColor" strokeWidth="2" />
      <circle cx="31" cy="14" r="5" stroke="currentColor" strokeWidth="2" />
      <path
        d="M6 38c0-6.6 4.9-11 11-11s11 4.4 11 11"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
      />
      <path
        d="M20 38c0-6.6 4.9-11 11-11s11 4.4 11 11"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
      />
    </svg>
  ),
  shield: (
    <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M24 5 8 11v11c0 10 6.8 17.7 16 21 9.2-3.3 16-11 16-21V11L24 5Z"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinejoin="round"
      />
      <path
        d="M17 24l5 5 9-10"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  ),
  medal: (
    <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="24" cy="28" r="12" stroke="currentColor" strokeWidth="2" />
      <path d="M24 21v14" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <path d="M18 25l6-4 6 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M17 6l4 10M31 6l-4 10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  ),
  heart: (
    <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M24 40S8 30.4 8 19.5C8 13.7 12.5 9 18 9c2.7 0 5.2 1.3 6.9 3.4"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
      />
      <path
        d="M24 40s16-9.6 16-20.5C40 13.7 35.5 9 30 9c-2.4 0-4.6 1-6.3 2.6"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
      />
      <path d="M4 34c3 3 6.5 4 10 3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <path d="M44 34c-3 3-6.5 4-10 3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  ),
};

const DEFAULT_VALUES = [
  {
    icon: "bulb",
    title: "Meaningful Impact",
    description: "Work on technologies that power industries and protect lives.",
  },
  {
    icon: "growth",
    title: "Growth & Learning",
    description: "Continuous learning opportunities and career advancement.",
  },
  {
    icon: "collab",
    title: "Collaborative Culture",
    description: "Work with passionate experts in a collaborative and inclusive environment.",
  },
  {
    icon: "shield",
    title: "Innovation Driven",
    description: "Encouraging new ideas and innovative solutions to complex challenges.",
  },
  {
    icon: "medal",
    title: "Recognition",
    description: "Performance is recognized and rewarded at every level.",
  },
  {
    icon: "heart",
    title: "Well-being First",
    description: "Employee well-being, work-life balance and a safe workplace.",
  },
];

const CareerValues = ({ title = "Why Build Your Career With Us", values = DEFAULT_VALUES }) => {
  return (
    <section className="career-values">
      <div className="career-values__inner">
        <h2 className="career-values__title">{title}</h2>

        <div className="career-values__grid">
          {values.map((item) => (
            <div className="career-values__card" key={item.title} tabIndex={0}>
              <div className="career-values__icon">{ICONS[item.icon]}</div>
              <h3 className="career-values__card-title">{item.title}</h3>
              <p className="career-values__card-desc">{item.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CareerValues;
