import { useEffect, useState } from 'react'
import NavGap from '../../components/Layout/NavGap.jsx'
import CareersHero from './components/CareersHero'
import CareerValues from './components/CareerValues'
import OpenPositions from './components/OpenPositions'
import WhatWeLookFor from './components/WhatWeLookFor'
import ResumeCTA from './components/ResumeCTA'
import ApplicationModal from './components/ApplicationModal'
import './CareersPage.css'

export default function CareersPage() {
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  const [modalOpen, setModalOpen] = useState(false)
  const [selectedJobTitle, setSelectedJobTitle] = useState(null)

  const openApplicationForm = (jobTitle = null) => {
    setSelectedJobTitle(jobTitle)
    setModalOpen(true)
  }

  const closeApplicationForm = () => {
    setModalOpen(false)
  }

  return (
    <div className="careers-page">
      <NavGap />
      <CareersHero />
      <CareerValues />
      <OpenPositions onApply={openApplicationForm} />
      <WhatWeLookFor />
      <ResumeCTA onApply={openApplicationForm} />
      <ApplicationModal
        isOpen={modalOpen}
        onClose={closeApplicationForm}
        jobTitle={selectedJobTitle}
      />
    </div>
  )
}
