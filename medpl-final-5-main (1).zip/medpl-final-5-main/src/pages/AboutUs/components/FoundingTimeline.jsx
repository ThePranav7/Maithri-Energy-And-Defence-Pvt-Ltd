import { useState } from 'react'
import './FoundingTimeline.css'

const ERAS = [
  {
    range: '2015',
    heading: 'Founded on Battery Management Systems',
    bullets: [
      'MEDPL began with one of the earliest indigenous BMS solutions in the segment.',
    ],
  },
  {
    range: '2018–2019',
    heading: 'R&D Expansion',
    bullets: [
      'Delivered a 256-cell BMS and defense battery platform (2018)',
      'Began a three-year Lithium battery pack partnership with HBL (2019)',
    ],
  },
  {
    range: '2020–2022',
    heading: 'Product Diversification',
    bullets: [
      'Supplied a ventilator battery to HBL during the pandemic (2020)',
      'Delivered a high-altitude solar lighting Li-ion battery alongside an L3 EV scale-up (2022)',
    ],
  },
  {
    range: '2025–2026',
    heading: 'Multi-Domain Technology Partner',
    bullets: [
      "Delivered Li-ion batteries for the world's first off-grid AWG and for DRDO's underwater vehicle (2025)",
      "Delivered India's first indigenous Sodium-ion battery prototype, supplied to NSTL, DRDO (2026)",
    ],
  },
]

function ImagePlaceholder({ big }) {
  return (
    <div className={`img-placeholder ${big ? 'img-placeholder--big' : 'img-placeholder--small'}`}>
      <svg viewBox="0 0 24 24" className="img-placeholder-icon">
        <rect x="3" y="5" width="18" height="14" rx="2" />
        <circle cx="9" cy="10.5" r="1.6" />
        <path d="M21 16l-5.5-5.5a1 1 0 00-1.4 0L7 18" />
      </svg>
      {big && <span>Image coming soon</span>}
    </div>
  )
}

function FoundingTimeline() {
  const [active, setActive] = useState(0)
  const era = ERAS[active]
  const percent = (active / (ERAS.length - 1)) * 100

  return (
    <section className="ft-section">
      <h2 className="ft-title">Founding Story &amp; Milestones</h2>

      <div className="ft-content">
        <div className="ft-left">
          <div className="ft-year">{era.range}</div>
          <div className="ft-heading">{era.heading}</div>
          <ul className="ft-list">
            {era.bullets.map((b) => (
              <li key={b}>
                <span className="ft-check">
                  <svg viewBox="0 0 24 24">
                    <path d="M5 13l4 4L19 7" />
                  </svg>
                </span>
                <span>{b}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="ft-right">
          <div className="ft-image-frame">
            <ImagePlaceholder big />
          </div>
        </div>
      </div>

      <div className="ft-nav">
        <div className="ft-thumb-track">
          <div className="ft-thumb" style={{ left: `${percent}%` }}>
            <ImagePlaceholder />
            <span className="ft-thumb-arrow" />
          </div>
        </div>

        <div className="ft-line-track">
          <div className="ft-line" />
          <div className="ft-line-fill" style={{ width: `${percent}%` }} />
          {ERAS.map((e, i) => (
            <button
              key={e.range}
              type="button"
              className={`ft-dot ${i === active ? 'is-active' : ''} ${i < active ? 'is-passed' : ''}`}
              style={{ left: `${(i / (ERAS.length - 1)) * 100}%` }}
              onClick={() => setActive(i)}
              aria-label={`Show ${e.range}`}
            >
              <span className="ft-dot-core" />
              <span className="ft-dot-label">{e.range}</span>
            </button>
          ))}
        </div>
      </div>
    </section>
  )
}

export default FoundingTimeline
