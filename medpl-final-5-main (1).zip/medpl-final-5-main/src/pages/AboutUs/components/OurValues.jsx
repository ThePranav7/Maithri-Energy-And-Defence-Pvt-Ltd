import './OurValues.css'

const VALUES = [
  {
    name: 'Integrity',
    desc: 'We uphold the highest standards of honesty, transparency and ethical practices.',
    icon: (
      <svg viewBox="0 0 24 24">
        <path d="M12 2l8 3v6c0 5-3.5 9-8 11-4.5-2-8-6-8-11V5l8-3z" />
        <path d="M8.5 12l2.5 2.5L16 9.5" />
      </svg>
    ),
  },
  {
    name: 'Innovation',
    desc: 'We continuously innovate to create effective, reliable and future-ready solutions.',
    icon: (
      <svg viewBox="0 0 24 24">
        <path d="M9 18h6" />
        <path d="M10 22h4" />
        <path d="M12 2a6 6 0 00-4 10.5c.6.6 1 1.4 1 2.5h6c0-1.1.4-1.9 1-2.5A6 6 0 0012 2z" />
        <path d="M12 2v2" strokeLinecap="round" />
      </svg>
    ),
  },
  {
    name: 'Quality',
    desc: 'Quality is at the core of every design, product and service we deliver.',
    icon: (
      <svg viewBox="0 0 24 24">
        <circle cx="12" cy="8" r="5" />
        <path d="M9 12.5L7 22l5-3 5 3-2-9.5" />
      </svg>
    ),
  },
  {
    name: 'Commitment',
    desc: 'We are committed to our customers, partners and the communities we serve.',
    icon: (
      <svg viewBox="0 0 24 24">
        <circle cx="9" cy="8" r="3" />
        <circle cx="17" cy="9" r="2.4" />
        <path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6" />
        <path d="M15 14.5c2.5.3 4.5 2.4 4.5 5.5" />
      </svg>
    ),
  },
  {
    name: 'Sustainability',
    desc: 'We build solutions that are energy-efficient, responsible and eco-conscious.',
    icon: (
      <svg viewBox="0 0 24 24">
        <circle cx="12" cy="12" r="9" />
        <path d="M3 12h18" />
        <path d="M12 3c2.5 2.5 3.8 5.8 3.8 9s-1.3 6.5-3.8 9c-2.5-2.5-3.8-5.8-3.8-9S9.5 5.5 12 3z" />
      </svg>
    ),
  },
]

function OurValues() {
  return (
    <section className="values-card">
      <h2 className="values-title">Our Values</h2>
      <div className="values-row">
        {VALUES.map((value, i) => (
          <div
            className="value-item"
            key={value.name}
            style={{ animationDelay: `${i * 1}s` }}
          >
            <div className="value-icon">{value.icon}</div>
            <div className="value-name">{value.name}</div>
            <div className="value-desc">{value.desc}</div>
          </div>
        ))}
      </div>
    </section>
  )
}

export default OurValues
