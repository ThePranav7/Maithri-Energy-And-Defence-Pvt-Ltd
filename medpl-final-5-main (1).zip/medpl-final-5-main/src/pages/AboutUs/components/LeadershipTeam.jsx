import amirthaSwamyPhoto from '../assets/leadership/amirtha-swamy.webp'
import jayachandranPhoto from '../assets/leadership/jayachandran-k.webp'
import badrinathRaoPhoto from '../assets/leadership/badrinath-rao.webp'
import './LeadershipTeam.css'

const LEADERS = [
  {
    name: 'Amirtha Swamy N',
    role: 'Chief Technical Officer (CTO)',
    background:
      'IITian with 20+ years across aerospace, defense, IoT and commercial sectors, with a pivotal role in developing and launching cutting-edge, real-world products.',
    photo: amirthaSwamyPhoto,
  },
  {
    name: 'Jayachandran K',
    role: 'VP — Business Development & OnM',
    background:
      'Dynamic senior executive with 30+ years driving multi-million-dollar growth in Industrial Power, Telecom and Railway sectors, with deep expertise in national sales strategy.',
    photo: jayachandranPhoto,
  },
  {
    name: 'Badrinath Rao',
    role: 'Finance Director',
    background:
      'Finance leader enabling global infrastructure and water projects through innovative cross-border financing, strategic debt solutions, and sustainable investment partnerships.',
    photo: badrinathRaoPhoto,
  },
]

/** Placeholder headshot — keeps the avatar slot present but empty until a real photo is added. */
function AvatarPlaceholder() {
  return (
    <div className="leadership-avatar" aria-hidden="true">
      <svg viewBox="0 0 64 64" width="34" height="34">
        <circle cx="32" cy="24" r="12" fill="#c7ccd6" />
        <path d="M8 56c3.5-13 12.8-20 24-20s20.5 7 24 20" fill="#c7ccd6" />
      </svg>
    </div>
  )
}

function LeadershipAvatar({ leader }) {
  if (!leader.photo) {
    return <AvatarPlaceholder />
  }
  return (
    <div className="leadership-avatar">
      <img
        src={leader.photo}
        alt={leader.name}
        className="leadership-avatar__photo"
      />
    </div>
  )
}

function LeadershipTeam() {
  return (
    <section className="leadership-section">
      <div className="leadership-heading-wrap">
        <h2 className="leadership-heading">Our Leadership Team</h2>
      </div>

      <div className="leadership-grid">
        {LEADERS.map((leader, i) =>
          leader.blank ? (
            <article className="leadership-card leadership-card--blank" key={`blank-${i}`} aria-hidden="true" />
          ) : (
            <article className="leadership-card" key={leader.name}>
              <LeadershipAvatar leader={leader} />
              <h3 className="leadership-name">{leader.name}</h3>
              <p className="leadership-role">{leader.role}</p>
              <p className="leadership-background">{leader.background}</p>
            </article>
          )
        )}
      </div>
    </section>
  )
}

export default LeadershipTeam
