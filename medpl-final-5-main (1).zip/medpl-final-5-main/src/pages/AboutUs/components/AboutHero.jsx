import heroBg from '../assets/hero-bg.webp'
import './AboutHero.css'

function AboutHero() {
  return (
    <section
      className="hero"
      style={{ backgroundImage: `url(${heroBg})` }}
    >
      <div className="hero-text">
        <p className="tagline">
          Engineering Excellence. Purpose-Driven Innovation.
        </p>
        <p className="body-copy">
          MEDPL is built on a culture of engineering excellence, continuous
          innovation, and responsible execution. We combine technical
          expertise with a practical understanding of complex requirements to
          develop solutions that deliver measurable value and lasting
          performance.
        </p>
        <p className="body-copy">
          Our commitment is to build trusted technology through precision,
          quality, and purposeful innovation.
        </p>
      </div>
    </section>
  )
}

export default AboutHero
