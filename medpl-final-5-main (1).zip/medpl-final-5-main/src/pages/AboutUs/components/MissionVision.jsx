import { Fragment } from 'react'
import './MissionVision.css'
import missionIcon from '../assets/mission-icon.webp'
import visionIcon from '../assets/vision-icon.webp'

const CELLS = [
  {
    key: 'mission',
    title: 'Mission',
    body:
      'Deliver high performance, reliable, and secure solutions for defence, renewable, and industrial markets through continuous R&D, indigenous design, and quality manufacturing.',
    icon: missionIcon,
  },
  {
    key: 'vision',
    title: 'Vision',
    body:
      'To be a leading provider of advanced energy storage, defence-grade power systems and innovative power conversion technologies with global recognition.',
    icon: visionIcon,
  },
]

function MissionVision() {
  return (
    <section className="mv-section" aria-label="Mission and Vision">
      <div className="mv-card">
        {CELLS.map((cell, i) => (
          <Fragment key={cell.key}>
            <div className="mv-row">
              <img className="mv-row__icon" src={cell.icon} alt="" />
              <div className="mv-row__copy">
                <h3 className="mv-row__title">{cell.title}</h3>
                <p className="mv-row__body">{cell.body}</p>
              </div>
            </div>
            {i === 0 && <div className="mv-divider" role="presentation" />}
          </Fragment>
        ))}
      </div>
    </section>
  )
}

export default MissionVision
