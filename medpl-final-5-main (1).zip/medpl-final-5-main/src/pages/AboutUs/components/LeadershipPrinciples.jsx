import './LeadershipPrinciples.css'

const PRINCIPLES = [
  {
    name: 'Purpose Driven',
    desc: 'We lead with purpose and create lasting impact.',
    icon: (
      <svg viewBox="0 0 24 24">
        <circle cx="11" cy="13" r="8" />
        <circle cx="11" cy="13" r="4.4" />
        <circle cx="11" cy="13" r="1" fill="currentColor" stroke="none" />
        <path d="M15.5 8.5L20 4" />
        <path d="M20 4h-3.2M20 4v3.2" />
      </svg>
    ),
  },
  {
    name: 'People Centric',
    desc: 'We empower our people and grow together.',
    icon: (
      <svg viewBox="0 0 24 24">
        <circle cx="9" cy="7.5" r="3" />
        <path d="M3.5 19c0-3.6 2.5-6 5.5-6s5.5 2.4 5.5 6" />
        <circle cx="17" cy="9" r="2.3" />
        <path d="M14.7 13.2c2.7.3 4.8 2.5 4.8 5.8" />
      </svg>
    ),
  },
  {
    name: 'Innovative Thinking',
    desc: 'We challenge the status quo and embrace innovation.',
    icon: (
      <svg viewBox="0 0 24 24">
        <path d="M9 17.5h6" />
        <path d="M10 20.5h4" />
        <path d="M12 3a6 6 0 00-4 10.5c.6.6 1 1.4 1 2.5h6c0-1.1.4-1.9 1-2.5A6 6 0 0012 3z" />
        <path d="M12 1.3v1.3" strokeLinecap="round" />
        <path d="M4 6l1.4 1" strokeLinecap="round" />
        <path d="M3 12.5h1.6" strokeLinecap="round" />
        <path d="M20 6l-1.4 1" strokeLinecap="round" />
        <path d="M21 12.5h-1.6" strokeLinecap="round" />
      </svg>
    ),
  },
  {
    name: 'Integrity First',
    desc: 'We uphold transparency, ethics and accountability.',
    icon: (
      <svg viewBox="0 0 24 24">
        <path d="M12 2l8 3v6c0 5-3.5 9-8 11-4.5-2-8-6-8-11V5l8-3z" />
        <path d="M8.5 12l2.5 2.5L16 9.5" />
      </svg>
    ),
  },
  {
    name: 'Collaborative',
    desc: 'We believe in teamwork and mutual respect.',
    icon: (
      <svg viewBox="0 0 24 24">
        <path d="M2 10.5l3.2-2.2c.6-.4 1.4-.4 1.9.1l1.4 1.3" />
        <path d="M22 10.5l-3.2-2.2c-.6-.4-1.4-.4-1.9.1l-4 3.6c-.7.6-.7 1.7 0 2.3.6.5 1.4.5 2 0l2.6-2.2" />
        <path d="M8.5 9.7l3.6 3.2c.6.6.6 1.6 0 2.2-.6.6-1.5.6-2.1.1L8 13.4" />
        <path d="M2 10.5l2.3 6.4 2 1.4" />
        <path d="M22 10.5l-2.1 6.2-3 2" />
      </svg>
    ),
  },
  {
    name: 'Results Oriented',
    desc: 'We focus on delivering excellence, every time.',
    icon: (
      <svg viewBox="0 0 24 24">
        <path d="M3 21h18" />
        <path d="M6 21v-6M11 21v-9M16 21v-4M20 21v-8" />
        <path d="M4 12l5.5-5.5L13 10l7-7" />
        <path d="M16.5 3H21v4.5" />
      </svg>
    ),
  },
]

function LeadershipPrinciples() {
  return (
    <section className="lp-section">
      <div className="lp-heading-wrap">
        <h2 className="lp-heading">Our Leadership Principles</h2>
      </div>

      <div className="lp-row">
        {PRINCIPLES.map((p) => (
          <div className="lp-item" key={p.name}>
            <div className="lp-icon">{p.icon}</div>
            <div className="lp-name">{p.name}</div>
            <div className="lp-desc">{p.desc}</div>
          </div>
        ))}
      </div>
    </section>
  )
}

export default LeadershipPrinciples
