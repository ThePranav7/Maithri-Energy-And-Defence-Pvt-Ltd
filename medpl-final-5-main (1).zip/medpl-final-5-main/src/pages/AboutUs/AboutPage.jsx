import { useEffect } from 'react'
import { useLocation } from 'react-router-dom'
import NavGap from '../../components/Layout/NavGap.jsx'
import AboutHero from './components/AboutHero.jsx'
import OurValues from './components/OurValues.jsx'
import LeadershipTeam from './components/LeadershipTeam.jsx'
import MissionVision from './components/MissionVision.jsx'
import LeadershipPrinciples from './components/LeadershipPrinciples.jsx'
import './AboutPage.css'

const NAVBAR_OFFSET = 90

export default function AboutPage() {
  const location = useLocation()

  useEffect(() => {
    if (location.hash) {
      const el = document.getElementById(location.hash.slice(1))
      if (el) {
        const top = el.getBoundingClientRect().top + window.scrollY - NAVBAR_OFFSET
        window.scrollTo({ top, behavior: 'smooth' })
        return
      }
    }
    window.scrollTo(0, 0)
  }, [location.pathname, location.hash])

  return (
    <>
      <NavGap />
      <div id="about-overview">
        <AboutHero />
      </div>
      <div className="wrapper">
        <OurValues />
        <div id="leadership">
          <LeadershipTeam />
        </div>
      </div>
      <div className="wrapper">
        <LeadershipPrinciples />
      </div>
      <div id="mission">
        <MissionVision />
      </div>
    </>
  )
}
