import React, { useRef, useState } from 'react';
import emailjs from '@emailjs/browser';
import {
  PinIcon,
  PhoneIcon,
  MailIcon,
  GlobeIcon,
  ArrowRightIcon,
  ShareIcon,
  LinkedinIcon,
  FacebookIcon,
  YoutubeIcon,
  XIcon,
} from './Icons.jsx';
import '../styles/contact-details.css';

// EmailJS credentials for the enquiry form
const EMAILJS_SERVICE_ID = 'service_n6japua';
const EMAILJS_TEMPLATE_ID = 'template_kyv3q2l';
const EMAILJS_PUBLIC_KEY = 'cUj4mGTeSMqORRJ9S';

const CHANNELS = [
  {
    icon: <PinIcon />,
    title: 'Registered Address',
    lines: [
      'Second Floor, Plot No. 158, Phase III, IDA Cherlapally, Hyderabad – 500 051',
    ],
  },
  {
    icon: <PhoneIcon />,
    title: 'Phone',
    lines: ['+91\u00A087908\u00A029596 | +91\u00A088857\u00A008126'],
  },
  {
    icon: <MailIcon />,
    title: 'Email',
    lines: ['jayachandran.k@maithrienergy.com', 'amirtha@maithrienergy.com'],
  },
  {
    icon: <GlobeIcon />,
    title: 'Website',
    lines: ['www.maithrienergy.com'],
    href: 'https://www.maithrienergy.com',
  },
];

export default function ContactDetails() {
  const formRef = useRef(null);
  // status: 'idle' | 'sending' | 'success' | 'error'
  const [status, setStatus] = useState('idle');
  const [errors, setErrors] = useState({});

  const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const PHONE_RE = /^[0-9+\-\s()]{7,20}$/;

  const validate = (form) => {
    const data = new FormData(form);
    const next = {};

    const fullName = (data.get('fullName') || '').trim();
    if (!fullName) next.fullName = 'Full name is required.';

    const email = (data.get('email') || '').trim();
    if (!email) next.email = 'Email address is required.';
    else if (!EMAIL_RE.test(email)) next.email = 'Enter a valid email address.';

    const phone = (data.get('phone') || '').trim();
    if (!phone) next.phone = 'Phone number is required.';
    else if (!PHONE_RE.test(phone)) next.phone = 'Enter a valid phone number.';

    const subject = (data.get('subject') || '').trim();
    if (!subject) next.subject = 'Please select an enquiry type.';

    const message = (data.get('message') || '').trim();
    if (!message) next.message = 'Please enter a message.';

    return next;
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!formRef.current) return;

    const nextErrors = validate(formRef.current);
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) {
      setStatus('idle');
      return;
    }

    setStatus('sending');

    emailjs
      .sendForm(
        EMAILJS_SERVICE_ID,
        EMAILJS_TEMPLATE_ID,
        formRef.current,
        { publicKey: EMAILJS_PUBLIC_KEY }
      )
      .then(() => {
        setStatus('success');
        formRef.current.reset();
        setErrors({});
      })
      .catch((error) => {
        console.error('EmailJS send failed:', error);
        setStatus('error');
      });
  };

  return (
    <section className="contact-details">
      <div className="contact-details__grid">
        {/* Left panel: Contact Details */}
        <div className="contact-details__panel">
          <h2 className="contact-details__heading">Contact Details</h2>

          <ul className="contact-details__list">
            {CHANNELS.map((channel) => (
              <li className="contact-channel" key={channel.title}>
                <span className="contact-channel__icon">{channel.icon}</span>
                <div className="contact-channel__text">
                  <p className="contact-channel__title">{channel.title}</p>
                  {channel.lines.map((line, i) =>
                    channel.href ? (
                      <a
                        className="contact-channel__link"
                        href={channel.href}
                        target="_blank"
                        rel="noreferrer"
                        key={i}
                      >
                        {line}
                      </a>
                    ) : channel.title === 'Email' && line.includes('@') ? (
                      <p className="contact-channel__detail" key={i}>
                        {line.split('@')[0]}@<wbr />
                        {line.split('@')[1]}
                      </p>
                    ) : (
                      <p
                        className={
                          channel.title === 'Phone'
                            ? 'contact-channel__detail contact-channel__detail--phone'
                            : 'contact-channel__detail'
                        }
                        key={i}
                      >
                        {line}
                      </p>
                    )
                  )}
                </div>
              </li>
            ))}
          </ul>

          <div className="contact-details__connect">
            <div className="contact-details__connect-heading">
              <span className="contact-details__connect-icon">
                <ShareIcon />
              </span>
              <span>Connect With Us</span>
            </div>
            <div className="contact-details__socials">
              <a
                className="contact-details__social"
                href="https://www.linkedin.com/company/maithrienergy"
                target="_blank"
                rel="noreferrer"
                aria-label="LinkedIn"
              >
                <LinkedinIcon />
              </a>
              <a
                className="contact-details__social"
                href="https://www.facebook.com/maithrienergy"
                target="_blank"
                rel="noreferrer"
                aria-label="Facebook"
              >
                <FacebookIcon />
              </a>
              <a
                className="contact-details__social"
                href="https://www.youtube.com/@maithrienergy"
                target="_blank"
                rel="noreferrer"
                aria-label="YouTube"
              >
                <YoutubeIcon />
              </a>
              <a
                className="contact-details__social"
                href="https://x.com/maithrienergy"
                target="_blank"
                rel="noreferrer"
                aria-label="X"
              >
                <XIcon />
              </a>
            </div>
          </div>
        </div>

        {/* Right panel: Enquiry Form */}
        <div className="contact-details__panel">
          <h2 className="contact-details__heading">Send Us an Enquiry</h2>
          <p className="contact-details__subtext">
            Fill out the form below and our team will get back to you shortly.
          </p>

          <form
            className="enquiry-form"
            ref={formRef}
            onSubmit={handleSubmit}
            noValidate
          >
            <div className="enquiry-form__row">
              <div className="enquiry-form__field">
                <label htmlFor="fullName">
                  Full Name <span className="enquiry-form__required">*</span>
                </label>
                <input
                  id="fullName"
                  name="fullName"
                  type="text"
                  placeholder="Your full name"
                  aria-invalid={!!errors.fullName}
                />
                {errors.fullName && <span className="enquiry-form__error">{errors.fullName}</span>}
              </div>
              <div className="enquiry-form__field">
                <label htmlFor="organisation">Organisation / Company</label>
                <input id="organisation" name="organisation" type="text" placeholder="Your company name (optional)" />
              </div>
            </div>

            <div className="enquiry-form__row">
              <div className="enquiry-form__field">
                <label htmlFor="email">
                  Email Address <span className="enquiry-form__required">*</span>
                </label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  placeholder="youremail@company.com"
                  aria-invalid={!!errors.email}
                />
                {errors.email && <span className="enquiry-form__error">{errors.email}</span>}
              </div>
              <div className="enquiry-form__field">
                <label htmlFor="phone">
                  Phone Number <span className="enquiry-form__required">*</span>
                </label>
                <input
                  id="phone"
                  name="phone"
                  type="tel"
                  placeholder="+91 00000 00000"
                  aria-invalid={!!errors.phone}
                />
                {errors.phone && <span className="enquiry-form__error">{errors.phone}</span>}
              </div>
            </div>

            <div className="enquiry-form__field enquiry-form__field--full">
              <label htmlFor="subject">
                Subject <span className="enquiry-form__required">*</span>
              </label>
              <select id="subject" name="subject" defaultValue="" aria-invalid={!!errors.subject}>
                <option value="" disabled>
                  Select an enquiry type
                </option>
                <option value="industrial">Industrial</option>
                <option value="defense">Defense</option>
                <option value="iot">IoT</option>
                <option value="general">General</option>
              </select>
              {errors.subject && <span className="enquiry-form__error">{errors.subject}</span>}
            </div>

            <div className="enquiry-form__field enquiry-form__field--full">
              <label htmlFor="message">
                Message <span className="enquiry-form__required">*</span>
              </label>
              <textarea
                id="message"
                name="message"
                rows="4"
                placeholder="Please share your enquiry or requirements in detail..."
                aria-invalid={!!errors.message}
              />
              {errors.message && <span className="enquiry-form__error">{errors.message}</span>}
            </div>

            <button
              type="submit"
              className="enquiry-form__submit"
              disabled={status === 'sending'}
            >
              {status === 'sending' ? 'SENDING...' : 'SEND ENQUIRY'}
              <ArrowRightIcon />
            </button>

            {status === 'success' && (
              <p className="enquiry-form__status enquiry-form__status--success" role="status">
                Thank you! Your enquiry has been sent successfully. Our team will get back to you shortly.
              </p>
            )}
            {status === 'error' && (
              <p className="enquiry-form__status enquiry-form__status--error" role="alert">
                Sorry, something went wrong while sending your enquiry. Please try again or reach us directly via phone or email.
              </p>
            )}
          </form>
        </div>
      </div>
    </section>
  );
}
