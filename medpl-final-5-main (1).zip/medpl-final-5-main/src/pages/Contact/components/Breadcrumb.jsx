import React from 'react';

export default function Breadcrumb() {
  return (
    <nav className="breadcrumb" aria-label="Breadcrumb">
      <span className="breadcrumb__item">Home</span>
      <svg
        className="breadcrumb__chevron"
        width="14"
        height="14"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        aria-hidden="true"
      >
        <polyline points="9 6 15 12 9 18" />
      </svg>
      <span className="breadcrumb__item breadcrumb__item--current">Contact Us</span>
    </nav>
  );
}
