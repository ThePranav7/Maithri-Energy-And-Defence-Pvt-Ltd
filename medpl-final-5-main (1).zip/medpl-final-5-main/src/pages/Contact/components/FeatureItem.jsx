import React from 'react';

export default function FeatureItem({ icon, title, description, showDivider }) {
  return (
    <div className="feature-item">
      <span className="feature-item__icon">{icon}</span>
      <div className="feature-item__text">
        <p className="feature-item__title">{title}</p>
        <p className="feature-item__description">{description}</p>
      </div>
      {showDivider && <span className="feature-item__divider" aria-hidden="true" />}
    </div>
  );
}
