import React from 'react';
import FeatureItem from './FeatureItem.jsx';
import { HeadsetIcon, ShieldCheckIcon, HandshakeIcon } from './Icons.jsx';
import backgroundImage from '../assets/contact-background.webp';
import '../styles/contact.css';

const FEATURES = [
  {
    icon: <HeadsetIcon />,
    title: 'Quick Response',
    description: (
      <>
        We respond within
        <br />
        24 business hours.
      </>
    ),
  },
  {
    icon: <ShieldCheckIcon />,
    title: 'Reliable Support',
    description: (
      <>
        Expert assistance for
        <br />
        all your queries.
      </>
    ),
  },
  {
    icon: <HandshakeIcon />,
    title: 'Partnership Focus',
    description: (
      <>
        Open to collaborations
        <br />
        and new opportunities.
      </>
    ),
  },
];

export default function ContactHero() {
  return (
    <div className="contact-hero-wrap">
      <section
        className="contact-hero"
        style={{ backgroundImage: `url(${backgroundImage})` }}
      >
        <div className="contact-hero__overlay" />

        <div className="contact-hero__content">
          <h1 className="contact-hero__heading">
            Let&rsquo;s Build a
            <br />
            Stronger Tomorrow
          </h1>

          <p className="contact-hero__description">
            Have a question, partnership idea, or need support?
            <br />
            We&rsquo;re here to help. Reach out to our team and
            <br />
            we&rsquo;ll get back to you as soon as possible.
          </p>

          <div className="contact-hero__features">
            {FEATURES.map((feature, index) => (
              <FeatureItem
                key={feature.title}
                icon={feature.icon}
                title={feature.title}
                description={feature.description}
                showDivider={index < FEATURES.length - 1}
              />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
