import React from 'react';
import {
  CarIcon,
  PersonIcon,
  WheelchairIcon,
  ClockIcon,
  HeadsetIcon,
  MailIcon,
  UsersIcon,
  HandshakeIcon,
  ArrowRightIcon,
} from './Icons.jsx';
import '../styles/our-location.css';

const FEATURES = [
  { icon: <CarIcon />, text: 'Well-connected by road and public transport' },
  { icon: <PersonIcon />, text: 'Ample visitor parking available' },
  { icon: <WheelchairIcon />, text: 'Accessible facilities for all visitors' },
];

const INFO_ITEMS = [
  {
    icon: <ClockIcon />,
    title: 'Business Hours',
    lines: ['Mon – Sat: 9:00 AM – 5:30 PM', 'Sunday: Closed'],
  },
  {
    icon: <HeadsetIcon />,
    title: 'Support Availability',
    lines: ['Available Anytime'],
  },
  {
    icon: <MailIcon />,
    title: 'Response Time',
    lines: ['We aim to respond', 'Anytime.'],
  },
  {
    icon: <UsersIcon />,
    title: "Let's Collaborate",
    lines: ['We welcome partnership', 'and project inquiries.'],
  },
];

const MAP_EMBED_SRC =
  'https://maps.google.com/maps?ll=17.4462562,78.6001475&z=14&output=embed';

const MAPS_DIRECTIONS_URL =
  'https://www.google.com/maps/dir/?api=1&destination=Maithri+Energy+%26+Defense+Pvt+Ltd,+Plot+158,+Phase+III,+IDA+Cherlapally,+Hyderabad+500051';

export default function OurLocation() {
  return (
    <>
      {/* Section 1: Our Location */}
      <section className="our-location">
        <div className="our-location__grid">
          <div className="our-location__text">
            <h2 className="our-location__heading">Our Location</h2>
            <span className="our-location__accent" aria-hidden="true" />
            <p className="our-location__desc">
              Our headquarters is located in Hyderabad, Telangana. Visit us for
              meetings or collaborations.
            </p>

            <ul className="our-location__features">
              {FEATURES.map((f) => (
                <li className="our-location__feature" key={f.text}>
                  <span className="our-location__feature-icon">{f.icon}</span>
                  <span>{f.text}</span>
                </li>
              ))}
            </ul>

            <a
              className="our-location__directions"
              href={MAPS_DIRECTIONS_URL}
              target="_blank"
              rel="noreferrer"
            >
              GET DIRECTIONS
              <ArrowRightIcon />
            </a>
          </div>

          <div className="our-location__map">
            <div className="our-location__map-card">
              <p className="our-location__map-card-title">
                Maithri Energy &amp; Defense Pvt. Ltd.
              </p>
              <p className="our-location__map-card-line">
                Second Floor, Plot No. 158, Phase III, IDA Cherlapally,
                Hyderabad – 500 051, Telangana, India
              </p>
              <a
                className="our-location__map-card-link"
                href={MAPS_DIRECTIONS_URL}
                target="_blank"
                rel="noreferrer"
              >
                View larger map
              </a>
            </div>

            <iframe
              className="our-location__map-iframe"
              src={MAP_EMBED_SRC}
              width="600"
              height="450"
              style={{ border: 0 }}
              allowFullScreen=""
              loading="lazy"
              referrerPolicy="strict-origin-when-cross-origin"
              title="Maithri Energy & Defense Pvt. Ltd. location map"
            />
          </div>
        </div>
      </section>

      {/* Section 2: Info strip */}
      <section className="our-location__info-strip">
        <div className="our-location__info-strip-grid">
          {INFO_ITEMS.map((item) => (
            <div className="info-item" key={item.title}>
              <span className="info-item__icon">{item.icon}</span>
              <div className="info-item__text">
                <p className="info-item__title">{item.title}</p>
                {item.lines.map((line, i) => (
                  <p className="info-item__line" key={i}>
                    {line}
                  </p>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Section 3: CTA banner */}
      <section className="our-location__cta">
        <div className="our-location__cta-inner">
          <span className="our-location__cta-icon">
            <HandshakeIcon />
          </span>
          <div className="our-location__cta-text">
            <p className="our-location__cta-heading">
              Ready to Power Possibilities Together?
            </p>
            <p className="our-location__cta-sub">
              Whether you have a question, need support, or want to explore a
              partnership, our team is ready to connect.
            </p>
          </div>
          <a className="our-location__cta-button" href="#contact-details">
            GET IN TOUCH
            <ArrowRightIcon />
          </a>
        </div>
      </section>
    </>
  );
}
