import React from 'react';

export function HeadsetIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M3 13a9 9 0 0 1 18 0" />
      <path d="M21 13v4a2 2 0 0 1-2 2h-1" />
      <rect x="17" y="13" width="4" height="6" rx="1.5" />
      <rect x="3" y="13" width="4" height="6" rx="1.5" />
      <path d="M12 21a2 2 0 0 0 2-2" />
    </svg>
  );
}

export function ShieldCheckIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M12 2.5 4 5.5v6c0 5.2 3.4 9 8 10 4.6-1 8-4.8 8-10v-6L12 2.5Z" />
      <path d="m8.5 12.3 2.3 2.3 4.7-4.9" />
    </svg>
  );
}

export function HandshakeIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="m11 17 2 2a1 1 0 1 0 3-3" />
      <path d="m14 14 2.5 2.5a1 1 0 1 0 3-3l-3.88-3.88a3 3 0 0 0-4.24 0l-.88.88a1 1 0 1 1-3-3l2.81-2.81a5.79 5.79 0 0 1 7.06-.87l.47.28a2 2 0 0 0 1.42.25L21 4" />
      <path d="m21 3 1 11h-2" />
      <path d="M3 3 2 14l6.5 6.5a1 1 0 1 0 3-3" />
      <path d="M3 4h8" />
    </svg>
  );
}

export function PinIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M12 21.5s7-6.6 7-12A7 7 0 0 0 5 9.5c0 5.4 7 12 7 12Z" />
      <circle cx="12" cy="9.5" r="2.5" />
    </svg>
  );
}

export function PhoneIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M4.5 4.5h4l1.7 4.4-2.2 1.7a12.5 12.5 0 0 0 5.4 5.4l1.7-2.2 4.4 1.7v4a1.5 1.5 0 0 1-1.6 1.5A16.5 16.5 0 0 1 3 5.5a1.5 1.5 0 0 1 1.5-1Z" />
    </svg>
  );
}

export function MailIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <rect x="3" y="5.5" width="18" height="13" rx="2" />
      <path d="m4 7 8 6 8-6" />
    </svg>
  );
}

export function GlobeIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <circle cx="12" cy="12" r="9" />
      <path d="M3 12h18" />
      <path d="M12 3c2.6 2.5 4 5.7 4 9s-1.4 6.5-4 9c-2.6-2.5-4-5.7-4-9s1.4-6.5 4-9Z" />
    </svg>
  );
}

export function ClockIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v5.5l3.5 2" />
    </svg>
  );
}

export function CarIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M4 16.5v-3.2c0-.5.16-1 .46-1.4l1.9-2.5A2.2 2.2 0 0 1 8.1 8.5h7.8c.7 0 1.35.33 1.74.9l1.9 2.5c.3.4.46.9.46 1.4v3.2" />
      <path d="M4 16.5h16" />
      <rect x="2.5" y="16.5" width="3" height="2.5" rx="0.6" />
      <rect x="18.5" y="16.5" width="3" height="2.5" rx="0.6" />
      <circle cx="7.5" cy="16.5" r="1.6" />
      <circle cx="16.5" cy="16.5" r="1.6" />
    </svg>
  );
}

export function PersonIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <circle cx="12" cy="7.5" r="3.3" />
      <path d="M5 20.5c0-3.6 3.1-6.2 7-6.2s7 2.6 7 6.2" />
    </svg>
  );
}

export function WheelchairIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <circle cx="10.5" cy="4.5" r="1.6" />
      <path d="M10 8v4l4.5 2.2" />
      <path d="M10 12H6.5" />
      <path d="M9.3 12a5.2 5.2 0 1 0 5.6 6.4" />
      <path d="m14.5 14.2 2 4.8h3" />
    </svg>
  );
}

export function UsersIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <circle cx="9" cy="8" r="3" />
      <path d="M2.7 19.5c0-3.3 2.8-5.7 6.3-5.7s6.3 2.4 6.3 5.7" />
      <circle cx="17.5" cy="8.7" r="2.4" />
      <path d="M15.8 13.9c2.8.3 4.9 2.4 4.9 5.1" />
    </svg>
  );
}

export function ShareIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <circle cx="18" cy="5" r="2.5" />
      <circle cx="6" cy="12" r="2.5" />
      <circle cx="18" cy="19" r="2.5" />
      <path d="m8.2 10.8 7.6-4.6" />
      <path d="m8.2 13.2 7.6 4.6" />
    </svg>
  );
}

export function LinkedinIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
      <path d="M6.94 5a1.94 1.94 0 1 1 0 3.88 1.94 1.94 0 0 1 0-3.88ZM5.16 9.75h3.56V19H5.16V9.75ZM11.2 9.75h3.41v1.27h.05c.48-.9 1.64-1.85 3.38-1.85 3.61 0 4.28 2.38 4.28 5.47V19h-3.55v-4.36c0-1.04-.02-2.38-1.45-2.38-1.46 0-1.68 1.14-1.68 2.31V19H11.2V9.75Z" />
    </svg>
  );
}

export function FacebookIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
      <path d="M14.5 21v-7.6h2.55l.38-2.96h-2.93V8.55c0-.86.24-1.44 1.47-1.44h1.57V4.46c-.27-.04-1.2-.12-2.28-.12-2.26 0-3.8 1.38-3.8 3.9v2.2H9v2.96h2.46V21h3.04Z" />
    </svg>
  );
}

export function YoutubeIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
      <path d="M21.5 8.1s-.2-1.5-.84-2.2c-.8-.85-1.7-.85-2.1-.9C15.8 4.8 12 4.8 12 4.8h-.01s-3.8 0-6.55.2c-.4.05-1.3.05-2.1.9C2.7 6.6 2.5 8.1 2.5 8.1S2.3 9.85 2.3 11.6v1.3c0 1.75.2 3.5.2 3.5s.2 1.5.84 2.2c.8.85 1.85.83 2.3.92 1.67.16 7.36.2 7.36.2s3.8-.01 6.56-.21c.4-.05 1.3-.05 2.1-.9.64-.7.84-2.2.84-2.2s.2-1.75.2-3.5v-1.3c0-1.75-.2-3.5-.2-3.5ZM9.95 14.9V8.9l5.6 3-5.6 3Z" />
    </svg>
  );
}

export function XIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
      <path d="M13.7 10.6 20.15 3h-1.53l-5.6 6.6L8.55 3H3.3l6.77 9.85L3.3 21h1.53l5.92-6.98L15.45 21h5.25l-7-10.4Zm-2.1 2.47-.68-.98L5.5 4.14h2.35l4.4 6.3.68.98 5.72 8.2h-2.35l-4.7-6.62Z" />
    </svg>
  );
}

export function ArrowRightIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M4 12h16" />
      <path d="m13 5 7 7-7 7" />
    </svg>
  );
}
