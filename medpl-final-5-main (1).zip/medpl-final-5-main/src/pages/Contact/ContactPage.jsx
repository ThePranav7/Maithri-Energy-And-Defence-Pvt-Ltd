import React, { useEffect } from "react";
import { useLocation } from "react-router-dom";
import ContactHero from "./components/ContactHero.jsx";
import ContactDetails from "./components/ContactDetails.jsx";
import OurLocation from "./components/OurLocation.jsx";

const NAVBAR_OFFSET = 90;

export default function ContactPage() {
  const location = useLocation();

  useEffect(() => {
    if (location.hash === "#contact-details") {
      const el = document.getElementById("contact-details");
      if (el) {
        const top = el.getBoundingClientRect().top + window.scrollY - NAVBAR_OFFSET;
        window.scrollTo({ top, behavior: "smooth" });
        return;
      }
    }
    window.scrollTo(0, 0);
  }, [location.pathname, location.hash]);

  return (
    <div className="contact-page">
      <ContactHero />
      <div id="contact-details">
        <ContactDetails />
      </div>
      <OurLocation />
    </div>
  );
}
