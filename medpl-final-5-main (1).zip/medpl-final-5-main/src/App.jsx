import { Routes, Route } from 'react-router-dom'
import Navbar from './components/Layout/Navbar.jsx'
import Footer from './components/Layout/Footer.jsx'
import HeroCarousel from './components/HeroCarousel/HeroCarousel.jsx'
import CorePillars from './components/CorePillars/CorePillars.jsx'
import SolutionsPreview from './components/SolutionsPreview/SolutionsPreview.jsx'
import TrustedBy from './components/TrustedBy/TrustedBy.jsx'
import WhyChooseUs from './components/WhyChooseUs/WhyChooseUs.jsx'
import AboutPage from './pages/AboutUs/AboutPage.jsx'
import ProductsPage from './pages/Products/ProductsPage.jsx'
import IndustrialPage from './pages/Products/Industrial/IndustrialPage.jsx'
import LiIonPage from './pages/Products/Industrial/LiIon/LiIonPage.jsx'
import PowerSystemPage from './pages/Products/Industrial/PowerSystem/PowerSystemPage.jsx'
import BMSPage from './pages/Products/Industrial/BMS/BMSPage.jsx'
import DefensePage from './pages/Products/Defense/DefensePage.jsx'
import IoTPage from './pages/Products/IoT/IoTPage.jsx'
import ContactPage from './pages/Contact/ContactPage.jsx'
import NewsPage from './pages/News/NewsPage.jsx'
import CareersPage from './pages/Careers/CareersPage.jsx'
import LegalPage from './pages/Legal/LegalPage.jsx'

function Home() {
  return (
    <main>
      <HeroCarousel />
      <CorePillars />
      <SolutionsPreview />
      <TrustedBy />
      <WhyChooseUs />
    </main>
  )
}

export default function App() {
  return (
    <>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="/products" element={<ProductsPage />} />
        <Route path="/products/industrial" element={<IndustrialPage />} />
        <Route path="/products/industrial/li-ion" element={<LiIonPage />} />
        <Route path="/products/industrial/power-system" element={<PowerSystemPage />} />
        <Route path="/products/industrial/bms" element={<BMSPage />} />
        <Route path="/products/defense" element={<DefensePage />} />
        <Route path="/products/iot" element={<IoTPage />} />
        <Route path="/contact" element={<ContactPage />} />
        <Route path="/news" element={<NewsPage />} />
        <Route path="/careers" element={<CareersPage />} />
        <Route path="/privacy" element={<LegalPage title="Privacy Policy" />} />
        <Route path="/terms" element={<LegalPage title="Terms" />} />
      </Routes>
      <Footer />
    </>
  )
}
